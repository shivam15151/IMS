<?php
$conn = new mysqli("localhost", "root", "", "labm");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error());
}
$sql="SELECT * FROM `items`";
$result= mysqli_query($conn,$sql);
$check= mysqli_fetch_array($result);
echo $check['lab_no'];
// if($row = $check){
// $lab_no = $row["lab_no"];
// $description = $row["description"];
// $quantity = $row["qty"];
// $equ_sr_no = $row["eqp_no"];
// $clg_code = $row["code"];
// $maf = $row["maf"];
// $invoice = $row["inv"];
// $dop = $row["date"];
// $gi_no = $row["gi_no"];
// $rate = $row["rate"];
// $dis_rate = $row["dis_rate"];
// $rate_vat = $row["rate_vat"];
// $cost_vat = $row["cost_vat"];
// $defective = $row["defective"];
// }
    include 'tcpdf/tcpdf.php';
      $obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
      $obj_pdf->SetCreator(PDF_CREATOR);  
      $obj_pdf->SetTitle("Export HTML Table data to PDF using TCPDF in PHP");  
    //  $obj_pdf->setViewerPreferences($preferences);
      $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
      $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
      $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
      $obj_pdf->SetDefaultMonospacedFont('helvetica  ');  
      $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
      $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '5', PDF_MARGIN_RIGHT);  
      $obj_pdf->setPrintHeader(false);  
      $obj_pdf->setPrintFooter(false);  
      $obj_pdf->SetAutoPageBreak(TRUE, 10);  
      $obj_pdf->setFontSubsetting(false);
      $obj_pdf->SetFont('helvetica', '', 12);  
      $obj_pdf->AddPage('L','A4'); 
//       // -- set new background ---
// // get the current page break margin
// $bMargin = $obj_pdf->getBreakMargin();
// // get current auto-page-break mode
// $auto_page_break = $obj_pdf->getAutoPageBreak();
// // disable auto-page-break
// $obj_pdf->SetAutoPageBreak(false, 0);
// // set bacground image
// $img_file = K_PATH_IMAGES.'1.jpg';
// $obj_pdf->Image($img_file, 0, 0,288, 224, '', '', '', false, 300, '', false, false, 0);
// // restore auto-page-break status
// $obj_pdf->SetAutoPageBreak($auto_page_break, $bMargin);
// // set the starting point for the page content
// $obj_pdf->setPageMark();
   
    // $diff = (date('Y') - date('Y',strtotime($DOB))-1);
$def=<<<EOD
      <table cellspacing="0" cellpadding="1" border="1" id="table">
    <tr>
       <th>Sr. no.</th>
            <th>Lab</th>
            <th>Description</th>
            <th>Quantity</th>
            <th>Equipment Serial No.</th>
            <th>College Code</th>
            <th>Supplier / Manufacturer</th>
            <th>Invoice / Challan</th>
            <th>Date of Purchase </th>
            <th>Gl No.</th>
            <th>Rate</th>
            <th>Discounted Rate</th>
            <th>Rate with Vat</th>
            <th>Cost with Vat</th>
            <th>Defective</th>
            <th>Action</th>
 </tr>
// EOD;
//   while($row = $result->fetch_assoc()) {
// $def .="<tr>
//              <td style="text-align: center;"><?php echo $row["id"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["lab_no"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["description"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["quantity"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["equipment no"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["college code"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["manufacturer"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["invoice"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["date"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["gi_no"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["rate"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["discounted rate"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["rate with vat"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["cost with vat"]; ?></td>
//              <td style="text-align: center;"><?php echo $row["defective"]; ?></td>
//           </tr>
//           <?php
//           }
//         }
//         ?>";
//  $i++;
 $defid++;
  }
$def .="</table>";
 $obj_pdf->writeHTML($def);
  $obj_pdf->Output("sample.pdf","I");
         
?>