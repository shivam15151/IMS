<?php


echo('<nav class="navbar navbar-expand-lg navbar-light bg-light"> ');
// echo('  <a class="navbar-brand" href="#">Navbar</a>');
// echo('  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">');
// echo('    <span class="navbar-toggler-icon"></span>');
// echo('  </button>');
echo('  <div class="collapse navbar-collapse" id="navbarNav">');
echo('    <ul class="navbar-nav">');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="hardware inv 601.php">Lab 601 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="hardware inv 602.php">Lab 602 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="hardware inv 603.php">Lab 603 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="hardware inv 604.php">Lab 604 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="hardware inv 605.php">Lab 605 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="hardware inv 701.php">Lab 701 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="hardware inv 703.php">Lab 703 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="hardware inv 709.php">Lab 709 <span class="sr-only">(current)</span></a>');
echo('      </li>');
// echo('      <li class="nav-item">');
// echo('        <a class="nav-link" href="#">Features</a>');
// echo('      </li>');
// echo('      <li class="nav-item">');
// echo('        <a class="nav-link" href="#">Pricing</a>');
// echo('      </li>');
// echo('      <li class="nav-item">');
// echo('        <a class="nav-link disabled" href="#">Disabled</a>');
// echo('      </li>');
echo('    </ul>');
echo('  </div>');
echo('</nav>');
?>