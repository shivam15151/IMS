<?php

session_start();

include('connect.php');



if (!(isset($_SESSION['login']))) {

    header('location:index.php');
}







$sql = "SELECT * FROM `items`";

$sql1 = "SELECT * FROM `software`";

$sql2 = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 601: Basic Electronics and PCB Lab'";

$sql3 = "SELECT * FROM `software` WHERE `lab_no` = 'Lab 601: Basic Electronics and PCB Lab'";

$sql4 = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 602: Analog and Digital Communication Lab'";

$sql5 = "SELECT * FROM `software` WHERE `lab_no` = 'Lab 602: Analog and Digital Communication Lab'";

$sql6 = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 603: RF Communication Lab'";

$sql7 = "SELECT * FROM `software` WHERE `lab_no` = 'Lab 603: RF Communication Lab'";

$sql8 = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 604: Microwave and Satellite Communication Lab'";

$sql9 = "SELECT * FROM `software` WHERE `lab_no` = 'Lab 604: Microwave and Satellite Communication Lab'";

$sql10 = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 605: Microcontoller and Microprocessor Lab'";

$sql11 = "SELECT * FROM `software` WHERE `lab_no` = 'Lab 605: Microcontoller and Microprocessor Lab'";

$sql12 = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 701: Software Simulation and Networking Lab'";

$sql13 = "SELECT * FROM `software` WHERE `lab_no` = 'Lab 701: Software Simulation and Networking Lab'";

$sql14 = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 703: Signal Processing Lab'";

$sql15 = "SELECT * FROM `software` WHERE `lab_no` = 'Lab 703: Signal Processing Lab'";

$sql16 = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 709: Project Lab'";

$sql17 = "SELECT * FROM `software` WHERE `lab_no` = 'Lab 709: Project Lab'";

// $sql18 = "SELECT COUNT(*) FROM `items` WHERE `rep_calib` = 'Repair'";





$result = $conn->query($sql);

$result1 = $conn->query($sql1);

$result2 = $conn->query($sql2);

$result3 = $conn->query($sql3);

$result4 = $conn->query($sql4);

$result5 = $conn->query($sql5);

$result6 = $conn->query($sql6);

$result7 = $conn->query($sql7);

$result8 = $conn->query($sql8);

$result9 = $conn->query($sql9);

$result10 = $conn->query($sql10);

$result11 = $conn->query($sql11);

$result12 = $conn->query($sql12);

$result13 = $conn->query($sql13);

$result14 = $conn->query($sql14);

$result15 = $conn->query($sql15);

$result16 = $conn->query($sql16);

$result17 = $conn->query($sql17);

// $result18 = $conn->query($sql18);




$sum_hardware = 0;

$sum_software = 0;

$sum_lab601_soft = 0;

$sum_lab601_hard = 0;

$sum_lab602_soft = 0;

$sum_lab602_hard = 0;

$sum_lab603_soft = 0;

$sum_lab603_hard = 0;

$sum_lab604_soft = 0;

$sum_lab604_hard = 0;

$sum_lab605_soft = 0;

$sum_lab605_hard = 0;

$sum_lab701_soft = 0;

$sum_lab701_hard = 0;

$sum_lab703_soft = 0;

$sum_lab703_hard = 0;

$sum_lab709_soft = 0;

$sum_lab709_hard = 0;

$sum_repair = 0;







if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        $sum_hardware = $sum_hardware + $row["total_cost"];
    }
}



if ($result1->num_rows > 0) {

    while ($row = $result1->fetch_assoc()) {

        $sum_software = $sum_software + $row["total_cost"];
    }
}



if ($result2->num_rows > 0) {

    while ($row = $result2->fetch_assoc()) {

        $sum_lab601_hard = $sum_lab601_hard + $row["total_cost"];
    }
}



if ($result3->num_rows > 0) {

    while ($row = $result3->fetch_assoc()) {

        $sum_lab601_soft = $sum_lab601_soft + $row["total_cost"];
    }
}



if ($result4->num_rows > 0) {

    while ($row = $result4->fetch_assoc()) {

        $sum_lab602_hard = $sum_lab602_hard + $row["total_cost"];
    }
}



if ($result5->num_rows > 0) {

    while ($row = $result5->fetch_assoc()) {

        $sum_lab602_soft = $sum_lab602_soft + $row["total_cost"];
    }
}



if ($result6->num_rows > 0) {

    while ($row = $result6->fetch_assoc()) {

        $sum_lab603_hard = $sum_lab603_hard + $row["total_cost"];
    }
}



if ($result7->num_rows > 0) {

    while ($row = $result7->fetch_assoc()) {

        $sum_lab603_soft = $sum_lab603_soft + $row["total_cost"];
    }
}



if ($result8->num_rows > 0) {

    while ($row = $result8->fetch_assoc()) {

        $sum_lab604_hard = $sum_lab604_hard + $row["total_cost"];
    }
}



if ($result9->num_rows > 0) {

    while ($row = $result9->fetch_assoc()) {

        $sum_lab604_soft = $sum_lab604_soft + $row["total_cost"];
    }
}



if ($result10->num_rows > 0) {

    while ($row = $result10->fetch_assoc()) {

        $sum_lab605_hard = $sum_lab605_hard + $row["total_cost"];
    }
}



if ($result11->num_rows > 0) {

    while ($row = $result11->fetch_assoc()) {

        $sum_lab605_soft = $sum_lab605_soft + $row["total_cost"];
    }
}



if ($result12->num_rows > 0) {

    while ($row = $result12->fetch_assoc()) {

        $sum_lab701_hard = $sum_lab701_hard + $row["total_cost"];
    }
}



if ($result13->num_rows > 0) {

    while ($row = $result13->fetch_assoc()) {

        $sum_lab701_soft = $sum_lab701_soft + $row["total_cost"];
    }
}



if ($result14->num_rows > 0) {

    while ($row = $result14->fetch_assoc()) {

        $sum_lab703_hard = $sum_lab703_hard + $row["total_cost"];
    }
}



if ($result15->num_rows > 0) {

    while ($row = $result15->fetch_assoc()) {

        $sum_lab703_soft = $sum_lab703_soft + $row["total_cost"];
    }
}



if ($result16->num_rows > 0) {

    while ($row = $result16->fetch_assoc()) {

        $sum_lab709_hard = $sum_lab709_hard + $row["total_cost"];
    }
}



if ($result17->num_rows > 0) {

    while ($row = $result17->fetch_assoc()) {

        $sum_lab709_soft = $sum_lab709_soft + $row["total_cost"];
    }
}



// if ($result18->num_rows > 0) {

//     while ($row = $result18->fetch_assoc()) {

//         $sum_repair = $sum_repair;
//     }
// }





?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <style type="text/css">
        .disclaimer {
            display: none;
        }
    </style>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="">

    <meta name="author" content="">

    <title> IMS </title>

    <!-- Custom fonts for this template-->

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">


    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-xymdQtn1n3lH2wcu0qhcdaOpQwyoarkgLVxC/wZ5q7h9gHtxICrpcaSUfygqZGOe" crossorigin="anonymous"></script>


    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <link rel=”stylesheet” href=”https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css” />

    <link rel=”stylesheet” href=”https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css” />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- Custom styles for this template-->

    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <link href="dashbd.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->

    <div id="wrapper">

        <!-- Sidebar -->

        <!-- Sidebar -->

        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->

            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">

                <div class="sidebar-brand-icon rotate-n-15">

                    <i class="#"></i>

                </div>

                <div class="sidebar-brand-text mx-3"><?php echo $_SESSION['login']; ?></div>

            </a>

            <!-- Divider -->

            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->

            <li class="nav-item active">

                <a class="nav-link" href="dashboard.php">

                    <i class="fas fa-fw fa-tachometer-alt"></i>

                    <span>Dashboard</span></a>

            </li>

            <!-- Divider -->

            <hr class="sidebar-divider">

            <!-- Nav Item - Utilities Collapse Menu -->

            <li class="nav-item">

                <a class="nav-link" href="profile.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Profile</span>

                </a>

            <li class="nav-item">

                <a class="nav-link" href="add item.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Add Items</span>

                </a>

            <li class="nav-item">

                <a class="nav-link" href="room.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Room</span>

                </a>

            <li class="nav-item">

                <a class="nav-link" href="hardware inv.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Inventory</span>

                </a>

                <!-- Divider -->

                <hr class="sidebar-divider">

                <!-- Nav Item - Charts -->

            <li class="nav-item">

                <a class="nav-link" href="defective.php">

                    <i class="fas fa-fw fa-chart-area"></i>

                    <span>Defectives</span></a>

            </li>

            <li class="nav-item">

                <a class="nav-link" href="borrower.php">

                    <i class="fa fa-users"></i>

                    <span>Borrower</span></a>

            </li>

            <!-- Nav Item - Tables -->

            <li class="nav-item">

                <a class="nav-link" href="repair.php">

                    <i class="fas fa-fw fa-table"></i>

                    <span>Repair</span></a>

            </li>

            <!-- Nav Item - Charts -->

            <!--

            </li> -->

            <!-- Nav Item - Charts -->

            <li class="nav-item">

                <a class="nav-link" href="scrap.php">

                    <i class="fas fa-fw fa-chart-area"></i>

                    <span>Scrap</span></a>

            </li>

            <!-- Divider -->

            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->

            <div class="text-center d-none d-md-inline">

                <button class="rounded-circle border-0" id="sidebarToggle"></button>

            </div>

        </ul>

        <!-- End of Sidebar -->

        <!-- Content Wrapper -->

        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->

            <div id="content">

                <!-- Topbar -->

                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->

                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">

                        <i class="fa fa-bars"></i>

                    </button>

                    <!-- Topbar Search -->

                    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">

                        <div class="input-group">

                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

                            <div class="input-group-append">

                                <button class="btn btn-primary" type="button">

                                    <i class="fas fa-search fa-sm"></i>

                                </button>

                            </div>

                        </div>

                    </form>

                    <!-- Topbar Navbar -->

                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->

                        <li class="nav-item dropdown no-arrow d-sm-none">

                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <i class="fas fa-search fa-fw"></i>

                            </a>

                            <!-- Dropdown - Messages -->

                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">

                                <form class="form-inline mr-auto w-100 navbar-search">

                                    <div class="input-group">

                                        <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

                                        <div class="input-group-append">

                                            <button class="btn btn-primary" type="button">

                                                <i class="fas fa-search fa-sm"></i>

                                            </button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </li>

                        <!-- Nav Item - Alerts -->



                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->

                        <li class="nav-item dropdown no-arrow">

                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['login']; ?></span>

                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">

                            </a>

                            <!-- Dropdown - User Information -->

                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">

                                <div class="dropdown-divider"></div>

                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">

                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>

                                    Logout

                                </a>

                            </div>

                        </li>

                    </ul>

                </nav>

                <!-- End of Topbar -->

                <!-- Begin Page Content -->

                <div class="container-fluid">

                    <!-- Page Heading -->

                    <div class="d-sm-flex align-items-center justify-content-between mb-4">

                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>

                        <a href="Generate Report har.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>

                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->

                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">

                            <div class="col-xl-3 col-md-6 mb-4">

                                <div class="card border-left-primary shadow h-100 py-2">

                                    <div class="card-body">

                                        <div class="row no-gutters align-items-center">

                                            <div class="col mr-2">

                                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">

                                                    Components Worth</div>

                                                <div class="h5 mb-0 font-weight-bold text-gray-800">₹<?php echo $sum_hardware; ?></div>

                                            </div>

                                            <div class="col-auto">

                                                <i class="fas fa-calendar fa-2x text-gray-300"></i>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </button>

                        <div id="collapseOne" class="accordion-collapse collapse " aria-labelledby="headingOne" data-bs-parent="#accordionExample">

                            <div class="accordion-body">

                                <strong>The sum total of the components across each lab is worth ₹<?php echo $sum_hardware; ?></strong>



                            </div>

                        </div>

                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">

                            <div class="col-xl-3 col-md-6 mb-4">

                                <div class="card border-left-primary shadow h-100 py-2">

                                    <div class="card-body">

                                        <div class="row no-gutters align-items-center">

                                            <div class="col mr-2">

                                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">

                                                    SOFTWARE WORTH</div>

                                                <div class="h5 mb-0 font-weight-bold text-gray-800">₹<?php echo $sum_software; ?></div>

                                            </div>

                                            <div class="col-auto">

                                                <i class="fas fa-calendar fa-2x text-gray-300"></i>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </button>

                        <div id="collapseOne" class="accordion-collapse collapse " aria-labelledby="headingOne" data-bs-parent="#accordionExample">

                            <div class="accordion-body">

                                <strong>The sum total of the Software across each lab is worth ₹<?php echo $sum_software; ?></strong>



                            </div>

                        </div>

                        

                        <!-- Earnings (Monthly) Card Example -->


                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">

                            <!-- Earnings (Annual) Card Example -->

                            <div class="col-xl-3 col-md-6 mb-4">

                                <div class="card border-left-success shadow h-100 py-2">

                                    <div class="card-body">

                                        <div class="row no-gutters align-items-center">

                                            <div class="col mr-2">

                                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">

                                                    LAB</div>

                                                <div class="h5 mb-0 font-weight-bold text-gray-800">₹<?php echo $sum_hardware + $sum_software; ?></div>

                                            </div>

                                            <div class="col-auto">

                                                <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </button>

                        <div id="collapseFour" class="accordion-collapse collapse " aria-labelledby="headingFour" data-bs-parent="#accordionExample">

                            <div class="accordion-body">

                                <strong>This is the cost of individual labs:</strong>

                                <table border="1">

                                    <tr>

                                        <th>Lab No</th>

                                        <th>Lab Name</th>

                                        <th>Total Cost </th>

                                    </tr>

                                    <tr>

                                        <th>Lab No.601</th>

                                        <th>Basic Electronics and PCB Lab</th>

                                        <th>₹<?php echo $sum_lab601_hard + $sum_lab601_soft; ?></th>

                                    </tr>

                                    <tr>

                                        <th>Lab No.602</th>

                                        <th>Analog and Digital Communication Lab</th>

                                        <th>₹<?php echo $sum_lab602_hard + $sum_lab602_soft; ?></th>

                                    </tr>

                                    <tr>

                                        <th>Lab No.603</th>

                                        <th>RF Communication Lab</th>

                                        <th>₹<?php echo $sum_lab603_hard + $sum_lab603_soft; ?></th>

                                    </tr>

                                    <tr>

                                        <th>Lab No.604</th>

                                        <th>Microwave and Satellite Communication Lab</th>

                                        <th>₹<?php echo $sum_lab604_hard + $sum_lab604_soft; ?></th>

                                    </tr>

                                    <tr>

                                        <th>Lab No.605</th>

                                        <th>Microcontoller and Microprocessor Lab</th>

                                        <th>₹<?php echo $sum_lab605_hard + $sum_lab605_soft; ?></th>

                                    </tr>

                                    <tr>

                                        <th>Lab No.701</th>

                                        <th>Software Simulation and Networking Lab</th>

                                        <th>₹<?php echo $sum_lab701_hard + $sum_lab701_soft; ?></th>

                                    </tr>

                                    <tr>

                                        <th>Lab No.703</th>

                                        <th>Signal Processing Lab</th>

                                        <th>₹<?php echo $sum_lab703_hard + $sum_lab703_soft; ?></th>

                                    </tr>

                                    <tr>

                                        <th>Lab No.709</th>

                                        <th>Project Lab</th>

                                        <th>₹<?php echo $sum_lab709_hard + $sum_lab709_soft; ?></th>

                                    </tr>

                                </table>

                            </div>

                        </div>

                        <!-- Pending Requests Card Example -->

                        <!--     <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">-->

                        <!--    <div class="col-xl-3 col-md-6 mb-4">-->

                        <!--        <div class="card border-left-warning shadow h-100 py-2">-->

                        <!--            <div class="card-body">-->

                        <!--                <div class="row no-gutters align-items-center">-->

                        <!--                    <div class="col mr-2">-->

                        <!--                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">-->

                        <!--                            Pending Requests</div>-->

                        <!--                        <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>-->

                        <!--                    </div>-->

                        <!--                    <div class="col-auto">-->

                        <!--                        <i class="fas fa-comments fa-2x text-gray-300"></i>-->

                        <!--                    </div>-->

                        <!--                </div>-->

                        <!--            </div>-->

                        <!--        </div>-->

                        <!--    </div>-->

                        <!--</div>-->

                        <!--</button>-->

                        <!--                <div id="collapseThree" class="accordion-collapse collapse " aria-labelledby="headingThree" data-bs-parent="#accordionExample">-->

                        <!--  <div class="accordion-body">-->

                        <!--    <strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.-->

                        <!--  </div>-->

                        <!--</div>-->

                        <!-- Content Row -->

                        <div class="row">

                            <!-- Area Chart -->

                            <!-- <div class="col-xl-8 col-lg-7">

                            <div class="card shadow mb-4">

                                Card Header - Dropdown -->

                            <!-- <div

                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">

                                    <h6 class="m-0 font-weight-bold text-primary">Expenditure Overview</h6>

                                    <div class="dropdown no-arrow">

                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"

                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>

                                        </a>

                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"

                                            aria-labelledby="dropdownMenuLink">

                                            <div class="dropdown-header">Dropdown Header:</div>

                                            <a class="dropdown-item" href="#">Action</a>

                                            <a class="dropdown-item" href="#">Another action</a>

                                            <div class="dropdown-divider"></div>

                                            <a class="dropdown-item" href="#">Something else here</a>

                                        </div>

                                    </div>

                                </div>

                                Card Body -->

                            <!-- <div class="card-body">

                                    <div class="chart-area">

                                        <canvas id="myAreaChart"></canvas>

                                    </div>

                                </div>

                            </div>

                        </div> -->

                            <!-- Pie Chart -->

                            <!-- <div class="col-xl-4 col-lg-5">

                            <div class="card shadow mb-4">

                                <!-- Card Header - Dropdown -->

                            <!-- <div

                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">

                                    <h6 class="m-0 font-weight-bold text-primary">Revenue Sources</h6>

                                    <div class="dropdown no-arrow">

                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"

                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>

                                        </a>

                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"

                                            aria-labelledby="dropdownMenuLink">

                                            <div class="dropdown-header">Dropdown Header:</div>

                                            <a class="dropdown-item" href="#">Action</a>

                                            <a class="dropdown-item" href="#">Another action</a>

                                            <div class="dropdown-divider"></div>

                                            <a class="dropdown-item" href="#">Something else here</a>

                                        </div>

                                    </div>

                                </div> -->

                            <!-- Card Body -->

                            <!-- <div class="card-body">

                                        <div class="chart-pie pt-4 pb-2">

                                            <canvas id="myPieChart"></canvas>

                                        </div>

                                        <div class="mt-4 text-center small">

                                            <span class="mr-2">

                                                <i class="fas fa-circle text-primary"></i> Direct

                                            </span>

                                            <span class="mr-2">

                                                <i class="fas fa-circle text-success"></i> Social

                                            </span>

                                            <span class="mr-2">

                                                <i class="fas fa-circle text-info"></i> Referral

                                            </span>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div> -->

                            <!-- Content Row -->

                            <div class="row">

                                <!-- Content Column -->

                                <div class="col-lg-6 mb-4">

                                    <!-- Project Card Example

                            <div class="card shadow mb-4">

                                <div class="card-header py-3">

                                    <h6 class="m-0 font-weight-bold text-primary">Projects</h6>

                                </div>

                                <div class="card-body">

                                    <h4 class="small font-weight-bold">Server Migration <span

                                            class="float-right">20%</span></h4>

                                    <div class="progress mb-4">

                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 20%"

                                            aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>

                                    </div>

                                    <h4 class="small font-weight-bold">Sales Tracking <span

                                            class="float-right">40%</span></h4>

                                    <div class="progress mb-4">

                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 40%"

                                            aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>

                                    </div>

                                    <h4 class="small font-weight-bold">Customer Database <span

                                            class="float-right">60%</span></h4>

                                    <div class="progress mb-4">

                                        <div class="progress-bar" role="progressbar" style="width: 60%"

                                            aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>

                                    </div>

                                    <h4 class="small font-weight-bold">Payout Details <span

                                            class="float-right">80%</span></h4>

                                    <div class="progress mb-4">

                                        <div class="progress-bar bg-info" role="progressbar" style="width: 80%"

                                            aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>

                                    </div>

                                    <h4 class="small font-weight-bold">Account Setup <span

                                            class="float-right">Complete!</span></h4>

                                    <div class="progress">

                                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%"

                                            aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>

                                    </div>

                                </div>

                            </div> -->

                                    <!-- Color System

                            <div class="row">

                                <div class="col-lg-6 mb-4">

                                    <div class="card bg-primary text-white shadow">

                                        <div class="card-body">

                                            Primary

                                            <div class="text-white-50 small">#4e73df</div>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-lg-6 mb-4">

                                    <div class="card bg-success text-white shadow">

                                        <div class="card-body">

                                            Success

                                            <div class="text-white-50 small">#1cc88a</div>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-lg-6 mb-4">

                                    <div class="card bg-info text-white shadow">

                                        <div class="card-body">

                                            Info

                                            <div class="text-white-50 small">#36b9cc</div>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-lg-6 mb-4">

                                    <div class="card bg-warning text-white shadow">

                                        <div class="card-body">

                                            Warning

                                            <div class="text-white-50 small">#f6c23e</div>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-lg-6 mb-4">

                                    <div class="card bg-danger text-white shadow">

                                        <div class="card-body">

                                            Danger

                                            <div class="text-white-50 small">#e74a3b</div>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-lg-6 mb-4">

                                    <div class="card bg-secondary text-white shadow">

                                        <div class="card-body">

                                            Secondary

                                            <div class="text-white-50 small">#858796</div>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-lg-6 mb-4">

                                    <div class="card bg-light text-black shadow">

                                        <div class="card-body">

                                            Light

                                            <div class="text-black-50 small">#f8f9fc</div>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-lg-6 mb-4">

                                    <div class="card bg-dark text-white shadow">

                                        <div class="card-body">

                                            Dark

                                            <div class="text-white-50 small">#5a5c69</div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-lg-6 mb-4">

                            Illustrations -->

                                    <!-- <div class="card shadow mb-4">

                                <div class="card-header py-3">

                                    <h6 class="m-0 font-weight-bold text-primary">Illustrations</h6>

                                </div>

                                <div class="card-body">

                                    <div class="text-center">

                                        <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;"

                                            src="img/undraw_posting_photo.svg" alt="...">

                                    </div>

                                    <p>Add some quality, svg illustrations to your project courtesy of <a

                                            target="_blank" rel="nofollow" href="https://undraw.co/">unDraw</a>, a

                                        constantly updated collection of beautiful svg images that you can use

                                        completely free and without attribution!</p>

                                    <a target="_blank" rel="nofollow" href="https://undraw.co/">Browse Illustrations on

                                        unDraw &rarr;</a>

                                </div>

                            </div> -->

                                    <!-- Approach -->

                                    <!-- <div class="card shadow mb-4">

                                <div class="card-header py-3">

                                    <h6 class="m-0 font-weight-bold text-primary">Development Approach</h6>

                                </div>

                                <div class="card-body">

                                    <p>SB Admin 2 makes extensive use of Bootstrap 4 utility classes in order to reduce

                                        CSS bloat and poor page performance. Custom CSS classes are used to create

                                        custom components and custom utility classes.</p>

                                    <p class="mb-0">Before working with this theme, you should become familiar with the

                                        Bootstrap framework, especially the utility classes.</p>

                                </div>

                            </div>

                        </div>

                    </div>

                </div> -->

                                    <!-- /.container-fluid -->

                                </div>

                                <!-- End of Main Content -->

                                <!-- Footer -->

                                <!-- <footer class="sticky-footer bg-white">

                <div class="container my-auto">

                    <div class="copyright text-center my-auto">

                        <span>Copyright &copy; Your Website 2021</span>

                    </div>

                </div>

            </footer> -->

                                <!-- End of Footer -->

                            </div>

                            <!-- End of Content Wrapper -->

                        </div>

                        <!-- End of Page Wrapper -->
                        <?php include 'footer.php' ?>
                        <br>

                        <!-- Scroll to Top Button-->

                        <a class="scroll-to-top rounded" href="#page-top">

                            <i class="fas fa-angle-up"></i>

                        </a>

                        <!-- Logout Modal-->

                        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

                            <div class="modal-dialog" role="document">

                                <div class="modal-content">

                                    <div class="modal-header">

                                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>

                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">

                                            <span aria-hidden="true">×</span>

                                        </button>

                                    </div>

                                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>

                                    <div class="modal-footer">

                                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>

                                        <a class="btn btn-primary" href="logout.php">Logout</a>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <!-- Bootstrap core JavaScript-->

                        <script src="vendor/jquery/jquery.min.js"></script>

                        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                        <!-- Core plugin JavaScript-->

                        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

                        <!-- Custom scripts for all pages-->

                        <script src="js/sb-admin-2.min.js"></script>

                        <!-- Page level plugins -->

                        <script src="vendor/chart.js/Chart.min.js"></script>

                        <!-- Page level custom scripts -->

                        <script src="js/demo/chart-area-demo.js"></script>

                        <script src="js/demo/chart-pie-demo.js"></script>

                        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

                        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>

                        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>

</body>

</html>