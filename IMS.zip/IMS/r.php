<?php
/****************************************************************************/
// Enter The Required Data Here
/****************************************************************************/
	$connection = new mysqli("localhost","id15573716_admin","Zylox@135pass","id15573716_labm");
	if($conn->connect_error)
	{
		die("connection failed: " . $conn->connect_error());
	}
	// Your Connection Query Variable
	$TableName= 'items'; // Define Your Table Name
	$xls_filename = 'YourFileName.xls'; // Define Excel (.xls) file name
	$downloadQuery = "SELECT * FROM $TableName";
$result = mysqli_query($connection,$downloadQuery);
if(!$result){
// Error Reporting Message To User
echo "<div class='alert alert-danger'>ERROR # '".mysqli_errno($connection)."' | ERROR: '".mysqli_error($connection)."'. ".exe_contactUs()."</div>";
exit();
die();
} else {
// Header Info Settings
header("Content-Type: application/xls");
header("Content-Disposition: attachment; filename=$xls_filename");
header("Pragma: no-cache");
header("Expires: 0");
/***** Start of Formatting for Excel *****/
// Define separator (defines columns in excel &amp; tabs in word)
$sep = "\t"; // tabbed character
// Start of printing column names as names of MySQL fields
for ($i = 0; $i<mysqli_num_fields($result); $i++) {
echo mysqli_fetch_field_direct($result, $i)->name . "\t";
}
echo "\n";
// End of printing column names
// Start while loop to get data
while($row = mysqli_fetch_array($result)){
//array_walk($row, __NAMESPACE__ . '\cleanData'); // UnComment To Stop Auto Formatting Of Data For Excel XLS Format
$schema_insert = "";
for($j=0; $j<mysqli_num_fields($result); $j++){
if(!isset($row[$j])) {
$schema_insert .= "NULL".$sep;
}
elseif ($row[$j] != "") {
$schema_insert .= "$row[$j]".$sep;
}
else {
$schema_insert .= "".$sep;
}
}
$schema_insert = str_replace($sep."$", "", $schema_insert);
$schema_insert = preg_replace("/\r\n|\n\r|\n|\r/", " ", $schema_insert);
$schema_insert .= "\t";
echo trim($schema_insert);
echo "\n";
}
}
/****************************************************************************/
// Stop Auto Formatting Of Data For Excel XLS Format (Not Important, On Demand)
/****************************************************************************/
function cleanData(&$str) {
// escape tab characters
$str = preg_replace("/\t/", "\\t", $str);
// escape new lines
$str = preg_replace("/\r?\n/", "\\n", $str);
// convert 't' and 'f' to boolean values
if($str == 't') $str = 'TRUE';
if($str == 'f') $str = 'FALSE';
// force certain number/date formats to be imported as strings
if(preg_match("/^0/", $str) || preg_match("/^\+?\d{8,}$/", $str) || preg_match("/^\d{4}.\d{1,2}.\d{1,2}/", $str)) {
$str = "'$str";
}
// escape fields that include double quotes
if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
}
?>