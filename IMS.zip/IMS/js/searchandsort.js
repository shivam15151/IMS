function search(allDataContent, uniqueID , using, searchBoxID) {

     /*

        Arguments:

        -- allDataContent: Data fetched from database

        -- uniqueID: unique data of table content.

        -- using: field on which we are applying sorting

        -- searchBoxID: ID of search box to get entered value

        -- search(allDataContent,'gi_no', 'description', this.value)

    */



    var value = document.getElementById(searchBoxID).value; 



    var tableHeading = document.getElementById("tableHeadings");

    tableHeading.style.display = "none";

    



    for(var i = 0; i < allDataContent.length; i++) {

        var element = document.getElementById("rowID"+allDataContent[i][uniqueID]);

        if(value && allDataContent[i][using].includes(value)) {



            tableHeading.style.display = "block";

            element.style.display = "block";

        } else if(value){

            tableHeading.style.display = "block";

            element.style.display = "none";

        } else {

            tableHeading.style.display = "block";

            element.style.display = "block";

        }

    }

}











function sort(allDataContent, sortBy, uniqueID, numColumns, allIDs, allFieldsName, links, ascORdec=true) {

     /*

        Arguments:

        -- allDataContent: Data fetched from database

        -- sortBy: field data used for sorting.

        -- numColumns: used for looping

        -- ascORdec: sorting in ascending order or descending order

    */

   var tempData = allDataContent;



    if (ascORdec) {

        if(isNaN(tempData[0][sortBy])) {

            // sortBy conatains string

            tempData.sort(function(a, b){

                let x = a.type.toLowerCase();

                let y = b.type.toLowerCase();

                if (x < y) {return -1;}

                if (x > y) {return 1;}

                return 0;

            });

        } else {

            // sortBy contains number

            tempData.sort(function(firstValue, secondValue){return firstValue[sortBy] - secondValue[sortBy]});

        }



    } else {

        // Reversed Sorting.

        if(isNaN(tempData[0][sortBy])) {

            // sortBy conatains string

            tempData.sort(function(a, b){

                let x = a.type.toLowerCase();

                let y = b.type.toLowerCase();

                if (x < y) {return 1;}

                if (x > y) {return -1;}

                return 0;

            });

        } else {

            // sortBy contains number

            tempData.sort(function(firstValue, secondValue){return secondValue[sortBy] - firstValue[sortBy]});

        }

    }



    for(var i = 0; i < tempData.length; i++) {

        console.log(tempData[i]);



        for (var j = 0; j < numColumns; j++) {

            if(j == 0) {

                continue;

            }

            if(j == numColumns - 4) {

                document.getElementById(allIDs[i][j]).href = links[i][0];

                continue;

            } else if (j == numColumns - 2 ) {

                document.getElementById(allIDs[i][j]).href = links[i][1];

                continue;

            } else if(j == numColumns - 1)  {

                document.getElementById(allIDs[i][j]).href = links[i][2];

                continue;

            }

            document.getElementById(allIDs[i][j]).innerHTML = tempData[i][allFieldsName[j - 1]];

        }

    }



}