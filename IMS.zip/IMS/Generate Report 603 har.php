
<?php  
include('connect.php');

session_start();

if (! (isset ( $_SESSION ['login'] ))) {

    header ( 'location:index.php' );



}
$sql = "SELECT * FROM `items` WHERE `lab_no` like '%603%'";

$result = $conn->query($sql);

$allData = array();

if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        $allData[] = $row;

    }

}
$counter = 0;

?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div class="printable_area">
<table>
<h1>Inventory Management System  Lab:603</h1>
<h2>Hardware Inventory</h2>

<style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
    
<thread>
<th style="width:80px;"><b>Sr. No. </th>

                                <th style="width:150px;">Lab</th>

                                <th style="width:200px;">Description</th>

                                <th style="width:100px;">Quantity</th>

                                <th style="width:150px;">Equipment Serial No.</th>

                                <th style="width:150px;">College Code</th>

                                <th style="width:200px;">Supplier / Manufacturer</th>

                               

                                <th style="width:150px;">Invoice</th>

                                <th style="width:150px;">Challan</th>

                                <th style="width:200px;">Date of Purchase </th>

                                <th style="width:200px;">Gl No.</th>

                                <th style="width:100px;">Rate</th>

                                <th style="width:100px;">Discount</th>

                                <th style="width:150px;">Discounted Rate</th>

                                <th style="width:200px;">VAT/MST/CGST/SGST</th>

                                <th style="width:200px;">Rate with Vat</th>

                                <th style="width:150px;">Octri</th>

                                <th style="width:200px;">Rate with Octri</th>

                                <th style="width:200px;">Lab_in_Charge_Name</th>

                                <th style="width:200px;">Name_of_HOD</th>

                                <th style="width:150px;">Total Cost</th>

</thread>
<tbody>
    <?php
    if (sizeof($allData) > 0) {
        for ($i = 0; $i < sizeof($allData); $i++) {
            $row = $allData[$i]; // Get the specific row data
            ?>
<tr>
    <td style="text-align: center;"><?php echo ++$counter; ?></td>

    <td style="text-align: center;"><?php echo $row["lab_no"]; ?></td>

    <td style="text-align: center;"><?php echo $row["description"]; ?></td>

    <td style="text-align: center;"><?php echo $row["quantity"]; ?></td>

    <td style="text-align: center;"><?php echo $row["equipment no"]; ?></td>

    <td style="text-align: center;"><?php echo $row["college code"]; ?></td>

    <td style="text-align: center;"><?php echo $row["manufacturer"]; ?></td>

    <td style="text-align: center;"><?php echo $row["invoice"]; ?></td>

    <td style="text-align: center;"><?php echo $row["challan_no"]; ?></td>

    <td style="text-align: center;"><?php echo $row["date"]; ?></td>

    <td style="text-align: center;"><?php echo$row["gi_no"]; ?></td>

    <td style="text-align: center;"><?php echo $row["rate"]; ?></td>

    <td style="text-align: center;"><?php echo $row["discount"]; ?></td>

    <td style="text-align: center;"><?php echo $row["discounted rate"]; ?></td>

    <td style="text-align: center;"><?php echo $row["vat"]; ?></td>

    <td style="text-align: center;"><?php echo $row["rate with vat"]; ?></td>

    <td style="text-align: center;"><?php echo $row["octri"]; ?></td>

    <td style="text-align: center;"><?php echo $row["rate_with_octri"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Lab_in_Charge_Name"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Name_of_HOD"]; ?></td>

    <td style="text-align: center;"><?php echo $row["total_cost"]; ?></td>
</tr>
<?php

}

}

?>
</tbody>
</table>
</div>
</body>
</html>


<!-- Include jspdf library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.3/jspdf.umd.min.js"></script>

<script>
    const generatePDF = () => {
        const doc = new jsPDF();
        const printable_area = document.querySelector(".printable_area");
        const options = {
            margin: {
                top: 20,
                bottom: 20,
                left: 10,
                right: 10
            }
        };

        doc.fromHTML(printable_area, options);
        window.open(URL.createObjectURL(doc.output("blob")), "_blank");

        // Print the PDF directly
        setTimeout(() => {
            window.print();
        }, 1000); // You can adjust the delay (milliseconds) as needed
    };
    
</script>
<script>setTimeout(() => {
            window.print();
        }, 1000);</script>