<?php

include('connect.php');

session_start();

if (! (isset ( $_SESSION ['login'] ))) {

	header ( 'location:index.php' );

}

$sql = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 606:Basic Electronic Engineering Lab'";

$result = $conn->query($sql);

$counter = 0;

?>

<!doctype html>

<html lang="en">

  <head>

    <meta charset="utf-8">

    <style type="text/css">.disclaimer { display: none; }</style><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="title icon" href="images/title-img.png">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-xymdQtn1n3lH2wcu0qhcdaOpQwyoarkgLVxC/wZ5q7h9gHtxICrpcaSUfygqZGOe" crossorigin="anonymous"></script>

    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

    <link rel="stylesheet" href="style.css">

    <title>Inventory</title>

  </head>

  <body>

    <!-- navbar -->

    <nav class="navbar navbar-expand-md navbar-light">

      <button class="navbar-toggler ml-auto mb-2 bg-light" type="button" data-toggle="collapse" data-target="#myNavbar">

        <span class="navbar-toggler-icon"></span>

      </button>

      <div class="collapse navbar-collapse" id="myNavbar">

        <div class="container-fluid">

          <div class="row">

            <!-- sidebar -->

             <div class="col-xl-2 col-lg-3 col-md-4 sidebar fixed-top">

              <a href="#" class="navbar-brand text-white d-block mx-auto text-center py-3 mb-4 bottom-border"> </a>

              <div class="bottom-border pb-3">

                <img src="somlogo.png" width="50" class="rounded-circle mr-3">

                <a href="#" class="text-white"><?php echo $_SESSION['login']; ?></a>

              </div>

              <ul class="navbar-nav flex-column mt-4">

                <li class="nav-item"><a href="dashboard.php" class="nav-link text-white p-3 mb-2 "><i class="fas fa-home text-light fa-lg mr-3"></i>Dashboard</a></li>

                <li class="nav-item"><a href="profile.php" class="nav-link text-white p-3 mb-2 sidebar-link"><i class="fas fa-user text-light fa-lg mr-3"></i>Profile</a></li>

                <li class="nav-item"><a href="add item.php" class="nav-link text-white p-3 mb-2 sidebar-link"><i class="fas fa-shopping-cart text-light fa-lg mr-3"></i>Add Item</a></li>

              <!-- <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 current sidebar-link"><i class="far fa-address-card fa-lg mr-3"></i>Add Items</a></li> -->

                <li class="nav-item"><a href="room.php" selected class="nav-link text-white p-3 mb-2 current sidebar-link"><i class="fas fa-door-open text-light fa-lg mr-3"></i>Room</a></li>

                <li class="nav-item"><a href="hardware inv.php" class="nav-link text-white p-3 mb-2  sidebar-link"><i class="fas fa-database text-light fa-lg mr-3"></i>Inventory</a></li>

                <li class="nav-item"><a href="defective.php" class="nav-link text-white p-3 mb-2 sidebar-link"><i class="fas fa-trash-alt text-light fa-lg mr-3"></i>Defectives</a></li>

                <li class="nav-item"><a href="repair.php" class="nav-link text-white p-3 mb-2 sidebar-link"><i class="fas fa-wrench text-light fa-lg mr-3"></i>Repair/Calibrate</a></li>

                 <li class="nav-item"><a href="borrower.php" class="nav-link text-white p-3 mb-2 sidebar-link"><i class="fas fa-handshake text-light fa-lg mr-3"></i>Borrower</a></li> 

                 <li class="nav-item"><a href="scrap.php" class="nav-link text-white p-3 mb-2 sidebar-link"><i class="fa fa-trash text-light fa-lg mr-3"></i>Scrap</a></li>

                <!-- <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link"><i class="fas fa-table text-light fa-lg mr-3"></i>Tables</a></li>

                <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link"><i class="fas fa-wrench text-light fa-lg mr-3"></i>Settings</a></li>

                <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link"><i class="fas fa-file-alt text-light fa-lg mr-3"></i>Documentation</a></li> -->

              </ul>

            </div>

            <!-- end of sidebar -->

            <!-- top-nav -->

             <div class="col-xl-10 col-lg-9 col-md-8 ml-auto bg-dark fixed-top py-2 top-navbar">

              <div class="row align-items-center">

                <div class="col-md-4">

                  <h3 class="text-light text-uppercase mb-0">Lab Management</h4>

                </div>

               <!-- <div class="col-md-5">

                  <form>

                    <div class="input-group">

                      <input type="text" class="form-control search-input" placeholder="Search...">

                      <button type="button" class="btn btn-white search-button"><i class="fas fa-search text-danger"></i></button>

                    </div>

                  </form>

                </div>-->

               <!-- <div class="col-md-4">

                  <ul class="navbar-nav">

                    <li class="nav-item icon-parent"><a href="#" class="nav-link icon-bullet"><i class="fas fa-comments text-muted fa-lg"></i></a></li>

                    <div class="nav-item icon-parent"><a href="#" class="nav-link icon-bullet"><i class="fas fa-bell text-muted fa-lg"></i></a>-->

                    <div class="nav-item ml-auto"><a href="logout.php" class="nav-link" ><i class="fas fa-sign-out-alt text-danger fa-lg"></i></a>

                  

                </div>

              </div>

            </div>

            <!-- end of top-nav -->

          </div>

        </div>

      </div>

    </nav>

    <!-- end of navbar -->

    <div class="dropdown"  style="margin-top: 4%;margin-left: 20%;">

  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

    Inventory

  </button>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

    <a class="dropdown-item" selected href="606_har_inv.php">Hardware Inventory</a>

    <a class="dropdown-item" href="606_sof_inv.php">Software Inventory</a>

    

  </div>

</div>

<br>
<?php
include 'navigation.php';
?>
<br>

                

                <div class="table-responsive" style="margin:0 auto; width:90%; overflow:auto; height:80%;">

                    <form>

                        <table class="table table-light table-bordered" id="table" style="background-color: white;box-shadow: 2px 2px 2px #999;">

                            <tr style="text-align: center;">

                               

                                <th>Sr. no.</th>

                                <th>Lab</th>

                                <th>Description</th>

                                <th>Quantity</th>

                                <th>Equipment Serial No.</th>

                                <th>College Code</th>

                                <th>Supplier / Manufacturer</th>

                               

                                <th>Invoice</th>

                                <th>Challan</th>

                                <th>Date of Purchase </th>

                                <th>Gl No.</th>

                                <th>Rate</th>

                                <th>Discount</th>

                                <th>Discounted Rate</th>

                                <th>VAT/MST/CGST/SGST</th>

                                <th>Rate with Vat</th>

                                <th>Octri</th>

                                <th>Rate with Octri</th>

                                <th>Lab_in_Charge_Name</th>

                                <th>Name_of_HOD</th>

                                <th>Total Cost</th>

                                <th>Image / PDF</th>

                                <th>Working Status</th>

                                <th>Action</th>

                            </tr>

                            <?php

                                    if ($result->num_rows > 0) {

                                        while ($row = $result->fetch_assoc()) {

                                    ?> 

                            <tr>

                                 <td style="text-align: center;"><?php echo ++$counter; ?></td>

                                 <td style="text-align: center;"><?php echo $row["lab_no"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["description"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["quantity"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["equipment no"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["college code"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["manufacturer"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["invoice"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["challan_no"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["date"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["gi_no"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["rate"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["discount"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["discounted rate"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["vat"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["rate with vat"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["octri"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["rate_with_octri"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["Lab_in_Charge_Name"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["Name_of_HOD"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["total_cost"]; ?></td>

                                 <td style="text-align: center;"><a href="<?php echo $row['path']; ?>">view</a></td>

                                 <td style="text-align: center;"><?php echo $row["defective"]; ?></td>

                                 <td style="text-align: center;">

                                    <a href="edit_item.php?id=<?php echo $row['id'] ?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                    <a href="del hardware.php?id=<?php echo $row['id'] ?>"><i class="fa fa-trash"></i>

                                </td>

                                </td>

                            </tr>

                    <?php

                                        }

                                    }

                    ?>

                        </table>

                        <!--<div class="text-center">

            <a href="user_data_print.php" class="btn btn-primary"></a> 

        </div>-->

                    </form>

                </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script src="script.js"></script>

  </body>

</html>