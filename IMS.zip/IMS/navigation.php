<?php


echo('<nav class="navbar navbar-expand-lg navbar-light bg-light"> ');
// echo('  <a class="navbar-brand" href="#">Navbar</a>');
// echo('  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">');
// echo('    <span class="navbar-toggler-icon"></span>');
// echo('  </button>');
echo('  <div class="collapse navbar-collapse" id="navbarNav">');
echo('    <ul class="navbar-nav">');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="601_har_inv.php">Lab 601 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="602_har_inv.php">Lab 602 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="603_har_inv.php">Lab 603 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="604_har_inv.php">Lab 604 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="605_har_inv.php">Lab 605 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="701_har_inv.php">Lab 701 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="703_har_inv.php">Lab 703 <span class="sr-only">(current)</span></a>');
echo('      </li>');
echo('      <li class="nav-item active">');
echo('        <a class="nav-link" href="709_har_inv.php">Lab 709 <span class="sr-only">(current)</span></a>');
echo('      </li>');
// echo('      <li class="nav-item">');
// echo('        <a class="nav-link" href="#">Features</a>');
// echo('      </li>');
// echo('      <li class="nav-item">');
// echo('        <a class="nav-link" href="#">Pricing</a>');
// echo('      </li>');
// echo('      <li class="nav-item">');
// echo('        <a class="nav-link disabled" href="#">Disabled</a>');
// echo('      </li>');
echo('    </ul>');
echo('  </div>');
echo('</nav>');
?>