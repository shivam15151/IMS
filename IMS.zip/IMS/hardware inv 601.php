<?php

include('connect.php');

session_start();

if (! (isset ( $_SESSION ['login'] ))) {

    header ( 'location:index.php' );



}

$sql = "SELECT * FROM `items` WHERE `lab_no` like '%601%'";

$result = $conn->query($sql);

$allData = array();

if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        $allData[] = $row;

    }

}





$counter = 0;

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <style type="text/css">.disclaimer { display: none; }</style><meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="">

    <meta name="author" content="">

    <title> IMS </title>

    <!-- Custom fonts for this template-->

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-xymdQtn1n3lH2wcu0qhcdaOpQwyoarkgLVxC/wZ5q7h9gHtxICrpcaSUfygqZGOe" crossorigin="anonymous"></script>


    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->

    <link href="css/sb-admin-2.min.css" rel="stylesheet">

          <link href="bg-color.css" rel="stylesheet">

</head>

    <script src="js\searchandsort.js"></script>

    <script>

        let allIds = [];

        let rowIds = [];

        let allFieldsName = [];

        let links = [];

        let tempLinks = [];

    </script>

</head>

<body id="page-top">



    <!-- Page Wrapper -->

    <div id="wrapper">

        <!-- Sidebar -->

        <!-- Sidebar -->

        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->

            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">

                <div class="sidebar-brand-icon rotate-n-15">

                    <i class="#"></i>

                </div>

                <div class="sidebar-brand-text mx-3"><?php echo $_SESSION['login']; ?></div>

            </a>

            <!-- Divider -->

            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->

            <li class="nav-item active">

                <a class="nav-link" href="dashboard.php">

                    <i class="fas fa-fw fa-tachometer-alt"></i>

                    <span>Dashboard</span></a>

            </li>

            <!-- Divider -->

            <hr class="sidebar-divider">

            <!-- Nav Item - Utilities Collapse Menu -->

            <li class="nav-item">

                <a class="nav-link" href="profile.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Profile</span>

                </a>

            <li class="nav-item">

                <a class="nav-link" href="add item.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Add Items</span>

                </a>

            <li class="nav-item">

                <a class="nav-link" href="room.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Room</span>

                </a>

            <li class="nav-item">

                <a class="nav-link" href="hardware inv.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Inventory</span>

                </a>

                <!-- Divider -->

                <hr class="sidebar-divider">

                <!-- Nav Item - Charts -->

            <li class="nav-item">

                <a class="nav-link" href="defective.php">

                    <i class="fas fa-fw fa-chart-area"></i>

                    <span>Defectives</span></a>

            </li>

            <li class="nav-item">

                <a class="nav-link" href="borrower.php">

                    <i class="fa fa-users"></i>

                    <span>Borrower</span></a>

            </li>

            <!-- Nav Item - Tables -->

            <li class="nav-item">

                <a class="nav-link" href="repair.php">

                    <i class="fas fa-fw fa-table"></i>

                    <span>Repair</span></a>

            </li>

            

           

       

            <!-- Nav Item - Charts -->

            <li class="nav-item">

                <a class="nav-link" href="scrap.php">

                    <i class="fas fa-fw fa-chart-area"></i>

                    <span>Scrap</span></a>

            </li>

            <!-- Divider -->

            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->

            <div class="text-center d-none d-md-inline">

                <button class="rounded-circle border-0" id="sidebarToggle"></button>

            </div>

        </ul>

        <!-- End of Sidebar -->

        <!-- Content Wrapper -->

        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->

            <div id="content">

                <!-- Topbar -->

                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->

                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">

                        <i class="fa fa-bars"></i>

                    </button>

                    <!-- Topbar Search -->

                    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">

                        <div class="input-group">

                            <input id="searchBox" type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2" oninput="search(allDataContent,'gi_no','description', 'searchBox')">

                            <div class="input-group-append">

                                <button class="btn btn-primary" type="button" onclick="search(allDataContent,'gi_no','description', 'searchBox')">

                                    <i class="fas fa-search fa-sm"></i>

                                </button>

                            </div>

                        </div>

                    </form>

                    <!-- Topbar Navbar -->

                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->

                        <li class="nav-item dropdown no-arrow d-sm-none">

                            <a class="nav-link dropdown-toggle" href="hardware inv 601.php" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <i class="fas fa-search fa-fw"></i>

                            </a>

                            <!-- Dropdown - Messages -->

                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">

                                <form class="form-inline mr-auto w-100 navbar-search">

                                    <div class="input-group">

                                        <input id="searchBox1" type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2" oninput="search(allDataContent,'gi_no','description', 'searchBox1')">

                                        <div class="input-group-append">

                                            <button class="btn btn-primary" type="button" onclick="search(allDataContent,'gi_no','description', 'searchBox1')">

                                                <i class="fas fa-search fa-sm"></i>

                                            </button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </li>

                        <!-- Nav Item - Alerts -->

                        

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->

                         <li class="nav-item dropdown no-arrow">

                            <a class="nav-link dropdown-toggle" href="login.php" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['login']; ?></span>

                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">

                            </a>

                            <!-- Dropdown - User Information -->

                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">

                                <div class="dropdown-divider"></div>

                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">

                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>

                                    Logout

                                </a>

                            </div>

                        </li>

                    </ul>

                </nav>

                <!-- End of Topbar -->

                <!-- Begin Page Content -->

                  <div class="dropdown"  style="margin:0 auto;text-align: center;">

  <button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

    Inventory

  </button>

   <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

    <a class="dropdown-item" href="hardware inv 601.php">Hardware Inventory</a>

    <a class="dropdown-item" href="601_sof_inv.php">Software Inventory</a>

    

  </div>

</div>
<div class="container-fluid">

                    <!-- Page Heading -->

                    <div class="d-sm-flex align-items-center justify-content-between mb-4">

                        <a href="Generate Report 601 har.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>

                    </div>
<br>
<?php
include 'inventory_nav.php';
?>
<br>

                

                <div class="table-responsive" style="margin:0 auto; width:90%; overflow:auto; height:80%;">

                    <form>

                        <script>

                            allFieldsName.push("lab_no");

                            allFieldsName.push("description");

                            allFieldsName.push("quantity");

                            allFieldsName.push("equipment no");

                            allFieldsName.push("college code");

                            allFieldsName.push("manufacturer");

                            allFieldsName.push("invoice");

                            allFieldsName.push("challan_no");

                            allFieldsName.push("date");

                            allFieldsName.push("gi_no");

                            allFieldsName.push("rate");

                            allFieldsName.push("discount");

                            allFieldsName.push("discounted rate");

                            allFieldsName.push("vat");

                            allFieldsName.push("rate with vat");

                            allFieldsName.push("octri");

                            allFieldsName.push("rate_with_octri");

                            allFieldsName.push("Lab_in_Charge_Name");

                            allFieldsName.push("Name_of_HOD");

                            allFieldsName.push("total_cost");

                            allFieldsName.push("path");

                            allFieldsName.push("defective");

                            allFieldsName.push("id");

                            allFieldsName.push("id");

                        </script>

                        <table class="table table-light table-bordered" id="table" style="table-layout:fixed; width:3530px; background-color: white;box-shadow: 2px 2px 2px #999;">

            



                            <tr id="tableHeadings" style="text-align: center;">

                

                                <th style="width:80px;"><b>Sr. No. </th>

                                <th style="width:150px;">Lab</th>

                                <th style="width:200px;">Description

                                    <div>

                                        <input type="button" style="width:25px; height:25px;" value="&#8593;" onclick="sort(allDataContent, 'description', 'gi_no', 23,  allIds, allFieldsName, links)">

                                        <input type="button" style="width:25px; height:25px;" value="&#8595;" onclick="sort(allDataContent, 'description', 'gi_no', 23,  allIds, allFieldsName, links, false)">

                                    </div>

                                </th>

                                <th style="width:100px;">Quantity</th>

                                <th style="width:150px;">Equipment Serial No.</th>

                                <th style="width:150px;">College Code</th>

                                <th style="width:200px;">Supplier / Manufacturer</th>

                               

                                <th style="width:150px;">Invoice</th>

                                <th style="width:150px;">Challan</th>

                                <th style="width:200px;">Date of Purchase </th>

                                <th style="width:200px;">Gl No.</th>

                                <th style="width:100px;">Rate</th>

                                <th style="width:100px;">Discount</th>

                                <th style="width:150px;">Discounted Rate</th>

                                <th style="width:200px;">VAT/MST/CGST/SGST</th>

                                <th style="width:200px;">Rate with Vat</th>

                                <th style="width:150px;">Octri</th>

                                <th style="width:200px;">Rate with Octri</th>

                                <th style="width:200px;">Lab_in_Charge_Name</th>

                                <th style="width:200px;">Name_of_HOD</th>

                                <th style="width:150px;">Total Cost</th>

                                <th style="width:150px;">Image / PDF</th>

                                <th style="width:200px;">Working Status</th>

                                <th style="width:200px;">Action</th>

                            </tr>

                           <?php

                                    if (sizeof($allData) > 0) {

                                        

                                        for ($i = 0; $i < sizeof($allData); $i++) {

                                    ?> 

                        

                            <tr id="rowID<?php echo $allData[$i]["gi_no"]; ?>">

                                <script>

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>0");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>1");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>2");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>3");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>4");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>5");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>6");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>7");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>8");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>9");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>10");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>11");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>12");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>13");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>14");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>15");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>16");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>17");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>18");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>19");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>20");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>21");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>22");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>23");

                                    rowIds.push("rowID<?php echo $allData[$i]["gi_no"];?>24");

                                    allIds.push(rowIds);

                                    rowIds = [];



                                    tempLinks.push("./<?php echo $allData[$i]['path']; ?>");

                                    tempLinks.push("./edit_item.php?id=<?php echo $allData[$i]['id'] ?>");

                                    tempLinks.push("./del hardware.php?id=<?php echo $allData[$i]['id'] ?>");



                                    links.push(tempLinks);

                                    console.log(tempLinks);

                                    tempLinks = [];

                                    console.log(tempLinks);



                                </script>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>0" style="text-align: center; width:80px;"><?php echo ++$counter; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>1" style="text-align: center; width:150px;"><?php echo $allData[$i]["lab_no"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>2" style="text-align: center; width:200px;"><?php echo $allData[$i]["description"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>3" style="text-align: center; width:100px;"><?php echo $allData[$i]["quantity"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>4" style="text-align: center; width:150px;"><?php echo $allData[$i]["equipment no"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>5" style="text-align: center; width:150px;"><?php echo $allData[$i]["college code"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>6" style="text-align: center; width:200px;"><?php echo $allData[$i]["manufacturer"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>7" style="text-align: center; width:150px;"><?php echo $allData[$i]["invoice"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>8" style="text-align: center; width:150px;"><?php echo $allData[$i]["challan_no"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>9" style="text-align: center; width:200px;"><?php echo $allData[$i]["date"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>10" style="text-align: center; width:200px;"><?php echo $allData[$i]["gi_no"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>11" style="text-align: center; width:100px;"><?php echo $allData[$i]["rate"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>12" style="text-align: center; width:100px;"><?php echo $allData[$i]["discount"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>13" style="text-align: center; width:150px;"><?php echo $allData[$i]["discounted rate"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>14" style="text-align: center; width:200px;"><?php echo $allData[$i]["vat"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>15" style="text-align: center; width:200px;"><?php echo $allData[$i]["rate with vat"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>16" style="text-align: center; width:150px;"><?php echo $allData[$i]["octri"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>17" style="text-align: center; width:200px;"><?php echo $allData[$i]["rate_with_octri"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>18" style="text-align: center; width:200px;"><?php echo $allData[$i]["Lab_in_Charge_Name"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>19" style="text-align: center; width:200px;"><?php echo $allData[$i]["Name_of_HOD"]; ?></td>
                                 
                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>20" style="text-align: center; width:150px;"><?php echo $allData[$i]["total_cost"]; ?></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>21" style="text-align: center; width:150px;"><a href="<?php echo $allData[$i]['path']; ?>">view</a></td>

                                 <td id="rowID<?php echo $allData[$i]["gi_no"];?>22" style="text-align: center; width:200px;"><?php echo $allData[$i]["defective"]; ?></td>

                                 <td style="text-align: center; width:200px;">

                                    <a id="rowID<?php echo $allData[$i]["gi_no"];?>23" href="edit_item.php?id=<?php echo $allData[$i]['id'] ?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                    <a id="rowID<?php echo $allData[$i]["gi_no"];?>24" href="del hardware.php?id=<?php echo $allData[$i]['id'] ?>"><i class="fa fa-trash"></i>

                                </td>

                                </td>

                            </tr>

                    <?php

                                        }

                                    }

                    ?>

                        </table>

                        <!--<div class="text-center">

            <a href="user_data_print.php" class="btn btn-primary"></a> 

        </div>-->

                    </form>

                </div>

               

                <br>

                        <!-- Scroll to Top Button-->

                        <a class="scroll-to-top rounded" href="#page-top">

                            <i class="fas fa-angle-up"></i>

                        </a>

                        <!-- Logout Modal-->

                        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

                            <div class="modal-dialog" role="document">

                                <div class="modal-content">

                                    <div class="modal-header">

                                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>

                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">

                                            <span aria-hidden="true">×</span>

                                        </button>

                                    </div>

                                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>

                                    <div class="modal-footer">

                                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>

                                        <a class="btn btn-primary" href="logout.php">Logout</a>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <!-- Bootstrap core JavaScript-->

                        <script src="vendor/jquery/jquery.min.js"></script>

                        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                        <!-- Core plugin JavaScript-->

                        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

                        <!-- Custom scripts for all pages-->

                        <script src="js/sb-admin-2.min.js"></script>

                        <!-- Page level plugins -->

                        <script src="vendor/chart.js/Chart.min.js"></script>

                        <!-- Page level custom scripts -->

                        <script src="js/demo/chart-area-demo.js"></script>

                        <script src="js/demo/chart-pie-demo.js"></script>

                        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

                        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>

                        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>

</body>

</html>