
<?php  
include('connect.php');

session_start();

if (! (isset ( $_SESSION ['login'] ))) {

    header ( 'location:index.php' );



}
$sql = "SELECT * FROM `components`";

$result = $conn->query($sql);

$allData = array();

if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        $allData[] = $row;

    }

}
$counter = 0;

?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div class="printable_area">
<table>
<h1>Inventory Management System  </h1>
<h2>Major Components</h2>

<style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
    
<thread>
<th style="width:80px;"><b>Sr. No. </th>

                                <th style="width:80px;">ID</th>

                                <th style="width:100px;">Lab No</th>

                                <th style="width:100px;">Description</th>

                                <th style="width:100px;">Quantity</th>

                                <th style="width:150px;">Equipment Serial No.</th>

                                <th style="width:200px;">Supplier / Manufacturer</th>

                                <th style="width:150px;">Invoice</th>

                                <th style="width:200px;">Date of Purchase </th>

                                <th style="width:200px;">gl No.</th>

                                <th style="width:100px;">Rate</th>

                                <th style="width:150px;">Total Cost</th>

</thread>
<tbody>
    <?php
    if (sizeof($allData) > 0) {
        for ($i = 0; $i < sizeof($allData); $i++) {
            $row = $allData[$i]; // Get the specific row data
            ?>
<tr>
    <td style="text-align: center;"><?php echo ++$counter; ?></td>
    
    <td style="text-align: center;"><?php echo $row["id"]; ?></td>
    
    <td style="text-align: center;"><?php echo $row["lab_no"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Description"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Quantity"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Equipment_Serial_No"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Supplier/Manufacturer"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Invoice"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Date_of_Purchase"]; ?></td>

    <td style="text-align: center;"><?php echo$row["gi_no"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Rate"]; ?></td>

    <td style="text-align: center;"><?php echo $row["Total_Cost"]; ?></td>
</tr>
<?php

}

}

?>
</tbody>
</table>
</div>
</body>
</html>


<!-- Include jspdf library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.3/jspdf.umd.min.js"></script>

<script>
    const generatePDF = () => {
        const doc = new jsPDF();
        const printable_area = document.querySelector(".printable_area");
        const options = {
            margin: {
                top: 20,
                bottom: 20,
                left: 10,
                right: 10
            }
        };

        doc.fromHTML(printable_area, options);
        window.open(URL.createObjectURL(doc.output("blob")), "_blank");

        // Print the PDF directly
        setTimeout(() => {
            window.print();
        }, 1000); // You can adjust the delay (milliseconds) as needed
    };
    
</script>
<script>setTimeout(() => {
            window.print();
        }, 1000);</script>