<?php
include('connect.php');
    $id= $_GET['id'];
$sql = "DELETE FROM `users` WHERE `id`= '$id'";
$result = $conn->query($sql);
if($result === TRUE){
  echo '<script>
  confirm("User Deleted Sucessfully");
  window.location = "profile.php";</script>';
}else{
  echo '<script>
  alert("Something went Wrong! Please try Again.")</script>'; 
}
?>