-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 25, 2023 at 08:41 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id15573716_labm`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrower`
--

CREATE TABLE `borrower` (
  `id` int(11) NOT NULL,
  `from_lab` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `to_lab` varchar(50) NOT NULL,
  `remark` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borrower`
--

INSERT INTO `borrower` (`id`, `from_lab`, `description`, `to_lab`, `remark`) VALUES
(29, 'Lab 703: Signal Processing Lab', 'Dell Computer', 'Lab 604: Microwave and Satellite Communication Lab', ' Equipment no: 7WZNWQ1/7WZR8R1 '),
(30, 'Lab 703: Signal Processing Lab', 'Lenovo Pc', 'Lab 604: Microwave and Satellite Communication Lab', 'Equipment No:PG00RUAZ(SS)');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `lab_no` varchar(50) NOT NULL,
  `description` varchar(3500) NOT NULL,
  `quantity` varchar(10) NOT NULL,
  `equipment no` varchar(300) NOT NULL,
  `college code` varchar(50) DEFAULT NULL,
  `manufacturer` varchar(500) NOT NULL,
  `invoice` varchar(100) DEFAULT NULL,
  `challan_no` varchar(40) DEFAULT NULL,
  `date` varchar(15) NOT NULL,
  `gi_no` varchar(11) DEFAULT NULL,
  `rate` varchar(11) NOT NULL,
  `discount` varchar(11) DEFAULT NULL,
  `discounted rate` varchar(11) DEFAULT NULL,
  `vat` varchar(11) DEFAULT NULL,
  `rate with vat` varchar(11) DEFAULT NULL,
  `octri` varchar(11) DEFAULT NULL,
  `rate_with_octri` varchar(11) DEFAULT NULL,
  `total_cost` float NOT NULL,
  `path` varchar(200) DEFAULT NULL,
  `defective` varchar(50) NOT NULL,
  `remark` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `lab_no`, `description`, `quantity`, `equipment no`, `college code`, `manufacturer`, `invoice`, `challan_no`, `date`, `gi_no`, `rate`, `discount`, `discounted rate`, `vat`, `rate with vat`, `octri`, `rate_with_octri`, `total_cost`, `path`, `defective`, `remark`) VALUES
(34, 'Lab 601: Basic Electronics and PCB Lab', 'LCR Q Meter (4910 Autocompute)', '1', '232068', 'KJSIEIT/ET/LQR/002', 'Aplab Limited', '25000152/ 210771', '-', '2002-08-16', '551', '13,450.00', '', '', '', '', '', '', 15028, NULL, 'Yes', NULL),
(38, 'Lab 603: RF Communication Lab', 'Printer  Laser,  Monochrome, 600 dpi, 12ppm, USB 2.0\r\nModel: Canon LBP2900 ', '1', 'MBGA572931', 'KJSIEIT/ET/PRN/007', 'Acma Computers Ltd., Andheri (E)', '11004', '-', '2012-02-28', '359', ' 5,238.10 ', '', '', ' 261.91 ', '', '', '', 5500.01, NULL, 'Yes', NULL),
(39, 'Lab 603: RF Communication Lab', 'Digital Multimeter, Autorange, 1000V DC / 1000V AC              KUSUM-MECO KM-6040', '1', '994935', 'KJSIEIT/ET/DMM/016', 'KUSUM MECO', '2730', '2730', '2009-09-11', '3751', '28,438.00', '', '', ' 3,554.75 ', '', '', '', 31992.8, NULL, 'Yes', NULL),
(42, 'Lab 605: Microcontoller and Microprocessor Lab', 'Servo Controlled Voltage Stabilizer 10KVA, Powerline Make (170V- 270V I/P)', '1', 'PGSSS/2005/03/178', 'KJSIEIT/ET/VS/001', 'Power Gun Systems Pvt. Ltd.', '766', '-', '2005-03-08', '1815', '11500', '', '', '', '', '', '', 11500, NULL, 'Yes', NULL),
(43, 'Lab 605: Microcontoller and Microprocessor Lab', 'Air Conditioner General Make 24/50Hz', '2', 'AXG24APKW', '-', 'ETA General Pvt. Ltd., Goregaon ', 'LN/7/SFMO601491', '-', '2005-09-30', '2056', '  24,889.00', '', '', '', '', '', '', 49778, NULL, 'Yes', NULL),
(44, 'Lab 709: Project Lab', 'LBP 2900 B ', '1', 'L11121E	', 'KJSIEIT/ET/PR/003', 'Challenger computers', '09-10/08515', '-', '2009-09-05', '3698', '5500', '', '', '', '', '', '', 5500, NULL, 'Yes', NULL),
(45, 'Lab 709: Project Lab', 'Lenovo- Intel Core 2 duo E7500 processor 2.93GHz,1066MHz FSB 3MB L2, 2GB PC-6400 (800 MHz)DDR2 SDRAM,320GB 7200RPM serial ATA hard drivem,DVDRW/CDRW', '1', 'L909045', 'KJSIEIT/ET/DC/161', 'Bluecom Technologies Pvt. Ltd.', 'BT/2002/09-10', '-', '2010-03-04', '3782', '  26,500.00', '', '', '', '', '', '', 26500, NULL, 'Yes', NULL),
(46, 'Lab 703: Signal Processing Lab', 'DSP Texas 320F228016 based Daughter Board with XDS 100 USB based Emulator, USB Cable, 14 Pin Flat Cable for XDS 100 Emulator, User Manual, Software CD', '1', '1601', '-', 'Applied Digital Microsystems Pvt. Ltd.', '71112', '-', '2011-07-28', 'G.1.235', '  45,376.00', '', '', '', '  47,644.80', '', '', 47644.8, NULL, 'Yes', NULL),
(47, 'Lab 703: Signal Processing Lab', 'DSP Starter Kit for TMS30C6713 Includes 16 MEG SDRAM, USB Cable, Power Cord, AC-DC Adapter with Instruction Manual', '1', '-', '-', 'Applied Digital Microsystems Pvt. Ltd.', '31310', '-', '2013-03-22', 'G.1.681', '  47,063.00', '', '', '', '', '', '', 49416, NULL, 'Yes', NULL),
(48, 'Lab 701: Software Simulation and Networking Lab', 'LBP 2900 Laser Printer', '1', 'MBGA778816', 'KJSIEIT/ET/PRN/004', 'Maruti Compusystems', '482', '-', '2011-05-12', '180', '5,500.00', '', '', '', '', '', '', 5500, NULL, 'Yes', NULL),
(49, 'Lab 701: Software Simulation and Networking Lab', 'HP Laser jet pro M1136 MFP', '1', 'CNG7D6YJ7P', 'KJSIEIT/ET/PRN/008', 'Nitya Infotech', 'NIM/358/DEC/12-13', '-', '0013-12-04', '597', '19,200.00', '', '', '', '', '', '', 19200, NULL, 'Yes', NULL),
(50, 'Lab 701: Software Simulation and Networking Lab', 'Access Point 610 N Linksys (Router)', '1', 'MDG20E139533', '-', 'Media Com Systems', '101', '-', '2011-02-20', '217', '  3,750.00 ', '', '', '', '', '', '', 3750, NULL, 'No', NULL),
(51, 'Lab 701: Software Simulation and Networking Lab', 'Lenovo think centre A58, with 18.5\" TFT monitor.', '1', 'L970023', 'KJSIEIT/ET/DC/048', 'Bluecom Technologies Pvt. Ltd.', 'BI/0769/10-11', '-', '2011-03-31', '151', '  25,000.00', '', '', '', '', '', '', 25000, NULL, 'No', NULL),
(52, 'Lab 703: Signal Processing Lab', '  25,000.00 \r\n\r\n\r\n\r\n\r\n\r\n\r\n', '22', '20', '2', '2', '2', '2', '0002-02-22', '2', '2', '', '', '', '', '', '', 2, NULL, 'No', NULL),
(60, 'Lab 703: Signal Processing Lab', 'DSP Texas 320F228016 based Daughter Board with XDS 100 USB based Emulator, USB Cable, 14 Pin Flat Cable for XDS 100 Emulator, User Manual, Software CD', '1', '1601', 'KJSIEIT', 'Applied Digital Microsystems Pvt. Ltd.', '71112', '71112', '2011-07-28', 'G.1.235', '45376', 'NIL', 'NIL', '', '47644.8', '', '', 47644.8, NULL, 'Yes', NULL),
(61, 'Lab 703: Signal Processing Lab', 'Laser Jet Printer HP P1108', '1', 'VNF4G38895', 'KJSIEIT/ET/PRN/013', 'Nexttech,Mumbadevi ,Masjid', 'NS-5084', 'NS-5084', '2020-02-07', '3793', '8200', '', '', '', '9676', '', '', 9676, NULL, 'Yes', NULL),
(62, 'Lab 703: Signal Processing Lab', 'LBP 2900 B Printer ', '1', 'L11121E', 'KJSIEIT/ET/PR/002', 'Challenger computers', '09-10/08515', '09-10/08515', '2009-09-05', '3698', '5500', '', '', '', '5500', '', '', 5500, NULL, 'Yes', NULL),
(63, 'Lab 703: Signal Processing Lab', 'Dell Optilex 390DT Intel Core i3-2100 (3.10GHz, 3MB L2 Cache), Intel H61 Express Chipset, 4GB DDR-3 (1333MHz) RAM, 500GB SATA HDD (7200 RPM), DVD Writer, Std. USB Keyboard, USB Optical Scroll Mouse, LAN 10/100/1000 mbps Integrated, Dell 18.5\" WXGA TFT, Integrated HD Graphics, Audio, No. Internal Speaker, No OS', '18', '7X1D8R1 7WY48R1 7WYB8R1 7WZM7R1 7WZQ8R1 7WYNWQ1 7WZT8R1 7WZR8R1 7X1S7R1 7X218R1 7X2Q8R1 7WYP8R1 7X0Y8R1 cw 7X14ZR1 cw 7WYR7R1 cw 7X2C8R1 cw 7XOPWQ1  NILKA-BSH  7WY58R1 NILKA-BSH ', 'KJSIEIT/ET/DC/073-097', 'Radiant Tradevest Pvt. Ltd.', '278', '278', '2012-09-01', '329', '26800', '', '', '', '', '', '26800', 482400, NULL, 'Yes', NULL),
(64, 'Lab 703: Signal Processing Lab', 'Desktop  Lenovo LN S510 10KXA00BHF (3-6100/4GB/500GB/WIN10SLHOME) with 19.5\" TFT 60DFAAR1WW,HDD ,32 GB DDR4, 2133 MHz - 2 x DIMM Slots, 500 GB / 1 TB, 7200 rpm SSD : 2.5\" 120 GB / 128 GB / 192 GB / 256 GB,Tower : Starting at 16.9 lbs (7.65 kg) SFF : Starting at 9.1 lbs (4.13 kg)\r\n\r\nDesktop  Lenovo LN S510 10KXA00BHF (3-6100/4GB/500GB/WIN10SLHOME) with 19.5\" TFT 60DFAAR1WW,HDD ,32 GB DDR4, 2133 MHz - 2 x DIMM Slots, 500 GB / 1 TB, 7200 rpm SSD : 2.5\" 120 GB / 128 GB / 192 GB / 256 GB,Tower : Starting at 16.9 lbs (7.65 kg) SFF : Starting at 9.1 lbs (4.13 kg)\r\n', '3', 'PG00RU9J PG00RU9Z PG00RU9W', 'KJSIEIT/ET/DC/119-122', 'JBA Infosolutions', 'JBA/0309/16-17', 'JBA/0309/16-17', '2016-09-02', '329', '32000', '', '', '', '', '', '33760', 101280, NULL, 'Yes', NULL),
(65, 'Lab 703: Signal Processing Lab', 'HP Bundle Desktop PC, ProDesk 400 G6 MT -13, 500 GB 7500 3.5, USB Busslim Keyboard, 32 GB DDR42400, USB Hardended WRD Mouse, Win10 64-bit OS Home 64SL, Intel 7100 7Gen Core i3-2C, DVD+DRDVD, V203p Monitor, 1*9.5 inch lcd monitor', '24', '4CE9511VYT (YC) CPU 4CE9511VYX 4CE9511VYY 4CE9511VYZ 4CE9511VZ6 4CE9511VZ8 4CE9511VZ9 4CE9511VZB 4CE9511VZG 4CE9511VZM 4CE9511VZS 4CE9511VZT 4CE9511VZV 4CE9511VZZ 4CE9511W00 4CE9511W01 (CW) 4CE9511W04 4CE9511W06 4CE9511W09 4CE9511W0B 4CE9511W0J (HP) 4CE9511W0R 4CE9511W14 4CE9511W1L', 'KJSIEIT/ET/DC/162 -185', 'Neptune Infosolution Pvt. Ltd , Malad west', '221170128680', '221170128680', '2020-02-07', '3795', '29000', '', '', '', '', '', '34220', 787060, NULL, 'Yes', NULL),
(66, 'Lab 604: Microwave and Satellite Communication Lab', 'The Link - Klystron Based Microwave Bench, Model-TL2001X-Band(8.2 to 12.4 GHz) Solid State Digital Klystron Power Supply(with AM/FM Modulation), Klystron Tube 2k25 or its equivalent, Waveguide Detector Mount with IN23 diode, Variable Attenuator(0-20dB)\r\n', '1', 'MWB01', 'KJSIEIT/ET/TK-MW/01', 'M/S-The Link', 'TL/A-3/51 & 54', 'TL/A-3/51 & 54', '2005-03-16', '1885', '159520', '', '', '', '', '', '', 159520, NULL, 'No', 'remark'),
(68, 'Lab 604: Microwave and Satellite Communication Lab', 'lenovo computer', '5', '101', '101', '101', '101', '101', '2022-07-31', '101', '1', '1', '1', '1', '1', '11', '1', 1, NULL, 'No', NULL),
(69, 'Lab 604: Microwave and Satellite Communication Lab', 'NVIS Magnetisum Lab', '1', 'NV6004', 'KJSIEIT/ET/TK-EWT/02', 'M/S-Automate Process Control', 'APC:201APC:192', 'APC:201APC:192', '2009-03-31', '3494', ' 13036', '0', '0', '0', '0', '0', '0', 13036, NULL, 'No', NULL),
(71, 'Lab 604: Microwave and Satellite Communication Lab', 'The Link - Klystron Based Microwave Bench, Model-TL2001X-Band(8.2 to 12.4 GHz) Solid State Digital Klystron Power Supply(with AM/FM Modulation), Klystron Tube 2k25 or its equivalent, Waveguide Detector Mount with IN23 diode, Variable Attenuator(0-20dB)', '1', '25', 'KJSIEIT/ET/TK-MW/01', 'M/S-The Link', 'TL/A-3/51 & 54', 'TL/A-3/51 & 54', '2005-05-16', '1885', '159520', '', '', '', '', '', '', 159520, NULL, 'Yes', NULL),
(73, 'Lab 605: Microcontoller and Microprocessor Lab', 'Universal  Programmer (Labtool-48UXP) with Cable & connector Set and KBD (6)', '1', 'AE0603000163', 'KJSIEIT/ET/EPP/001', 'Dyanlog (I) Limited', 'DIL-480/003107', 'DIL-480/003107', '2006-06-20', '2355', '42670', '', '', '', '', '', '', 47471, NULL, 'Yes', NULL),
(74, 'Lab 605: Microcontoller and Microprocessor Lab', 'Logic Analyser with Integrated Digital Test System LG 320 + CPLD/EPGA Trainer Model', '1', '170', 'KJSIEIT/ET/LA/001', 'Applied Digital Microsystems Pvt. Ltd.', ' 050601', ' 050601', '2006-06-02', '2314', '175000', '', '', '', '', '', '', 159250, NULL, 'Yes', NULL),
(75, 'Lab 605: Microcontoller and Microprocessor Lab', 'TK Base Kit (Set of 3 each)', '3', '170', 'KJSIEIT/ET/LA/002-004', 'Applied Digital Microsystems Pvt. Ltd.', ' 050601', ' 050601', '2006-06-02', '2314', '22500', '', '', '', '', '', '', 61425, NULL, 'Yes', NULL),
(76, 'Lab 605: Microcontoller and Microprocessor Lab', 'Upgradation of Tkbase CPLD/EPGA Trainer Model TK Base Kit with Daughter Boards, Adapter, CDs, P/S Cables', '3', '1112/1114/1116', 'KJSIEIT/ET/LA/005-007', 'Applied Digital Microsystems Pvt. Ltd.', '010901', '010901', '2009-01-09', '3397', '19900', '', '', '', '', '', '', 55879, NULL, 'Yes', NULL),
(77, 'Lab 605: Microcontoller and Microprocessor Lab', 'Laptop Lenovo (Model B450-A59-02-8950) with carry case', '1', 'EB16682696', 'KJSIEIT/ET/LC/001', 'Bluecom Technologies Pvt. Ltd.', 'BT/0250/10-11  CS/5681', 'BT/0250/10-11  CS/5681', '2010-05-14', '3831', '30952', '', '', '', '', '', '', 32500, NULL, 'Yes', NULL),
(78, 'Lab 605: Microcontoller and Microprocessor Lab', 'Logic Analyser hosted / upgradable Universal Trainer / Development System +\r\nXilinx FPGA Spartan 3XC3S400 Daughter board & Serial EPROM + JTAG Connector + 89c51RD2 Daughter Board + ARM7 LPC21xx Daughter Board with cable + PIC 18F4520 Daughter Board with onboard  ISP', '5', '1809, 1810, 1815, 1816,  1818', 'KJSIEIT/ET/LA/008-012', 'Applied Digital Microsystems Pvt. Ltd.', '011303', '011303', '2013-01-04', 'G.1.608', '41377', '', '', '', '', '', '', 217229, NULL, 'Yes', NULL),
(79, 'Lab 605: Microcontoller and Microprocessor Lab', 'HP PROBOOK 440GB (3V7N0PA)', '1', '5CD1220Z7D', 'KJSIEIT/ET/LC/011', 'Neptune Infosolution Pvt. Ltd.', 'NIPL/JUN21/325', 'NIPL/JUN21/325', '2021-06-21', '4051', '45400', '', '', '', '', '', '', 53572, NULL, 'Yes', NULL),
(80, 'Lab 605: Microcontoller and Microprocessor Lab', 'Dell Latitude 3490 Laptop Intel i3-7131 processor upto 2.7GHz, 3MB Smart Cache, 64 bit Membery 8 GB DDR4 RAM @2400MHz, HDD 500GB Serial SATA, @7200 RPM', '2', '870VXR2 / 890VXR2', 'KJSIEIT/ET/LC/009-010', 'Pentagon System and Services Pvt. Ltd.', 'MH1819/1575', 'MH1819/1575', '0008-08-10', '3106', '37000', '', '', '', '', '', '', 87320, NULL, 'Yes', NULL),
(81, 'Lab 605: Microcontoller and Microprocessor Lab', 'Laser Jet Printer HP P1108', '1', 'VNF4V26182', 'KJSIEIT/ET/PRN/011', 'SOL NET Systems Pvt. Ltd', 'SOLNET/1031/1819', 'SOLNET/1031/1819', '2018-09-12', '3049', '7100', '', '', '', '', '', '', 8378, NULL, 'Yes', NULL),
(82, 'Lab 605: Microcontoller and Microprocessor Lab', 'LENOVO (M720T) Windows-10 Pro pre-loaded Desktop', '2', 'PG01BLWN / PG01BLWU', 'KJSIEIT/ET/DC/159-160', 'Om Sai Corporation', 'GSTOSG18192464', 'GSTOSG18192464', '2018-09-08', '3065', '37394.21', '', '', '', '', '', '', 74788.4, NULL, 'Yes', NULL),
(83, 'Lab 605: Microcontoller and Microprocessor Lab', 'HP Bundle Desktop PC, ProDesk 400 G4 MT, 500 GB 7500 3.5, USB Busslim Keyboard, 8 GB DDR42400, USB Hardended WRD Mouse, Win10 64-bit OS Home 64SL, Intel 7100 7Gen Core i3-2C, DVD+DRDVD, V203p Monitor', '20', 'SGH740TQZT, SGH740TR00 SGH740TR01, SGH740TR03 SGH740TR07, SGH740TR0R SGH740TR0X, SGH740TR12 SGH740TR18, SGH740TR19 SGH740TR1C, SGH740TR1H SGH740TR1M, SGH740TR1N SGH740TR1P, SGH740TR1Q SGH740TR1T, SGH740TR1X SGH740TR1Y, SGH740TRZW', 'KJSIEIT/ET/DC/129-148', 'HP India Sales Pvt. Ltd.', 'SVV/171/2017-18', 'SVV/171/2017-18', '2017-10-17', '2548', '31500', '', '', '', '', '', '', 743400, NULL, 'Yes', NULL),
(84, 'Lab 605: Microcontoller and Microprocessor Lab', 'Dell Optilex 390DT Intel Core i3-2100 (3.10GHz, 3MB L2 Cache), Intel H61 Express Chipset, 4GB DDR-3 (1333MHz) RAM, 500GB SATA HDD (7200 RPM), DVD Writer, Std. USB Keyboard, USB Optical Scroll Mouse, LAN 10/100/1000 mbps Integrated, Dell 18.5\" WXGA TFT, Integrated HD Graphics, Audio, No. Internal Speaker, No OS.', '2', '7WY38R1 / 7WYG8R1', 'KJSIEIT/ET/DC/099-110', 'Radiant Tradevest Pvt. Ltd.', '278', '278', '2012-10-09', 'G.1.329', '25529.81', '', '', '', '', '', '', 53600, NULL, 'Yes', NULL),
(85, 'Lab 605: Microcontoller and Microprocessor Lab', 'TK-uP Logic Analyser hosted / upgradable Universal Processsor Development System + Module for Intel 8085 + Module for Intel 8086', '5', '173 / 243 / 244 / 249 / 260', 'KJSIEIT/ET/LA/013-017', 'Applied Digital Microsystems Pvt. Ltd.', '011303', '011303', '0013-12-04', 'G.1.608', '22106', '', '', '', '', '', '', 116056, NULL, 'Yes', NULL),
(86, 'Lab 605: Microcontoller and Microprocessor Lab', 'TK Base Peripheral Interface Cards - TK Smi Stepper Motor with interface cards + TK DC Motor with Opto sensor interface card + TKADC 8-bit ADC Module Parallel +\r\nTKDAC 8-bit DAC Module Parallel + TK GSM Module', '2', '512 / 513 / 514 / 515 / 516', 'KJSIEIT/ET/LA/018-022', 'Applied Digital Microsystems Pvt. Ltd.', '011303', '011303', '2013-01-04', 'G.1.608', '18522', '', '', '', '', '', '', 97240.5, NULL, 'Yes', NULL),
(87, 'Lab 605: Microcontoller and Microprocessor Lab', 'Voltas Split - 3 Star 2 Ton', '1', '-', '-', 'Neumann Aircon', 'NAM/G/95/2017-2018', 'NAM/G/95/2017-2018', '2017-09-18', '2457', '43499.50', '', '', '', '', '', '', 43499.5, NULL, 'No', NULL),
(88, 'Lab 605: Microcontoller and Microprocessor Lab', 'Speaker', '1', 'zebsrpop0172078', 'KJSIEIT/ET/SPK/011', 'Amazon', 'SJAB3975', 'SJAB3975', '2016-09-19', '-', '449', '', '', '', '', '', '', 449, NULL, 'Yes', NULL),
(89, 'Lab 605: Microcontoller and Microprocessor Lab', 'Speakers S-100 2.0 (ZEB-S500 Wave)', '9', 'ZEBANS500121013923/34/37/38/47/50/52/54/58/59', 'KJSIEIT/ET/SPK/001-010', 'Manglik Infosys', '11-12 Jul 2467', '11-12 Jul 2467', '2011-07-28', 'G.1.223', '450', '', '', '', '', '', '', 4252.5, NULL, 'No', NULL),
(90, 'Lab 604: Microwave and Satellite Communication Lab', 'NVIS Electricity Lab\r\n', '1', 'NV6000', 'KJSIEIT/ET/TK-EWT/01', 'M/S-Automate Process Control', 'APC:201     APC:192', 'APC:201     APC:192', '2009-03-31', '3494', '13036', '', '', '', '', '', '', 13036, NULL, 'Yes', NULL),
(91, 'Lab 601: Basic Electronics and PCB Lab', 'DIGITAL MULTIMETER 3 3/4 DIGIT \r\n', '5', '2485797- 2485801', 'KJSIEIT / ET/ DMM-078-082', 'Aplab Limited', '18730159', '18730159', '2019-03-20', '3492', '2124', '', '', '', '', '', '', 10620, NULL, 'Yes', NULL),
(92, 'Lab 601: Basic Electronics and PCB Lab', 'Aplab 2MHZ Multiwaveform signal generator MSG2M \r\n', '5', 'HO03MSG0119001 -  2 , HO03MSG0119025- 26 , HO03MSG1218273', 'KJSIEIT / ET/ FG-060-064', 'Aplab Limited', '18300721', '18300721', '2019-03-20', '3491', '7080', '', '', '', '', '', '', 35400, NULL, 'Yes', NULL),
(93, 'Lab 601: Basic Electronics and PCB Lab', ' Aplab, 30MHz Dual Trace Oscilloscope 3706C\r\n', '9', 'HO03OSC0219027 -32 ,HO03OSC0319033- 35', 'KJSIEIT / ET/ CRO-046-054', 'Aplab Limited', '18300721', '18300721', '2019-03-20', '3491', '19470', '', '', '', '', '', '', 175230, NULL, 'Yes', NULL),
(94, 'Lab 601: Basic Electronics and PCB Lab', 'Power Supply ±12V/1A  DC Make : Sairush Electronics Model: SEL0120017\r\n', '9', '072K2/67, 69 ,70,71, 73, 75, 76, 80, 81', 'KJSIEIT/ET/PS/033-041', 'Automate Process Control', '7/2/1930', '7/2/1930', '2002-07-29', '521', '2500', '250', '2250', '', '', '101', '2351', 21161, NULL, 'Yes', NULL),
(95, 'Lab 601: Basic Electronics and PCB Lab', 'Digital Multimeter, 4½ Digit, 3A  Scientific HM5011\r\n', '3', '0412215, 0503216, 0503217', 'KJSIEIT/ET/DMM/0133-0135', 'Automate Process Control', 'APC-52/23/3/05', 'APC-52/23/3/05', '2005-03-23', '1829', '13000', '1430', '11570', '1134', '12704', '699', '13403', 40208, NULL, 'Yes', NULL),
(96, 'Lab 601: Basic Electronics and PCB Lab', 'Lenovo  [ThinkCentre  A58 5597-A12] Intel Core 2 Duo E7500 Processor 2.93GHz 1066 MHz FSB, 3MB L2 Cache, 2GB PC-6400 (800MHz) DDR2 SDRAM, 320GB 7200RPM SATA HDD, PCI/PCIe Tower (4x5), Intel GMA 4500, DVDRW/CDRW, 10/100/1000 Gigabit Ethernet, Full size English Keyboard, USB Optical wheel Mouse (400 DPI, USB), 18.5\" TFT Monitor\r\n', '3', 'L927728/L927660/L904286', 'KJSIEIT/ET/DC/006/008/009', 'Bluecom Technologies Pvt. Ltd.', 'BT/2252/09-10', 'BT/2252/09-10', '2010-03-04', '3782', '25480', '', '', '1019', '26500', '', '', 79500, NULL, 'Yes', NULL),
(97, 'Lab 601: Basic Electronics and PCB Lab', 'Power supply Sairush Model No: SVL030002D\r\n', '7', '032k10/117,118,119,120,121,122, 123', 'KJSIEIT/ET/PS/051-057', 'Automate Process Control', 'APC-09/APC-09', 'APC-09/APC-09', '2010-04-19', '3834', '10063', '', '', '1258', '11321', '623', '11944', 83605, NULL, 'Yes', NULL),
(98, 'Lab 601: Basic Electronics and PCB Lab', 'Function Generator Scientech 2 mhz\r\n', '4', '02102501/02102547/02102551/02102553', 'KJSIEIT/ET/FG/028-032', 'Automate Process Control', 'APC-09/APC-09', 'APC-09/APC-09', '2010-04-19', '3834', '88844', '', '', '1106', '9950', '547', '10497', 41988, NULL, 'Yes', NULL),
(99, 'Lab 601: Basic Electronics and PCB Lab', 'Scanner Canon Lide 100\r\n', '1', 'KDMC/65460', 'KJSIEIT/ET/SCN/001', 'CHALLENGE COMPUTERS', '1011/1510', '1011/1510', '2010-05-20', '3833', '2990', '142', '2848', '142', '2990', '', '', 2990, NULL, 'Yes', NULL),
(100, 'Lab 601: Basic Electronics and PCB Lab', 'Digital multimeter Scientech 41/2 Caddo 61 T\r\n', '8', '051076/77/78/79/80/81/82, 090975', 'KJSIEIT/ET/DMM/026-033', 'Automate Process Control', 'APC-42/APC-41', 'APC-42/APC-41', '2010-06-07', '3844', '16188', '', '', '2024', '18212', '1002', '19213', 153705, NULL, 'Yes', NULL),
(101, 'Lab 601: Basic Electronics and PCB Lab', 'LAMINATE COATER\r\n', '1', '10/4/M/2004', 'KJSIEIT/ET/LC/001', 'PHENIX', '10', '10', '2010-08-31', '14', '14650', '4395', '10255', '1282', '11537', '', '', 11537, NULL, 'Yes', NULL),
(102, 'Lab 601: Basic Electronics and PCB Lab', 'PHOTO RESIST DRYER\r\n', '1', '10/4/M/2005', 'KJSIEIT/ET/PD/001', 'PHENIX', '10', '10', '2010-08-31', '14', '13550', '4065', '9485', '1186', '10671', '', '', 10671, NULL, 'Yes', NULL),
(103, 'Lab 601: Basic Electronics and PCB Lab', 'BOTH SIDE EXPOSURE\r\n', '1', '10/4/M/2006', 'KJSIEIT/ET/BSE/001', 'PHENIX', '10', '10', '2010-08-31', '14', '26900', '8070', '18830', '2354', '21184', '', '', 21184, NULL, 'Yes', NULL),
(104, 'Lab 601: Basic Electronics and PCB Lab', 'EASY  ETCHER\r\n', '1', '10/4/M/2007', 'KJSIEIT/ET/EE/001', 'PHENIX', '10', '10', '2010-08-31', '14', '19850', '5955', '13895', '1737', '15632', '', '', 15632, NULL, 'Yes', NULL),
(105, 'Lab 601: Basic Electronics and PCB Lab', 'EASY DRILLING MACHINE\r\n', '1', '10/4/M/2008', 'KJSIEIT/ET/EDM/001', 'PHENIX', '10', '10', '2010-08-31', '14', '8950', '2685', '6265', '783', '7048', '', '', 7048, NULL, 'Yes', NULL),
(106, 'Lab 601: Basic Electronics and PCB Lab', 'PROTO CIRCULAR SAW\r\n', '1', '10/4/M/2009', 'KJSIEIT/ET/PCS/001', 'PHENIX', '10', '10', '2010-08-31', '14', '10500', '3150', '7350', '919', '8269', '', '', 8269, NULL, 'Yes', NULL),
(107, 'Lab 601: Basic Electronics and PCB Lab', 'Digital Storage oscilloscope 100 mhz(Model-DS 1102E)\r\n', '2', '0810100-0810101', 'KJSIEIT/ET/DSO/004-005', 'Automate Process Control', 'APC-82/APC-91', 'APC-82/APC-91', '2010-09-01', '13', '83250', '', '', '4163', '87413', '', '', 174825, NULL, 'Yes', NULL),
(108, 'Lab 601: Basic Electronics and PCB Lab', 'LASER PRINTER                                   (Canon LBP 2900B)\r\n', '1', 'MBGA13-7216', 'KJSIEIT/ET/PRN/003', 'WELLDONE Computer', '2448', '2448', '2010-09-09', '09', '5333', '', '', '267', '5600', '', '', 5600, NULL, 'Yes', NULL),
(109, 'Lab 601: Basic Electronics and PCB Lab', 'Power supply  30V Sairush Model No:SVL032002D\r\n', '5', '072K11/360,361,362,363,364', 'KJSIEIT/ET/PS/060-064', 'Automate Process Control', 'APC-53/APC-58', 'APC-53/APC-58', '2011-08-09', '254', '8554', '', '', '1069', '9623', '', '', 48116, NULL, 'Yes', NULL),
(110, 'Lab 601: Basic Electronics and PCB Lab', 'Power supply 12V Sairush Model No:SVL012002T\r\n', '3', '082K11/388,389,390', 'KJSIEIT/ET/PS/065-067', 'Automate Process Control', 'APC-53/APC-58', 'APC-53/APC-58', '2011-08-09', '254', '5100', '', '', '638', '5738', '', '', 17213, NULL, 'Yes', NULL),
(111, 'Lab 601: Basic Electronics and PCB Lab', 'CRO Caddo 801 30 MhZ\r\n', '5', '8113331/32/33/37/38', 'KJSIEIT/ET/CRO/028-032', 'Automate Process Control', 'APC-67/APC-70', 'APC-67/APC-70', '2011-08-25', '254', '18700', '', '', '935', '19635', '', '', 98175, NULL, 'Yes', NULL),
(112, 'Lab 601: Basic Electronics and PCB Lab', 'FG SCIENTIFIC CADDO 10MHZ\r\n', '10', '06114263,64,       07114265,66,67,71,73,74,75,77.', 'KJSIEIT/ET/FG/033-047', 'Automate Process Control', 'APC-67/APC-63', 'APC-67/APC-63', '2011-08-25', '254', '7650', '', '', '956', '8606', '', '', 86062, NULL, 'Yes', NULL),
(113, 'Lab 601: Basic Electronics and PCB Lab', 'DMM Scientific HM5011-3A\r\n', '11', '1103465/66/1109467/70/71/73/74/75/77/78/79', 'KJSIEIT/ET/DMM/034-048', 'Automate Process Control', '101/105', '101/105', '2011-09-30', '289', '13760', '', '', '1720', '15480', '', '', 170280, NULL, 'Yes', NULL),
(114, 'Lab 601: Basic Electronics and PCB Lab', 'GW-DMM -GDM-8261\r\n', '2', 'EM170132 /  EM170152', 'KJSIEIT/ET/DMM/049-050', 'Automate Process Control', 'APC-154', 'APC-154', '2013-01-11', '139', '56875', '', '', '', '', '', '', 135008, NULL, 'Yes', NULL),
(115, 'Lab 601: Basic Electronics and PCB Lab', 'Variac 3 Phase/5 amp (close type)\r\n', '2', 'oo', 'KJSIEIT/ET/PS/069-070', 'ADVANCE ELECTRONICS', '133/13-14', '133/13-14', '2013-07-30', '777', '9480', '', '', '1185', '10665', '', '', 21330, NULL, 'Yes', NULL),
(116, 'Lab 601: Basic Electronics and PCB Lab', 'Variac 1 Phase/10 amp (close type)\r\n', '1', '00', 'KJSIEIT/ET/PS/071', 'ADVANCE ELECTRONICS', '133/13-14', '133/13-14', '2013-07-30', '777', '4040', '', '', '505', '4545', '', '', 4545, NULL, 'Yes', NULL),
(117, 'Lab 601: Basic Electronics and PCB Lab', 'Power Supply (0-30V/2A, +/-15V) Adtron Multi O/P\r\n', '2', '00', 'KJSIEIT/ET/PS/072-073', 'ADVANCE ELECTRONICS', '133/13-14', '133/13-14', '2013-07-30', '777', '8800', '', '', '1100', '9900', '', '', 19800, NULL, 'Yes', NULL),
(118, 'Lab 601: Basic Electronics and PCB Lab', 'Power Supply (0-30V/2A, +/-15V) Adtron Multi O/P\r\n', '1', '00', 'KJSIEIT/ET/PS/074', 'ADVANCE ELECTRONICS', '133/13-14', '133/13-14', '2013-07-30', '777', '10960', '', '', '1370', '12330', '', '', 12330, NULL, 'Yes', NULL),
(119, 'Lab 601: Basic Electronics and PCB Lab', 'Digital Multimeter, 4½ Digit, Auto Range, Table Top Make: Classic\r\n', '2', '996373538/  996373544', 'KJSIEIT/ET/DMM/064-065', 'ADVANCE ELECTRONICS', '02/14-15', '02/14-15', '2014-04-04', '952', '15300', '', '', '1913', '17213', '', '', 34425, NULL, 'Yes', NULL),
(120, 'Lab 601: Basic Electronics and PCB Lab', 'Printer Laser Jet HP P1108\r\n', '1', 'VNF4V10334', 'KJSIEIT/ET/PRN/010', 'JBA Infosolutions', 'JBA/0367/16-17', 'JBA/0367/16-17', '2016-11-01', '2023', '7877', '', '', '473', '8350', '', '', 8350, NULL, 'Yes', NULL),
(121, 'Lab 601: Basic Electronics and PCB Lab', 'Lenovo Desktop M720T -10SRS0TV00  Intel Coe i3-8100 th Gen 3.9GHz 8GB 2X4GB DDR4 2400 NECC UnBuffered Memory, 500GB 7200 RPM ,Intel B370 Chipset ,Intel HD 610 Graphics  10 / 100 /1000 NIC ,USB Keyboard & optical Mouse ,Integrated AUDIO 1 X Pce X 1,2X PCie X 16, 1Xm2 PCEeslot 1DP Port 1VGA Port, 1HDMI Port, 2 USB 3.0 ,Audio in ,Audio Out, 1 RJ45, Windows 10 home 64 single Language India warrenty Five Years Onsite.Comprehensive Warrenty  by parent Company\r\n', '5', 'PG01BLWD/  PG01BLWF/ PG01BLWG/ PG01BLWK/     PG01BLWL', 'KJSIEIT/ ET/DC/154-158', 'OM SAI CORPORATION', 'GSTOSG18192464', 'GSTOSG18192464', '2018-09-08', '3065', '31690', '', '', '5704', '37394', '', '', 186971, NULL, 'Yes', NULL),
(122, 'Lab 601: Basic Electronics and PCB Lab', 'Laptop: Lenovo Thinkpad E-431 with carry case 4GB RAM, DDR3L-1600, HDD 500GB, 7200 RPM, DVD Gigabit Ethernet, Win 7 starter\r\n', '1', 'PGGW906', 'KJSIEIT/ET/LC/006', 'Om Sai Corporation', 'OSG/14-15/0273', 'OSG/14-15/0273', '2014-06-14', '1021', '41990', '', '', '', '', '', '', 41990, NULL, 'Yes', NULL),
(123, 'Lab 603: RF Communication Lab', 'Multimedia Projector \r\nModel: EPSON  EB X02', '2', 'RPLK2700759   RPLK2700721', 'KJSIEIT/ET/PROJ/003 KJSIEIT/ET/PROJ/004', 'EPSON ', '0569/EITPL/2013-14', '0569/EITPL/2013-14', '2013-03-08', '813', '26558', '', '', '', '', '', '', 59800, NULL, 'Yes', NULL),
(124, 'Lab 603: RF Communication Lab', 'Digital Multimeter \r\nTable Top,  4½ Digit, Auto Range, True RMS, Dual Display\r\nMake: VICTOR 8145B ', '2', '996373539  996373531', 'KJSIEIT/ET/DMM/060  KJSIEIT/ET/DMM/061', 'VICTOR', '02/14-15', '02/14-15', '2014-04-04', '952', '15300', '', '', '', '', '', '', 34425, NULL, 'Yes', NULL),
(125, 'Lab 603: RF Communication Lab', 'Multimedia Projector \r\nModel: EPSON  EB X02', '2', 'RPLK3900388  RPLK3900014', 'KJSIEIT/ET/PROJ/005 KJSIEIT/ET/PROJ/006', 'EPSON ', '101998', '101998', '2014-06-03', '1017', '24267', '', '', '', '', '', '', 54600, NULL, 'Yes', NULL),
(126, 'Lab 603: RF Communication Lab', 'Abitrary Function Generator \r\nMake : GW INSTEK\r\nModel: AFG 2005', '2', 'EL912055,  EL824205', 'KJSIEIT/ET/FG/049 KJSIEIT/ET/FG/050', 'GW INSTEK', 'APC-137', 'APC-137/12-13', '2012-12-13', '608', '21875', '', '', '', '', '', '', 51406, NULL, 'Yes', NULL),
(127, 'Lab 602: Analog and Digital Communication Lab', 'ST2102 : TDM Pulse Amplitude Mod/Demod ', '2', '301188-301189', 'KJSIEIT/ET/DC-TK/005-006', 'Automate Process Control', '02/07/020', '02/07/020', '2002-07-10', '506', '13740', '', '', '', '', '', '', 28378, NULL, 'Yes', NULL),
(129, 'Lab 602: Analog and Digital Communication Lab', 'CRO Four Trace, 100 MHz Scientific SM511', '1', '412040', 'KJSIEIT/ET/CRO/026', 'Automate Process Control', 'APC-47/ APC-49', 'APC-47/ APC-49', '2005-02-27', '1817', '  56425', '', '', '', '', '', '', 61909, NULL, 'Yes', NULL),
(130, 'Lab 602: Analog and Digital Communication Lab', 'Function Generator SM5071 Scientific 3MHz ', '1', '4111361', 'KJSIEIT/ET/FG/011', 'Automate Process Control', 'APC-47/ APC-49', 'APC-47/ APC-49', '2005-02-28', '1817', '  8190', '', '', '', '', '', '', 8986, NULL, 'Yes', NULL),
(131, 'Lab 602: Analog and Digital Communication Lab', 'Digital Multimeter, 4½ Digit, 3A  Scientific HM5011', '1', '0503218', 'KJSIEIT/ET/DMM/002', 'Automate Process Control', 'APC-57/ APC-58', 'APC-57/ APC-58', '2005-03-23', '1829', '  11570', '', '', '', '', '', '', 13402, NULL, 'Yes', NULL),
(132, 'Lab 602: Analog and Digital Communication Lab', 'CRC Coding Decoding Trainer', '1', 'CRC100', 'KJSIEIT/ET/DC-TK/019', 'Techno scientific Co.', 'BR/005/06', 'BR/005/06', '2006-04-12', '2279', '  40000 ', '', '', '', '', '', '', 42750, NULL, 'Yes', NULL),
(133, 'Lab 602: Analog and Digital Communication Lab', 'QPSK : Mod/Demod System Trainer', '1', 'COM117', 'KJSIEIT/ET/DC-TK/020', 'Techno scientific Co.', 'BR/005/06', 'BR/005/06', '2006-12-04', '2279', '  36000', '', '', '', '', '', '', 38475, NULL, 'Yes', NULL),
(134, 'Lab 602: Analog and Digital Communication Lab', 'Measurement of Bandwidth Efficiency of QPSK', '1', 'QPSK101', 'KJSIEIT/ET/DC-TK/021', 'Techno scientific Co.', 'BR/005/06', 'BR/005/06', '2006-12-04', '2279', '  32500', '', '', '', '', '', '', 34734, NULL, 'Yes', NULL),
(135, 'Lab 602: Analog and Digital Communication Lab', 'Minimum Shift Keying Trainer', '1', 'MSK100', 'KJSIEIT/ET/DC-TK/022', 'Techno scientific Co.', 'BR/005/06', 'BR/005/06', '2006-12-04', '2279', '  72500', '', '', '', '', '', '', 77484, NULL, 'Yes', NULL),
(136, 'Lab 602: Analog and Digital Communication Lab', 'Digital Multimeter, Autorange, 1000V DC / 1000V AC KM-6040', '1', '994904', 'KJSIEIT/ET/DMM/025', 'KUSUM MECO', '2730', '2730', '2009-11-09', '3751', '  1402', '', '', '', '', '', '', 1577, NULL, 'Yes', NULL),
(137, 'Lab 602: Analog and Digital Communication Lab', 'Hal-Tech Digital Trainer kit              Model:HLTPDT-09LP', '10', 'DLDA/01/02/03/04/05/06/07/08/09/10', 'KJSIEIT/ET/DE-TK/001-010', 'M/S Hal-Tech Plus', '902/06', '902/06', '2009-09-24', '3730', '12000', '', '', '', '', '', '', 94500, NULL, 'Yes', NULL),
(138, 'Lab 602: Analog and Digital Communication Lab', 'DSO Rigol : DS1102E 100MHz \r\n\r\n\r\n\r\n', '5', '810102/ 810104/ 810105/ 810106 /810107', 'KJSIEIT/ET/DSO/007-011', 'Automate Process Control', 'APC:91/APC:82', 'APC:91/APC:82', '2010-08-31', '13', '  83,250', '', '', '', '', '', '', 437062, NULL, 'Yes', NULL),
(139, 'Lab 602: Analog and Digital Communication Lab', 'Canon Laser Jet Printer LBP2900', '1', '97410', 'KJSIEIT/ET/PRN/005', 'M/S Nitya Infotech', 'NIM/409/ AUG/11-12', 'NIM/409/ AUG/11-12', '2011-08-10', '242', '5400.00', '', '', '', '', '', '', 5400, NULL, 'Yes', NULL),
(140, 'Lab 603: RF Communication Lab', 'Laptop with Carry Case \r\nModel: HP Probook 440 G8 (3V7N0PA)', '1', '5CD1220Z79', 'KJSIEIT/ET/LC/012', 'HP', 'NIP/JUN21/325', 'NIP/JUN21/325', '2021-06-21', '4051', '45400', '', '', '', '', '', '', 53572, NULL, 'Yes', NULL),
(141, 'Lab 603: RF Communication Lab', 'Advanced Motorised Antenna Trainer \r\nMake: Akademika', '1', '1811019', 'KJSIEIT/ET/TK-RF/005', 'Akademika', 'ASL/18-19/0144', 'ASL/18-19/0144', '2019-02-01', '3349', '155200', '', '', '', '', '', '', 183136, NULL, 'Yes', NULL),
(142, 'Lab 602: Analog and Digital Communication Lab', 'Amplitude Mod/Demod Trainer\r\n\r\nAmplitude Mod/Demod Trainer\r\nAmplitude Mod/Demod Trainer\r\n\r\n\r\n', '4', 'BCT-01/01 BCT-01/02 BCT-01/03 BCT-01/04', 'KJSIEIT/ET/AC-TK/013-016', 'M/S Kitek Technologies', '38', '38', '2011-08-17', '314', '3800', '', '', '', '', '', '', 11115, NULL, 'Yes', NULL),
(143, 'Lab 602: Analog and Digital Communication Lab', 'Frequency Mod/Demod Trainer\r\n\r\n\r\n', '4', 'BCT-02/01 BCT-02/02 BCT-02/03 BCT-02/04', 'KJSIEIT/ET/AC-TK/017 -020', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '3800			 			', '', '', '', '', '', '', 11115, NULL, 'Yes', NULL),
(144, 'Lab 602: Analog and Digital Communication Lab', 'Anolog Signal sampling & Reconstruction trainer\r\n', '2', 'ACT-01/01 ACT-01/02', 'KJSIEIT/ET/AC-TK/021 - 022', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '7500', '', '', '', '', '', '', 10969, NULL, 'Yes', NULL),
(145, 'Lab 602: Analog and Digital Communication Lab', 'PAM,PPM,PWM Mod/Demod Trainer\r\n', '2', 'ACT-04/01 ACT-04/02', 'KJSIEIT/ET/DC-TK/042-043', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '12500', '', '', '', '', '', '', 18281, NULL, 'Yes', NULL),
(146, 'Lab 602: Analog and Digital Communication Lab', 'TDM Pulse Code Modulation Transmitter Trainer\r\n', '2', 'ACT-04/01 ACT-04/02', 'KJSIEIT/ET/DC-TK/044 -045', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '12500', '', '', '', '', '', '', 18281, NULL, 'Yes', NULL),
(147, 'Lab 601: Basic Electronics and PCB Lab', 'TDM Pulse Code Demodulation Receiver Trainer\r\n', '2', 'ACT-05/01 ACT-05/02', 'KJSIEIT/ET/DC-TK/046-047', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '12500', '', '', '', '', '', '', 18281, NULL, 'Yes', NULL),
(148, 'Lab 602: Analog and Digital Communication Lab', 'Delta,Adaptive Delta& Sigma Mod/Demod Trainer\r\n', '2', 'ACT-06/01 ACT-06/02', 'KJSIEIT/ET/DC-TK/048 -049', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '12500', '', '', '', '', '', '', 18281, NULL, 'Yes', NULL),
(149, 'Lab 602: Analog and Digital Communication Lab', 'TDM Pulse Code Demodulation Receiver Trainer\r\n', '2', 'ACT-05/01 ACT-05/02', 'KJSIEIT/ET/DC-TK/046-047', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '12500', '', '', '', '', '', '', 18281, NULL, 'Yes', NULL),
(150, 'Lab 602: Analog and Digital Communication Lab', 'Delta,Adaptive Delta& Sigma Mod/Demod Trainer\r\n', '2', 'ACT-06/01 ACT-06/02', 'KJSIEIT/ET/DC-TK/048-049', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '12500', '', '', '', '', '', '', 18281, NULL, 'Yes', NULL),
(151, 'Lab 602: Analog and Digital Communication Lab', 'Data Conditioning Kit\r\n', '2', 'ACT-07T/01ACT-07T/02', 'KJSIEIT/ET/DC-TK/050-051', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '12500', '', '', '', '', '', '', 18281, NULL, 'Yes', NULL),
(152, 'Lab 602: Analog and Digital Communication Lab', 'Data Reconditioning Kit\r\n', '2', 'ACT-07R/01 ACT-07R/02', 'KJSIEIT/ET/DC-TK/052 -053', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '12500', '', '', '', '', '', '', 18281, NULL, 'Yes', NULL),
(153, 'Lab 602: Analog and Digital Communication Lab', 'Base Band Transmission/Reception Kit\r\n\r\n\r\n\r\n', '5', 'ADCT-04/  01-05', 'KJSIEIT/ET/DC-TK/054-058', 'M/S Kitek Technologies', '138', '138', '2011-08-17', '314', '16500', '', '', '', '', '', '', 60328, NULL, 'Yes', NULL),
(154, 'Lab 602: Analog and Digital Communication Lab', 'Hal-Tech Digital Trainer kit HLTPDT-09LP', '5', 'DLDA/11/12/13/14/15', 'KJSIEIT/ET/DE-TK/011-015', 'M/S Hal-Tech Plus', '6/901', '6/901', '2011-09-19', '314', '10150', '', '', '', '', '', '', 53288, NULL, 'Yes', NULL),
(155, 'Lab 603: RF Communication Lab', 'Fibre Optics Communication Trainer Kit\r\nMake : Kitek\r\nModel:  9521460047 (FOCT-01)', '1', '200101', 'KJSIEIT/ET/TK-FOC/001 ', 'Kitek', '190', 'm-190', '2020-01-20', '3858', '12870', '', '', '', '', '', '', 15187, NULL, 'Yes', NULL),
(156, 'Lab 602: Analog and Digital Communication Lab', 'DSB / SSB AM Transmitter Trainer\r\n\r\n', '1', 'ACT-08/01 ,02 ,03', 'KJSIEIT/ET/AC-TK/023 - 025', 'M/S Kitek Technologies', '32/73', '32/73', '2011-11-21', '0', '18500', '', '', '', '', '', '', 13528, NULL, 'Yes', 'remark'),
(157, 'Lab 602: Analog and Digital Communication Lab', 'DSB / SSB AM Receiver Trainer\r\n\r\n\r\n\r\n', '2', 'ACT-09/02-03', 'KJSIEIT/ET/AC-TK/027-028', 'M/S Kitek Technologies', '32/73', '32/73', '2011-11-21', '0', '18500', '', '', '', '', '', '', 27718, NULL, 'Yes', NULL),
(158, 'Lab 602: Analog and Digital Communication Lab', 'FM Transmitter Receiver Trainer\r\n\r\n\r\n', '4', 'ACT-10/01 ACT-10/02 ACT-10/03 ACT-10/04', 'KJSIEIT/ET/AC-TK/029 -032', 'M/S Kitek Technologies', '32/73', '32/73', '2011-11-21', '0', '18500', '', '', '', '', '', '', 54113, NULL, 'Yes', NULL),
(159, 'Lab 603: RF Communication Lab', 'Fibre Optics Communication Trainer Kit\r\nMake : Kitek\r\nModel:  9521460047 (FOCT-01)', '1', '200102', 'KJSIEIT/ET/TK-FOC/002', 'Kitek', '190', 'M-190', '2020-01-20', '3858', '12870', '', '', '', '', '', '', 15187, NULL, 'Yes', NULL),
(160, 'Lab 603: RF Communication Lab', 'Fibre Optics Communication Trainer Kit\r\nMake : Kitek\r\nModel:  9521460047 (FOCT-01)', '1', '200103', 'KJSIEIT/ET/TK-FOC/003 ', 'Kitek', '190', 'M-190', '2020-01-23', '3858', '12870', '', '', '', '', '', '', 15187, NULL, 'Yes', NULL),
(161, 'Lab 603: RF Communication Lab', 'Fibre Optics Communication Trainer Kit\r\nMake : Kitek\r\nModel:  9521460047 (FOCT-01)', '1', '200104', 'KJSIEIT/ET/TK-FOC/004 ', 'Kitek', '190', 'M-190', '2022-01-23', '3858', '12870', '', '', '', '', '', '', 15187, NULL, 'Yes', NULL),
(162, 'Lab 603: RF Communication Lab', 'Fibre Optics Communication Trainer Kit\r\nMake : Kitek\r\nModel:  9521460047 (FOCT-01) ', '1', '200105', 'KJSIEIT/ET/TK-FOC/005', 'Kitek', '190', 'M-190', '2020-01-23', '3858', '12870', '', '', '', '', '', '', 15187, NULL, 'Yes', NULL),
(163, 'Lab 603: RF Communication Lab', 'Fibre Optics Communication Trainer Kit\r\nMake : Kitek\r\nModel:  9521460047 (FOCT-01)', '1', '200106', 'KJSIEIT/ET/TK-FOC/006 ', 'Kitek', '190', 'M-190', '2020-01-23', '3858', '12870', '', '', '', '', '', '', 15187, NULL, 'Yes', NULL),
(164, 'Lab 603: RF Communication Lab', 'Desktop  Computer \r\nLenovo [ThinkCentre A70 Series (0864-E4Q)] ', '2', 'L930968 L930997', 'KJSIEIT/ET/DC/061 KJSIEIT/ET/DC/062', 'Lenovo', 'MSPL/11-12/APR/01156', 'MSPL/11-12/APR/01156', '2011-06-09', 'G I 200', '25400', '', '', '', '', '', '', 53540, NULL, 'Yes', NULL),
(165, 'Lab 603: RF Communication Lab', 'Desktop Computer, \r\nLenovo LN S510 10KWA00BHF', '1', 'PG00RUAU', 'KJSIEIT/ET/DC/117', 'Lenovo', 'JBA/0308/16-17', 'JBA/0308/16-17', '2016-09-02', '1914', '32000', '', '', '', '', '', '', 32760, NULL, 'Yes', NULL),
(166, 'Lab 603: RF Communication Lab', 'Desktop Computer\r\nLenovo LN S510 10KWA00BHF ', '1', 'PG00RUAX', 'KJSIEIT/ET/DC/118', 'Lenovo', 'JBA/0308/16-17', 'JBA/0308/16-17', '2016-09-02', '1914', '32000', '', '', '', '', '', '', 33760, NULL, 'Yes', NULL),
(167, 'Lab 603: RF Communication Lab', 'Desktop Computer\r\nLenovo LN S510 10KWA00BHF ', '1', 'PG00RUA5', 'KJSIEIT/ET/DC/122', 'Lenovo', 'JBA/0308/16-17', 'JBA/0308/16-17', '2016-09-02', '1914', '32000', '', '', '', '', '', '', 33760, NULL, 'Yes', NULL),
(168, 'Lab 603: RF Communication Lab', 'Desktop Computer\r\nLenovo LN S510 10KWA00BHF ', '1', 'PG00RUAF', 'KJSIEIT/ET/DC/124', 'Lenovo', 'JBA/0308/16-17', 'JBA/0308/16-17', '2016-09-02', '1914', '32000', '', '', '', '', '', '', 33760, NULL, 'Yes', NULL),
(169, 'Lab 603: RF Communication Lab', 'Desktop Computer\r\nLenovo LN S510 10KWA00BHF ', '1', 'PG00RUB8', 'KJSIEIT/ET/DC/125', 'Lenovo', 'JBA/0308/16-17', 'JBA/0308/16-17', '2016-09-02', '1914', '32000', '', '', '', '', '', '', 33760, NULL, 'Yes', NULL),
(170, 'Lab 603: RF Communication Lab', 'Desktop Computer\r\nLenovo LN S510 10KWA00BHF ', '1', 'PG00RUAS', 'KJSIEIT/ET/DC/127', 'Lenovo', 'JBA/0308/16-17', 'JBA/0308/16-17', '2016-09-02', '1914', '32000', '', '', '', '', '', '', 33760, NULL, 'Yes', NULL),
(171, 'Lab 603: RF Communication Lab', 'Desktop Computer\r\nLenovo LN S510 10KWA00BHF', '1', 'PG00RU9R', 'KJSIEIT/ET/DC/128', 'Lenovo', 'JBA/0308/16-17', 'JBA/0308/16-17', '2016-09-02', '1914', '32000', '', '', '', '', '', '', 33760, NULL, 'Yes', NULL),
(172, 'Lab 701: Software Simulation and Networking Lab', 'GSM GPRS Training System', '1', '-', '-', 'Automate Process Control', 'APC 154', 'APC 154', '2013-01-11', '672', ' 109044 ', '', '', '', '', '', '', 109044, NULL, 'Yes', NULL),
(173, 'Lab 603: RF Communication Lab', 'CRO Dual Trace, 30 MHz,\r\nMake : Aplab\r\nModel: 3706C ', '1', 'HO03OSC0915235 ', 'KJSIEIT/ET/CRO/035 ', 'Aplab', '15300193', '1510000000000910', '2015-09-30', '1574', '15000', '', '', '', '', '', '', 17719, NULL, 'Yes', NULL),
(174, 'Lab 603: RF Communication Lab', 'CRO Dual Trace, 30 MHz,\r\nMake : Aplab\r\nModel: 3706C', '1', 'HO03OSC0915236 ', 'KJSIEIT/ET/CRO/036 ', 'Aplab', '15300193', '1510000000000910', '2015-09-15', '1914', '15000', '', '', '', '', '', '', 17719, NULL, 'Yes', NULL),
(175, 'Lab 603: RF Communication Lab', 'CRO Dual Trace, 30 MHz,\r\nMake : Aplab\r\nModel: 3706C ', '1', 'HO03OSC0915237 ', 'KJSIEIT/ET/CRO/037 ', 'Aplab', '15300193', '1510000000000910', '2015-09-30', '1914', '15000', '', '', '', '', '', '', 17719, NULL, 'Yes', NULL),
(176, 'Lab 603: RF Communication Lab', 'CRO Dual Trace, 30 MHz,\r\nMake : Aplab\r\nModel: 3706C ', '1', 'HO03OSC0915238', 'KJSIEIT/ET/CRO/038', 'Aplab', '15300193', '1510000000000910', '2015-09-30', '1574', '15000', '', '', '', '', '', '', 17719, NULL, 'Yes', NULL),
(177, 'Lab 603: RF Communication Lab', 'CRO Dual Trace, 30 MHz,\r\nMake : Aplab\r\nModel: 3706C ', '1', 'HO03OSC0915242', 'KJSIEIT/ET/CRO/039', 'Aplab', '15300193', '1510000000000910', '2015-09-30', '1574', '15000', '', '', '', '', '', '', 17719, NULL, 'Yes', NULL),
(178, 'Lab 701: Software Simulation and Networking Lab', 'HP PRODESK400 G7 MT PC 9CY16AV INTEL CORE i3 8GB DDR4 2666 DIMM Memory 512 GB SSD RAM\r\n', '20', '4CE214CGTC 4CE214CGSG 4CE214CGT1 4CE214CGT8 4CE214CGTK 4CE214CGT6 4CE214CGT4 4CE214CGTD 4CE214CGTN 4CE214CGSR 4CE214CGTF 4CE214CGV0 4CE214CGT9 4CE214CGSK 4CE214CGSZ 4CE214CGT2 4CE214CGTV 4CE214CGTR 4CE214CGTY 4CE214CGSP', 'KJSIEIT/ET/DC/186 TO KJSIEIT/ET/DC/205', 'NEPTUNE INFOSOLUTIONS PVT LTD', 'NIPL MAY22 O76', 'PO IEIT0048 21 22', '2022-05-04', '4276', '41125', '', '', '', '', '', '', 970550, NULL, 'Yes', NULL),
(179, 'Lab 603: RF Communication Lab', 'DTH Receiver System \r\nMake : Scientech\r\nModel:  ST2664 ', '1', '0901570', 'KJSIEIT/ET/TK-TV/009', 'Scientech', '1941516', 'CH-117-1516', '2015-09-18', '1508', '19620', '', '', '', '', '', '', 22072, NULL, 'Yes', NULL),
(180, 'Lab 603: RF Communication Lab', 'DTH Receiver System \r\nMake : Scientech\r\nModel:  ST2664 ', '1', '0901571', 'KJSIEIT/ET/TK-TV/010 ', 'Scientech', '1941516', 'CH-117-1516', '2015-09-18', '1508', '19620', '', '', '', '', '', '', 22073, NULL, 'Yes', NULL),
(181, 'Lab 701: Software Simulation and Networking Lab', 'Bluetooth link Demonstrator BTL 01 ', '2', '-', '-', 'Automate Process Control', 'APC-67', '-', '2011-08-24', '-', '24543', '', '', '', '', '', '', 49087, NULL, 'Yes', NULL),
(182, 'Lab 701: Software Simulation and Networking Lab', 'LBP 2900 Laser Printer\r\n', '1', 'MBGA778816', 'KJSIEIT ET PRN 004', 'Maruti Compusystems', '482', '-', '2011-05-12', '180', ' 5500', '', '', '', '', '', '', 5500, NULL, 'Yes', NULL),
(183, 'Lab 603: RF Communication Lab', 'LCD  TV Trainers Jig with Monitor ', '1', 'FTL21508201', 'KJSIEIT/ET/TK-TV/006', 'Funfirst', '2015-16/03', '2015-16/03', '2015-05-20', '1469', '57422', '', '', '', '', '', '', 64600, NULL, 'Yes', NULL),
(184, 'Lab 701: Software Simulation and Networking Lab', 'HP Laser jet pro M1136 MFP\r\n', '1', 'CNG7D6YJ7P', 'KJSIEIT/ET/PRN/008', 'Nitya Infotech', 'NIM/358/DEC/12-13', '-', '2013-01-04', '597', '19200', '', '', '', '', '', '', 19200, NULL, 'Yes', NULL),
(185, 'Lab 603: RF Communication Lab', 'LCD  TV Trainers Jig with Monitor ', '1', 'FTL21508202', 'KJSIEIT/ET/TK-TV/007 ', 'Funfirst', '2015-16/03', '2015-16/03', '2015-08-20', '1469', '57422', '', '', '', '', '', '', 64600, NULL, 'Yes', NULL),
(186, 'Lab 701: Software Simulation and Networking Lab', 'Wireless LAN Trainer \r\n', '2', '-', '-', 'Advance Electronic Industries', '58/15-16', '71/15-16', '2015-08-10', '1608', '41250', '', '', '', '', '', '', 41250, NULL, 'Yes', NULL),
(187, 'Lab 603: RF Communication Lab', 'LCD  TV Trainers Jig with Monitor ', '1', 'FTL21508203', 'KJSIEIT/ET/TK-TV/008', 'Funfirst', '2015-16/03', '2015-16/03', '2015-08-20', '1469', '57422', '', '', '', '', '', '', 64600, NULL, 'Yes', NULL),
(188, 'Lab 701: Software Simulation and Networking Lab', 'Zigbee Trainer\r\n', '2', '-', '-', 'Advance Electronic Industries', '58/15-16', '71/15-16', '2015-08-10', '1607', '41125', '', '', '', '', '', '', 92813, NULL, 'Yes', NULL),
(189, 'Lab 701: Software Simulation and Networking Lab', 'WIFI Trainer\r\n', '2', '-', '-', 'Advance Electronic Industries', '58/15-16', '71/15-16', '2015-08-10', '1610', '41125', '', '', '', '', '', '', 92813, NULL, 'Yes', NULL),
(190, 'Lab 701: Software Simulation and Networking Lab', 'Dell Latitude 3490 Laptop Intel i3-7131', '1', '380VXR2', 'KJSIEIT/ET/LC/008', 'Pentagon system and services Pvt. Ltd.', 'MH1819', '1575', '2018-09-10', '-', '37000', '', '', '', '', '', '', 37000, NULL, 'Yes', NULL),
(191, 'Lab 701: Software Simulation and Networking Lab', 'GW -ANALOG OSCILOSCOPE MODEL GOS-630FC', '2', 'EL894768 EM854636', 'KJSIEIT/ET/CRO/033 KJSIEIT/ET/CRO/034', 'ADM', 'APC 137', 'APC 137', '2013-01-04', '608', '20562', '', '', '', '', '', '', 44887, NULL, 'Yes', NULL),
(192, 'Lab 603: RF Communication Lab', 'Fiber Optics Trainer Kit', '2', '85101 85102', 'KJSIEIT/ET/TK-OFC/09 KJSIEIT/ET/TK-OFC/10', 'Advance Electronic Industries', '44/15-16', '44/15-16', '2015-07-09', '1609', '11812', '', '', '', '', '', '', 23625, NULL, 'Yes', NULL),
(193, 'Lab 603: RF Communication Lab', 'Fiber Optics Trainer Kit', '1', '1844', 'KJSIEIT/ET/TK-OFC/07', 'Scientech', '204/08-09', '204/08-09', '2009-10-05', '3442', '11603', '', '', '', '', '', '', 11603, NULL, 'Yes', NULL),
(194, 'Lab 603: RF Communication Lab', 'FDM Mux/Demux Trainer', '1', '1843', 'KJSIEIT/ET/TK-OFC/06', 'Scientech', '204/08-09', '204/08-09', '2009-10-05', '3442', '10803', '', '', '', '', '', '', 10803, NULL, 'Yes', NULL),
(195, 'Lab 601: Basic Electronics and PCB Lab', 'Laser Fiber Optics Trainer Kit(Transmitter & Receiver) ST2506 ', '1', '1016598', 'KJSIEIT/ET/TK-OFC/13', 'Scientech', 'ET-118/16-17 ', 'ET-118/16-17 ', '2016-12-06', '2945', '33514', '', '', '', '', '', '', 33514, NULL, 'Yes', NULL),
(196, 'Lab 603: RF Communication Lab', 'Optical Power Meter ST2551', '2', '616461 1116972', 'KJSIEIT/ET/TK-OFCM/03 KJSIEIT/ET/TK-OFCM/04', 'Scientech', 'ET-118/16-17 ', 'ET-118/16-17 ', '2016-12-06', '2945', '15941', '', '', '', '', '', '', 31882, NULL, 'Yes', NULL),
(197, 'Lab 602: Analog and Digital Communication Lab', 'Dell Optilex 390DT Intel Core i3-2100 (3.10GHz, 3MB L2 Cache), Intel H61 Express Chipset, 4GB DDR-3 (1333MHz) RAM, 500GB SATA HDD (7200 RPM), DVD Writer, Std. USB Keyboard, USB Optical Scroll Mouse, LAN 10/100/1000 mbps Integrated, Dell 18.5\" WXGA TFT, Integrated HD Graphics, Audio, No. Internal Speaker, No OS.\r\n\r\n\r\n', '4', '7WZ78R1, 7X1K8R1, 7WYQ8R1, 7WZQWQ1', 'KJSIEIT/ET/DC/065 -067,102', 'Radiant Tradevest Pvt. Ltd.', '278', '278', '2012-01-09', '329', '25529', '', '', '', '', '', '', 107200, NULL, 'No', NULL),
(198, 'Lab 602: Analog and Digital Communication Lab', 'Agilent 100MHz DSO 1012A\r\n\r\n\r\n\r\n', '5', 'CN53101119 ,CN53101127 ,CN53121256 ,CN53121279 ,CN53121421', 'KJSIEIT/ET/DSO/012 -016', 'M/S Advance Electronic Industries', '133/13-14', '133/13-14', '2013-07-30', '777', '76500', '', '', '', '', '', '', 430312, NULL, 'Yes', NULL),
(199, 'Lab 602: Analog and Digital Communication Lab', 'Digit DMM 4&3/4 4&1/2 Auto Range Desktop Digital Multimeter\r\n\r\n\r\n\r\n', '5', '992810978;  992811000;  992811013;  992811015;  991557688', 'KJSIEIT/ET/DMM/051 - 055', 'M/S Advance Electronic Industries', '133/13-14', '133/13-14', '2013-07-30', '7777', '17200', '', '', '', '', '', '', 96750, NULL, 'Yes', NULL),
(200, 'Lab 601: Basic Electronics and PCB Lab', 'Digital Handy Multimeter MASTECH [M92A(H)] \r\n\r\n\r\n', '4', '11090070744; ;  11090070875;  11090070878 11090070881', 'KJSIEIT/ET/DMM/056-059', 'M/S Advance Electronic Industries', '133/13-14', '133/13-14', '2013-07-30', '777', '2000', '', '', '', '', '', '', 9000, NULL, 'Yes', NULL),
(201, 'Lab 602: Analog and Digital Communication Lab', 'Lenovo Desktop LN S510 10KXA00BHF\r\n\r\n\r\n\r\n\r\n', '6', 'PG00RUB6 ,PG00RUAD , PG00RUAM, PG00RUAN, PG00RUAY ,PG00RUA7', 'KJSIEIT/ET/DC/112-116, 121', 'JBA Infosolutions', 'JBA/0308/16-17', 'JBA/0308/16-17', '2016-09-02', '0', '32000', '', '', '', '', '', '', 202560, NULL, 'Yes', NULL),
(202, 'Lab 602: Analog and Digital Communication Lab', 'DSB/AMTransmitter Trainer\r\n', '2', 'ACT-08/04 ,ACT-08/05', 'KJSIEIT/ET/AC-TK/032 -033', 'M/S Kitek Technologies', '139', '139', '2016-10-10', '2572', '9000', '', '', '', '', '', '', 23040, NULL, 'Yes', NULL),
(203, 'Lab 602: Analog and Digital Communication Lab', 'DSB/SSB Reciever Trainer', '1', 'ACT-09/04', 'KJSIEIT/ET/AC-TK/034', 'M/S Kitek Technologies', '139', '139', '2017-10-10', '2572', '9000', '', '', '', '', '', '', 11520, NULL, 'Yes', NULL),
(204, 'Lab 602: Analog and Digital Communication Lab', 'CRO (3706 C Aplab,  30MHz Dual Trace CTC, 140mm)\r\n\r\n', '3', 'HO03OSC0319036, HO03OSC0319037, HO03OSC0319038', 'KJSIEIT/ET/CRO/055-057', 'Aplab Limited', '18300721', '18300721', '2019-03-20', '3491', '16500', '', '', '', '', '', '', 58410, NULL, 'Yes', NULL),
(205, 'Lab 602: Analog and Digital Communication Lab', '\"ASK Mod/Dmod Trainer 9521460043 (BCT-12)\r\n\"\r\n\r\n\r\n\r\n', '5', '200112, 200113, 200114 ,200115 ,200116', 'KJSIEIT/ET/DC-TK/059 - 063', 'M/S Kitek Technologies', '190', '190', '2020-01-23', '3858', '4173', '', '', '', '', '', '', 24621, NULL, 'Yes', NULL),
(206, 'Lab 602: Analog and Digital Communication Lab', 'FSK Mod/Dmod Trainer 9521460044 (BCT-11\r\n\r\n\r\n\r\n', '5', '200107, 200108, 200109, 200110, 200111', 'KJSIEIT/ET/DC-TK/064-068', 'M/S Kitek Technologies', '190', '190', '2020-01-23', '3858', '4160', '', '', '', '', '', '', 24544, NULL, 'Yes', NULL),
(207, 'Lab 602: Analog and Digital Communication Lab', 'PSK Mod/Dmod Trainer 9521460043 (BCT-13) \r\n\r\n\r\n\r\n', '5', '200117, 200118 ,200119 ,200120, 200121', 'KJSIEIT/ET/DC-TK/069 -073', 'M/S Kitek Technologies', '190', '190', '2020-01-23', '3858', '4173', '', '', '', '', '', '', 24621, NULL, 'Yes', NULL),
(208, 'Lab 602: Analog and Digital Communication Lab', 'QPSK/DQPSK Demodulation Kit 9521460046 (ADCT-03)\r\n\r\n\r\n\r\n', '5', '200127 ,200128 ,200129, 200130, 200131,', 'KJSIEIT/ET/DC-TK/074 -078', 'M/S Kitek Technologies', '190', '190', '2020-01-23', '3858', '11025', '', '', '', '', '', '', 65047, NULL, 'Yes', NULL),
(209, 'Lab 602: Analog and Digital Communication Lab', 'QPSK/DQPSK Modulation Kit 9521460045 (ADCT-02)\r\n\r\n\r\n\r\n', '5', '200122, 200123, 200124, 200125, 200126', 'KJSIEIT/ET/DC-TK/079 - 083', 'M/S Kitek Technologies', '190', '190', '2020-01-23', '3858', '  11,025.00', '', '', '', '', '', '', 65047, NULL, 'Yes', 'remark'),
(210, 'Lab 602: Analog and Digital Communication Lab', 'CRO (3706 C Aplab,  30MHz Dual Trace CTC, 140mm)\r\n', '2', 'H0030SC1217358 H0030SC1217359', 'KJSIEIT/ET/CRO/044 -045', 'Aplab Limited', '17300509', '17300509', '2017-12-30', '3491', '  20,000.00', '', '', '', '', '', '', 39648, NULL, 'Yes', NULL);
INSERT INTO `items` (`id`, `lab_no`, `description`, `quantity`, `equipment no`, `college code`, `manufacturer`, `invoice`, `challan_no`, `date`, `gi_no`, `rate`, `discount`, `discounted rate`, `vat`, `rate with vat`, `octri`, `rate_with_octri`, `total_cost`, `path`, `defective`, `remark`) VALUES
(211, 'Lab 604: Microwave and Satellite Communication Lab', 'NVIS Electricity Lab\r\n', '1', 'NV6000', 'KJSIEIT/ET/TK-EWT/01', 'M/S-Automate Process Control', 'APC:201     APC:192', 'APC:201     APC:192', '2009-03-31', '3494', ' 13036', '', '', '', '', '', '', 13036, NULL, 'Yes', NULL),
(212, 'Lab 604: Microwave and Satellite Communication Lab', 'Gauss & Tesla Meter\r\n', '1', 'NV621', 'KJSIEIT/ET/TK-EWT/03', 'M/S-Automate Process Control', 'APC:201     APC:192', 'APC:201     APC:192', '2009-03-31', '3494', ' 13036', '', '', '', '', '', '', 13036, NULL, 'Yes', NULL),
(213, 'Lab 604: Microwave and Satellite Communication Lab', '1Hz to 1.2GHz RF Synthesizer Hameg HM-8134, Frequency Resolution 1Hz, Output Power from-127dBm to +13dBm, AM/FM/PM & Gate Modulation\r\n', '1', '043870017', 'KJSIEIT/ET/RFS/001', 'M/S-Automate Process Control', '\"APC-87/ APC-86\"', '\"APC-87/ APC-86\"', '2009-09-07', '3724', '558200', '', '', '', '', '', '', 558200, NULL, 'Yes', NULL),
(214, 'Lab 604: Microwave and Satellite Communication Lab', '1Hz to 3GHz RF Synthesizer Hameg HM-8135, Output power from-135dBm to +13dBm, Modulation Modes-AM, FM, Pulse, FSK, PSK, Rs-232 Interface, Optional:USB,IEEE-488\r\n\r\n', '1', '055410010', 'KJSIEIT/ET/RFS/002', 'M/S-Automate Process Control', '\"APC-88/ APC-87\"', '\"APC-88/ APC-87\"', '2009-09-08', '3724', '761183', '', '', '', '', '', '', 761183, NULL, 'Yes', NULL),
(215, 'Lab 604: Microwave and Satellite Communication Lab', 'Spectrum Analyzer, 1000 MHz, Analog, Scientech Caddo-8010\r\n\r\n', '2', '50928, 50929', 'KJSIEIT/ET/SA/001-002', 'M/S-Automate Process Control', '\"APC-90/  APC-89\"', '\"APC-90/  APC-89\"', '2009-09-14', '3724', '100032', '', '', '', '', '', '', 200064, NULL, 'Yes', NULL),
(216, 'Lab 604: Microwave and Satellite Communication Lab', 'LG-3GHz-Spectrum Analyzer, 1 KHz-3GHz, Digital LIGNex1 NS-30A\r\n', '1', '70916', 'KJSIEIT/ET/SA/003', 'M/S-Automate Process Control', '\"APC-90/  APC-89\"', '\"APC-90/  APC-89\"', '2009-09-14', '3724', '691792', '', '', '', '', '', '', 691792, NULL, 'Yes', NULL),
(217, 'Lab 604: Microwave and Satellite Communication Lab', 'Adtron - Klystron Based Microwave Bench\r\n', '1', 'MWB02', 'KJSIEIT/ET/TK-MW/02', 'M/S-Advance Electronic Industries', '376/09-10', '376/09-10', '2009-11-16', '3751', '90000', '', '', '', '', '', '', 90000, NULL, 'Yes', NULL),
(218, 'Lab 604: Microwave and Satellite Communication Lab', 'Scientech - Model No : ST2272 Satellite Communication Trainer, Uplink Transmitter:Transmit 3 signals simultaneously at each up-linking frequency, Satellite Link:Transponder with selectable frequency conversion, Downlink Receiver:Receives & demodulate 3 signals simultaneously\r\n', '1', '310175', 'KJSIEIT/ET/TK-SCOM/01', 'M/S-Automate Process Control', 'APC:09', 'APC:09', '2010-04-19', '3834', '143778', '', '', '', '', '', '', 143778, NULL, 'Yes', NULL),
(219, 'Lab 604: Microwave and Satellite Communication Lab', 'Rigol DS1102E-100MHz,DSO, Smpling -1GS/s – 1 channel on 500MS/s – 2 channels on, Memory Depth-16kpoints – 1 channel on8kpoints – 2 channels on, Trigger Modes-Edge, Pulse Width, Slope, Video, Alternate, Automatic Measurement-22 voltage & time measurements & cursor measurement, Connectivity-USB device & host, RS232\r\n', '1', '810103', 'KJSIEIT/ET/DSO/006', 'M/S-Automate Process Control', 'APC:91      APC:82', 'APC:91      APC:82', '2010-08-31', '013', '87413', '', '', '', '', '', '', 87413, NULL, 'Yes', NULL),
(220, 'Lab 604: Microwave and Satellite Communication Lab', 'Radar Trainer Kit(NV2001)\r\n', '1', '711227', 'KJSIEIT/ET/TK-RE/01', 'M/S-Automate Process Control', 'APC:58     APC:53', 'APC:58     APC:53', '2011-08-09', '254', '114750', '', '', '', '', '', '', 114750, NULL, 'No', NULL),
(221, 'Lab 604: Microwave and Satellite Communication Lab', 'Kitek-LVDT Trainer Kit, LVDT transducer with transparent enclouser, Displacement of ±5mm, Primary Excitation voltage of Sine wave 1V p-p\r\nKitek-LVDT Trainer Kit, LVDT transducer with transparent enclouser, Displacement of ±5mm, Primary Excitation voltage of Sine wave 1V p-p\r\n\r\n\r\n\r\n\r\n', '3', 'LVDT01-03', 'KJSIEIT/ET/TK-EI/01-03', 'M/S-Kitek Technologies', '138', '138', '2011-08-17', '314', '9287', '', '', '', '', '', '', 27861, NULL, 'Yes', NULL),
(222, 'Lab 604: Microwave and Satellite Communication Lab', 'Kitek-Strain Guage Trainer Kit,Resistive load cell is used to measure load up to 3 kgs.Primary excitation voltage of 12V DC.\r\n\r\n\r\n', '3', 'SG01-03', 'KJSIEIT/ET/TK-EI/04-06', 'M/S-Kitek Technologies', '138', '138', '2011-08-17', '314', '9287', '', '', '', '', '', '', 27861, NULL, 'Yes', NULL),
(223, 'Lab 604: Microwave and Satellite Communication Lab', 'Kitek-RTD Trainer Kit, PT-100 Type RTD Sensor, temperature measured upto 100°C\r\n\r\n\r\n', '3', 'RTD01-03', 'KJSIEIT/ET/TK-EI/07-09', 'M/S-Kitek Technologies', '138', '138', '2011-08-17', '314', '4461', '', '', '', '', '', '', 13383, NULL, 'Yes', NULL),
(224, 'Lab 604: Microwave and Satellite Communication Lab', 'Klystron Power Supply\r\n', '1', 'KPS01', 'KJSIEIT/ET/MW-KPS/01', 'M/S-Advance Electronic Industries', '218/11-12', '218/11-12', '2011-08-24', '285', '19688', '', '', '', '', '', '', 19688, NULL, 'Yes', NULL),
(225, 'Lab 604: Microwave and Satellite Communication Lab', 'Gunn Power Supply, Bias voltage 0 to 10V, Current 0 to 750mA(Max), Modulation Amp. 0 to 15V(P-P)\r\n\r\n', '2', 'GPS01-02', 'KJSIEIT/ET/MW-GPS/01-02', 'M/S-Advance Electronic Industries', '237/11-12', '237/11-12', '2011-09-06', '378', '7481', '', '', '', '', '', '', 14963, NULL, 'Yes', NULL),
(226, 'Lab 604: Microwave and Satellite Communication Lab', 'CANON - Laser Jet Printer LBP2900B\r\n', '1', 'MHPA206844', 'KJSIEIT/ET/PRN/006', 'M/S-Nitya Infotech', 'NIM/298/SEP/11-12', 'NIM/298/SEP/11-12', '2011-09-10', '266', '5425', '', '', '', '', '', '', 5425, NULL, 'Yes', NULL),
(227, 'Lab 604: Microwave and Satellite Communication Lab', 'Adtron - Klystron Based Microwave Bench\r\n\r\n', '1', 'MWB03-04', 'KJSIEIT/ET/TK-MW/03-04', 'M/S-Advance Electronic Industries', '260/11-12', '260/11-12', '2011-09-21', '378', '70875', '', '', '', '', '', '', 141750, NULL, 'Yes', NULL),
(228, 'Lab 601: Basic Electronics and PCB Lab', 'Dell Optilex 390DT Intel Core i3-2100 (3.10GHz, 3MB L2 Cache), Intel H61 Express Chipset, 4GB DDR-3 (1333MHz) RAM, 500GB SATA HDD (7200 RPM), DVD Writer, Std. USB Keyboard, USB Optical Scroll Mouse, LAN 10/100/1000 mbps Integrated, Dell 18.5\" WXGA TFT, Integrated HD Graphics, Audio, No. Internal Speaker, No OS.', '3', '7X2M7R1 /  7WZ98R1 /  7WZV8R1 ', 'KJSIEIT/ET/DC/109,104,105', 'Radiant Tradevest pvt. Ltd.', '278', '278', '2012-01-09', '329', '26800', '', '', '', '', '', '', 80400, NULL, 'Yes', NULL),
(229, 'Lab 604: Microwave and Satellite Communication Lab', 'Triple Band Radio Signal Generator\r\n', '1', 'RG-2003', 'KJSIEIT/ET/TK-AMERSG/01', 'M/S-Automate Process Control', 'APC:127     APC:119', 'APC:127     APC:119', '2011-10-31', '303', '223125', '', '', '', '', '', '', 223125, NULL, 'Yes', NULL),
(230, 'Lab 604: Microwave and Satellite Communication Lab', 'RMS Voltage Measurement Kit \r\n\r\n\r\n', '3', 'RMS01-03', 'KJSIEIT/ET/TK-EI/10-12', 'M/S-Kitek Technologies', '32/73', '32/73', '2011-11-21', '314', '6216', '', '', '', '', '', '', 18648, NULL, 'Yes', NULL),
(231, 'Lab 604: Microwave and Satellite Communication Lab', 'Microwave Active Circuits Design\r\n', '3', 'MSA 2003-02,03,05    ', 'KJSIEIT/ET/TK-AME/01-03', 'M/S-Automate Process Control', 'APC:127     APC:119', 'APC:127     APC:119', '2011-10-31', '303', '478125', '', '', '', '', '', '', 478125, NULL, 'Yes', NULL),
(232, 'Lab 604: Microwave and Satellite Communication Lab', 'DELL Personal Computers: Dell Optiplex 390DT, Intel Core i3 2100(3.10GHz, 3MB L2 Cache) Intel H61 Express Chipset, 4GB DDR-3(1333MHz)RAM, 500GB SATA HDD(7200RPM), DVD Writer, Std. USB Keyboard, USB Optical Mouse, LAN10/100/1000mbps Integrated, Dell 18.5\" WXGA TFT, Integrated HD Graphics, Audio, No Int. Spk, No OS.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n', '8', '7WZX8R1,7XZN7R1,7X2P7R1,7X2N7R1,7WZ38R1,7WXYYR1,7WYL7R1,7WZG8R1,', 'KJSIEIT/ET/DC/093, 95-98,102,110,111', 'M/S-Radiant Tradevest Pvt Ltd.', '278', '278', '2012-01-09', '329', '26800', '', '', '', '', '', '', 214400, NULL, 'Yes', NULL),
(233, 'Lab 604: Microwave and Satellite Communication Lab', '4 1/2-Auto Range Bench Top Digital Multimeter: Reading Rates per second Slow: 3; Fast: 5-7, Maximum Input750V rms, 1000peak \r\n\r\n', '2', '996373461, 996373463', 'KJSIEIT/ET/DMM/066-067', 'M/S-Advance Electronic Industries', '02/14-15', '02/14-15', '2014-04-04', '952', '17213', '', '', '', '', '', '', 34426, NULL, 'Yes', NULL),
(234, 'Lab 604: Microwave and Satellite Communication Lab', 'Desktop  Lenovo LN S510 10KXA00BHF (3-6100/4GB/500GB/WIN10SLHOME) with 19.5\" TFT 60DFAAR1WW,HDD ,32 GB DDR4, 2133 MHz - 2 x DIMM Slots, 500 GB / 1 TB, 7200 rpm SSD : 2.5\" 120 GB / 128 GB / 192 GB / 256 GB,Tower : Starting at 16.9 lbs (7.65 kg) SFF : Starting at 9.1 lbs (4.13 kg)\r\n', '1', 'PG00RUAZ', 'KJSIEIT/ET/DC/122', 'M/S-JBA Infosolutions', 'JBA/0309/16-17', 'JBA/0309/16-17', '2016-09-02', '1-2', '33760', '', '', '', '', '', '', 33760, NULL, 'Yes', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `repair`
--

CREATE TABLE `repair` (
  `id` int(11) NOT NULL,
  `lab_no` varchar(100) NOT NULL,
  `rep_calib` varchar(30) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `concerned_person` varchar(100) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `date` varchar(15) NOT NULL,
  `cost` varchar(11) NOT NULL,
  `remark` varchar(300) DEFAULT NULL,
  `path` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `repair`
--

INSERT INTO `repair` (`id`, `lab_no`, `rep_calib`, `company_name`, `concerned_person`, `mobile_no`, `date`, `cost`, `remark`, `path`) VALUES
(7, 'Lab 604: Microwave and Satellite Communication Lab', 'Calibrated', 'APLAB', 'K.Pashte', '9753102468', '2022-04-04', '', 'Multimeter', NULL),
(14, 'Lab 701: Software Simulation and Networking Lab', 'Repair', 'Oscar Technologies', '-', '-', '2013-01-19', '  1,150.00 ', 'Product name:Linksys WMP 54G PCI LAN Adapter', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `scrap`
--

CREATE TABLE `scrap` (
  `id` int(11) NOT NULL,
  `lab_no` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `equipment_sr_no` varchar(20) NOT NULL,
  `college_code` varchar(30) NOT NULL,
  `company` varchar(200) NOT NULL,
  `date_of_purchase` varchar(15) NOT NULL,
  `cost` varchar(11) NOT NULL,
  `reason` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `scrap`
--

INSERT INTO `scrap` (`id`, `lab_no`, `description`, `equipment_sr_no`, `college_code`, `company`, `date_of_purchase`, `cost`, `reason`) VALUES
(13, 'Lab 703: Signal Processing Lab', 'Dell Optilex 390DT Intel Core i3-2100 (3.10GHz, 3MB L2 Cache), Intel H61 Express Chipset, 4GB DDR-3 (1333MHz) RAM, 500GB SATA HDD (7200 RPM), DVD Writer, Std. USB Keyboard, USB Optical Scroll Mouse, LAN 10/100/1000 mbps Integrated, Dell 18.5\" WXGA TFT, Integrated HD Graphics, Audio, No. Internal Speaker, No OS.', '7WZT7R1', 'KJSIEIT/ET/DC/073-082', 'Radiant Tradevest Pvt. Ltd.', '2012-09-01', '  26,800.00', 'Not Working'),
(14, 'Lab 703: Signal Processing Lab', 'Dell Optilex 390DT Intel Core i3-2100 (3.10GHz, 3MB L2 Cache), Intel H61 Express Chipset, 4GB DDR-3 (1333MHz) RAM, 500GB SATA HDD (7200 RPM), DVD Writer, Std. USB Keyboard, USB Optical Scroll Mouse, LAN 10/100/1000 mbps Integrated, Dell 18.5\" WXGA TFT, Integrated HD Graphics, Audio, No. Internal Speaker, No OS.', '7X0Z8R1', 'KJSIEIT/ET/DC/073-082', 'Radiant Tradevest Pvt. Ltd.', '2012-09-01', '  26,800.00', 'Not Working');

-- --------------------------------------------------------

--
-- Table structure for table `software`
--

CREATE TABLE `software` (
  `id` int(11) NOT NULL,
  `lab_no` varchar(50) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `quantity` varchar(11) NOT NULL,
  `no_users` varchar(11) NOT NULL,
  `server_based` varchar(50) NOT NULL,
  `license_no` varchar(100) NOT NULL,
  `license_expiry` varchar(15) NOT NULL,
  `institute_code` varchar(20) NOT NULL,
  `supplier` varchar(300) NOT NULL,
  `invoice` varchar(11) NOT NULL,
  `date_purchase` varchar(15) NOT NULL,
  `gi_no` varchar(20) NOT NULL,
  `rate_vat` varchar(11) NOT NULL,
  `total_cost` varchar(11) NOT NULL,
  `path` varchar(200) DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  `remark` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `software`
--

INSERT INTO `software` (`id`, `lab_no`, `description`, `quantity`, `no_users`, `server_based`, `license_no`, `license_expiry`, `institute_code`, `supplier`, `invoice`, `date_purchase`, `gi_no`, `rate_vat`, `total_cost`, `path`, `status`, `remark`) VALUES
(3, 'Lab 701: Software Simulation and Networking Lab', 'Core 2 Duo desktop,Lenovo A70Ser with 18.5 wide monitor\r\n\r\n\r\n\r\n\r\n\r\n', '7', '', 'Stand alone', 'L901862', '2010-03-04', 'KJSIEIT/ET/DC/027', '', '20020910', '2010-03-04', '151', '26500', '185500', NULL, 'Not Working', ''),
(4, 'Lab 605: Microcontoller and Microprocessor Lab', 'MS Office - 2003 Professional', '10', '10', 'Stand alone', '-', '2005-03-28', '-', 'LDS Infotech Pvt. Ltd.', '1168', '2005-03-28', '1851', '1,650.00', '37950.00', NULL, 'Working', ''),
(5, 'Lab 605: Microcontoller and Microprocessor Lab', 'Proteus Virtual System Modeling (VSM) Software', '5', '1', 'Stand alone', '-', '2009-09-23', '-', 'Designtech System Ltd', '20091022', '2009-09-23', '3734', '  25,500.00', '132600.00', NULL, 'Working', ''),
(6, 'Lab 604: Microwave and Satellite Communication Lab', 'SIMTEL Physics Software Single User', '1', '1', 'Stand alone', '101906', '', '691', 'M/S-Automate Process Control', '201192', '2009-03-31', '3494', ' 23,400.00 ', '23400.00', NULL, 'Working', 'Working'),
(7, 'Lab 605: Microcontoller and Microprocessor Lab', '8051 Development Suite C-Cross Compiler, Simulator, Assembler, IDE for 8051 smart pointer Facility essential', '5', '', 'Stand alone', '-', '2013-12-04', '-', 'ADM Pvt. Ltd.', '081503', '2013-01-04', '608', '218,993', '218993', NULL, 'Working', ''),
(8, 'Lab 605: Microcontoller and Microprocessor Lab', '8051 Cross Dev. Suite with Hardware Lock to USB port + ARM Cross Dev. Suite with Hardware Lock to USB port + Software CD + \r\nUSB Cables + User Manuals', '5', '5', 'Stand alone', '-', '2014-08-28', '-', 'ADM Pvt. Ltd.', '081503', '2014-08-28', '1465', '115888.5', '579442', NULL, 'Working', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `lab_no` varchar(200) NOT NULL,
  `role` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `lab_no`, `role`) VALUES
(1, 'admin', '12345', 'admin', NULL),
(6, 'pupadhay', 'lab601', 'Lab 601: Basic Electronics and PCB Lab', NULL),
(7, 'kmugale', 'tech601', 'Lab 601: Basic Electronics and PCB Lab', NULL),
(8, 'hpatil', 'tech602', 'Lab 602: Analog and Digital Communication Lab', NULL),
(9, 'tdhake', 'lab602', 'Lab 602: Analog and Digital Communication Lab', NULL),
(10, 'cwagh', 'tech603', 'Lab 603: RF Communication Lab', NULL),
(11, 'phatode', 'lab603', 'Lab 603: RF Communication Lab', NULL),
(12, 'stikekar', 'tech604', 'Lab 604: Microwave and Satellite Communication Lab', NULL),
(13, 'kiran.rathod', 'lab604', 'Lab 604: Microwave and Satellite Communication Lab', NULL),
(14, 'punam.always', 'tech605', 'Lab 605: Microcontoller and Microprocessor Lab', NULL),
(15, 'rashmi', 'lab605', 'Lab 605: Microcontoller and Microprocessor Lab', NULL),
(16, 'nilka', 'tech701', 'Lab 701: Software Simulation and Networking Lab', NULL),
(17, 'pkamble', 'lab701', 'Lab 701: Software Simulation and Networking Lab', NULL),
(18, 'ychavan', 'tech703', 'Lab 703: Signal Processing Lab', NULL),
(19, 'harshwardhan', 'lab703', 'Lab 703: Signal Processing Lab', NULL),
(20, 'sandhyakadam', 'lab709', 'Lab 709: Project Lab', NULL);

--
-- Indexes for dumped tables
--
CREATE TABLE `components` (
  `Sr_no` int(3) NOT NULL,
  `id` int(11) NOT NULL,
  `lab_no` varchar(60) NOT NULL,
  `Description` varchar(1500) NOT NULL,
  `Quantity` varchar(3) NOT NULL,
  `Equipment_Serial_No` varchar(100) NOT NULL,
  `Supplier/Manufacturer` varchar(300) NOT NULL,
  `Invoice` varchar(20) NOT NULL,
  `Date_of_Purchase` date NOT NULL,
  `gi_no` varchar(20) NOT NULL,
  `Rate` int(10) NOT NULL,
  `Total_Cost` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `components` (`Sr_no`,`id`, `lab_no`, `Description`, `Quantity`, `Equipment_Serial_No`, `Supplier/Manufacturer`, `Invoice`, `Date_of_Purchase`, `gi_no`,`Rate`, `Total_Cost`) VALUES
(1,46,'Lab 703: Signal Processing Lab','DSP Texas 320F228016 based Daughter Board with XDS 100 USB based Emulator, USB Cable, 14 Pin Flat Cable for XDS 100 Emulator, User Manual, Software CD',1,'1601','Applied Digital Microsystems Pvt. Ltd.','71112','2011-07-28','G.1.235',45376.00,47644.80),
(2,47,'Lab 703: Signal Processing Lab','DSP Starter Kit for TMS30C6713 Includes 16 MEG SDRAM, USB Cable, Power Cord, AC-DC Adapter with Instruction Manual',1,'-','Applied Digital Microsystems Pvt. Ltd.','31310','2013-03-22','G.1.681',47063.00,49416.00),
(3,60,'Lab 703: Signal Processing Lab','DSP Texas 320F228016 based Daughter Board with XDS 100 USB based Emulator, USB Cable, 14 Pin Flat Cable for XDS 100 Emulator, User Manual, Software CD',1,'1601','Applied Digital Microsystems Pvt. Ltd.','71112','2011-07-28','G.1.235',45376.00,47644.80),
(4,66,'Lab 604: Microwave and Satellite Communication Lab','The Link - Klystron Based Microwave Bench, Model-TL2001X-Band(8.2 to 12.4 GHz) Solid State Digital Klystron Power Supply(with AM/FM Modulation), Klystron Tube 2k25 or its equivalent, Waveguide Detector Mount with IN23 diode, Variable Attenuator(0-20dB)',1,'MWB01','M/S-The Link','TL/A-3/51 & 54','2005-03-16','1885',159520.00,159520.00),
(5,72,'Lab 604: Microwave and Satellite Communication Lab','The Link - Klystron Based Microwave Bench, Model-TL2001X-Band(8.2 to 12.4 GHz) Solid State Digital Klystron Power Supply(with AM/FM Modulation), Klystron Tube 2k25 or its equivalent, Waveguide Detector Mount with IN23 diode, Variable Attenuator(0-20dB)',1,'25','M/S-The Link','TL/A-3/51 & 54','2005-05-16','1885',159520.00,159520.00),
(6,73,'Lab 605: Microcontoller and Microprocessor Lab','Universal Programmer (Labtool-48UXP) with Cable & connector Set and KBD (6)',1,'AE0603000163','Dyanlog (I) Limited','DIL-480/003107','2006-06-20','2355',42670.00,47471.00),
(7,74,'Lab 605: Microcontoller and Microprocessor Lab','Logic Analyser with Integrated Digital Test System LG 320 + CPLD/EPGA Trainer Model',1,'170','Applied Digital Microsystems Pvt. Ltd.','050601','2006-06-02','2314',175000.00,159250.00),
(8,77,'Lab 605: Microcontoller and Microprocessor Lab','Laptop Lenovo (Model B450-A59-02-8950) with carry case',1,'EB16682696','Bluecom Technologies Pvt. Ltd.','BT/0250/10-11 CS/5681','2010-05-14','3831',30952.00,32500.00),
(9,78,'Lab 605: Microcontoller and Microprocessor Lab','Logic Analyser hosted / upgradable Universal Trainer / Development System + Xilinx FPGA Spartan 3XC3S400 Daughter board & Serial EPROM + JTAG Connector + 89c51RD2 Daughter Board + ARM7 LPC21xx Daughter Board with cable + PIC 18F4520 Daughter Board with onboard ISP',5,'1809, 1810, 1815, 1816, 1818','Applied Digital Microsystems Pvt. Ltd.','011303','2013-01-04','G.1.608',41377.00,217229.00),
(10,98,'Lab 601: Basic Electronics and PCB Lab','Function Generator Scientech 2 mhz',4,'02102501/02102547/02102551/02102553','Automate Process Control','APC-09/APC-09','2010-04-19','3834',88844.00,41988.00),
(11,107,'Lab 601: Basic Electronics and PCB Lab','Digital Storage oscilloscope 100 mhz(Model-DS 1102E)',2,'0810100-0810101','Automate Process Control','APC-82/APC-91','2010-09-01','13',83250.00,174825.00),
(12,114,'Lab 601: Basic Electronics and PCB Lab','GW-DMM -GDM-8261',2,'EM170132 / EM170152','Automate Process Control','APC-154','2013-01-11','139',56875.00,135008.00),
(13,129,'Lab 602: Analog and Digital Communication Lab','CRO Four Trace, 100 MHz Scientific SM511',1,'412040','Automate Process Control','APC-47/ APC-49','2005-02-27','1817',56425.00,61909.00),
(14,135,'Lab 602: Analog and Digital Communication Lab','Minimum Shift Keying Trainer',1,'MSK100','Techno scientific Co.','BR/005/06','2006-12-04','2279',72500.00,77484.00),
(15,138,'Lab 602: Analog and Digital Communication Lab','DSO Rigol : DS1102E 100MHz',5,'810102/ 810104/ 810105/ 810106 /810107','Automate Process Control','APC:91/APC:82','2010-08-31','13',83250.00,437062.00),
(16,140,'Lab 603: RF Communication Lab','Laptop with Carry Case Model: HP Probook 440 G8 (3V7N0PA)',1,'5CD1220Z79','HP','NIP/JUN21/325','2021-06-21','4051',45400.00,53572.00),
(17,141,'Lab 603: RF Communication Lab','Advanced Motorised Antenna Trainer Make: Akademika',1,'1811019','Akademika','ASL/18-19/0144','2019-02-01','3349',155200.00,183136.00),
(18,172,'Lab 701: Software Simulation and Networking Lab','GSM GPRS Training System',1,'-','Automate Process Control','APC 154','2013-01-11','672',109044.00,109044.00),
(19,183,'Lab 603: RF Communication Lab','LCD TV Trainers Jig with Monitor',1,'FTL21508201','Funfirst','2015-16/03','2015-05-20','1469',57422.00,64600.00),
(20,185,'Lab 603: RF Communication Lab','LCD TV Trainers Jig with Monitor',1,'FTL21508202','Funfirst','2015-16/03','2015-05-20','1469',57422.00,64600.00),
(21,186,'Lab 701: Software Simulation and Networking Lab','Wireless LAN Trainer',2,'-','Advance Electronic Industries','58/15-16','2015-08-10','1608',41250.00,41250.00),
(22,187,'Lab 603: RF Communication Lab','LCD TV Trainers Jig with Monitor',1,'FTL21508202','Funfirst','2015-16/03','2015-05-20','1469',57422.00,64600.00),
(23,188,'Lab 701: Software Simulation and Networking Lab','Zigbee Trainer',2,'-','Advance Electronic Industries','58/15-16','2015-08-10','1607',41125.00,92813.00),
(24,189,'Lab 701: Software Simulation and Networking Lab','WIFI Trainer',2,'-','Advance Electronic Industries','58/15-16','2015-08-10','1610',41125.00,92813.00),
(25,198,'Lab 602: Analog and Digital Communication Lab','Agilent 100MHz DSO 1012A',5,'CN53101119 ,CN53101127 ,CN53121256 ,CN53121279 ,CN53121421','M/S Advance Electronic Industries','133/13-14','2013-07-30','777',76500.00,430312.00),
(26,213,'Lab 604: Microwave and Satellite Communication Lab','1Hz to 1.2GHz RF Synthesizer Hameg HM-8134, Frequency Resolution 1Hz, Output Power from-127dBm to +13dBm, AM/FM/PM & Gate Modulation',1,'043870017','M/S-Automate Process Control','APC-87/ APC-86','2009-09-07','3724',558200.00,558200.00),
(27,214,'Lab 604: Microwave and Satellite Communication Lab','1Hz to 3GHz RF Synthesizer Hameg HM-8135, Output power from-135dBm to +13dBm, Modulation Modes-AM, FM, Pulse, FSK, PSK, Rs-232 Interface, Optional:USB,IEEE-488',1,'055410010','M/S-Automate Process Control','APC-88/ APC-87','2009-09-08','3724',761183.00,761183.00),
(27,215,'Lab 604: Microwave and Satellite Communication Lab','Spectrum Analyzer, 1000 MHz, Analog, Scientech Caddo-8010',2,'50928, 50929','M/S-Automate Process Control','APC-90/ APC-89','2009-09-14','3724',100032.00,200064.00),
(28,216,'Lab 604: Microwave and Satellite Communication Lab','LG-3GHz-Spectrum Analyzer, 1 KHz-3GHz, Digital LIGNex1 NS-30A',1,'70916','M/S-Automate Process Control','APC-90/ APC-89','2009-09-14','3724',691792.00,691792.00),
(29,217,'Lab 604: Microwave and Satellite Communication Lab','Adtron - Klystron Based Microwave Bench',1,'MWB02','M/S-Advance Electronic Industries','376/09-10','2009-11-16','3751',90000.00,90000.00),
(29,218,'Lab 604: Microwave and Satellite Communication Lab','Scientech - Model No : ST2272 Satellite Communication Trainer, Uplink Transmitter:Transmit 3 signals simultaneously at each up-linking frequency, Satellite Link:Transponder with selectable frequency conversion, Downlink Receiver:Receives & demodulate 3 signals simultaneously',1,'310175','M/S-Automate Process Control','APC:09','2010-04-19','3834',143778.00,143778.00),
(30,219,'Lab 604: Microwave and Satellite Communication Lab','Rigol DS1102E-100MHz,DSO, Smpling -1GS/s – 1 channel on 500MS/s – 2 channels on, Memory Depth-16kpoints – 1 channel on8kpoints – 2 channels on, Trigger Modes-Edge, Pulse Width, Slope, Video, Alternate, Automatic Measurement-22 voltage & time measurements & cursor measurement, Connectivity-USB device & host, RS232',1,'810103','M/S-Automate Process Control','APC:91 APC:82','2010-08-31','013',87413.00,87413.00),
(31,220,'Lab 604: Microwave and Satellite Communication Lab','Radar Trainer Kit(NV2001)',1,'711227','M/S-Automate Process Control','APC:58 APC:53','2011-08-09','254',114750.00,114750.00),
(32,227,'Lab 604: Microwave and Satellite Communication Lab','Adtron - Klystron Based Microwave Bench',1,'MWB03-04','M/S-Advance Electronic Industries','260/11-12','2011-09-21','378',70875.00,141750.00),
(33,229,'Lab 604: Microwave and Satellite Communication Lab','Triple Band Radio Signal Generator',1,'RG-2003','M/S-Automate Process Control','APC:127 APC:119','2011-10-31','303',223125.00,223125.00),
(34,231,'Lab 604: Microwave and Satellite Communication Lab','Microwave Active Circuits Design',3,'MSA 2003-02,03,05','M/S-Automate Process Control','APC:127 APC:119','2011-10-31','303',478125.00,478125.00);
--
-- Indexes for table `borrower`
--
ALTER TABLE `borrower`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repair`
--
ALTER TABLE `repair`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scrap`
--
ALTER TABLE `scrap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `software`
--
ALTER TABLE `software`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `components`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrower`
--
ALTER TABLE `borrower`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- AUTO_INCREMENT for table `repair`
--
ALTER TABLE `repair`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `scrap`
--
ALTER TABLE `scrap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `software`
--
ALTER TABLE `software`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

ALTER TABLE `components`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
