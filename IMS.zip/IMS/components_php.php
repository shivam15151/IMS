<?php

include('connect.php');

$id = $_POST["id"];

$lab_no = $_POST["lab_no"];

$description = $_POST["Description"];

$quantity = $_POST["Quantity"];

$equ_sr_no = $_POST["Equipment_Serial_No"];

$maf = $_POST["Supplier/Manufacturer"];

$invoice = $_POST["Invoice"];

$dop = $_POST["Date_of_Purchase"];

$gi_no = $_POST["gi_no"];

$rate = $_POST["Rate"];

$total = $_POST["Total_Cost"];



$sql = "INSERT INTO `components`(`id`, `lab_no`, `Description`, `Quantity`, `Equipment_Serial_No`, `Supplier/Manufacturer`, `Invoice`, `Date_of_Purchase`, `gi_no`, `Rate`, `Total_Cost`) Value ('$id','$lab_no', '$description', '$quantity', '$equ_sr_no', '$maf', '$invoice' , '$dop', '$gi_no', '$rate', '$total')";

$result = $conn->query($sql);

if($result === TRUE){

    echo '<script>

	alert("Component Added Sucessfully");

	window.location = "add item.php";</script>';

}else{

	echo '<script>

	alert("Something went Wrong! Please try Again.");

	window.location = "add item.php";</script>'; 

}


?>