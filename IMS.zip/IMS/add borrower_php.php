<?php

include('connect.php');

$from_lab = $_POST["lab_from"];

$description = $_POST["description"];

$to_lab = $_POST["lab_to"];

$remark = $_POST["remark"];

$sql = "INSERT INTO `borrower`(`from_lab`, `description`, `to_lab`, `remark`) VALUES ('$from_lab','$description','$to_lab','$remark')";

$result = $conn->query($sql);

if($result === TRUE){

  echo '<script>

  alert("Item Added Sucessfully");

 window.location = "borrower.php";

  </script>';

}else{

  echo '<script>

  alert("Something went Wrong! Please try Again.");

  window.location = "add borrower.php";</script>'; 

}

?>