<?php
include('connect.php');
    $id= $_GET['id'];
$sql = "DELETE FROM `scrap` WHERE `id`= '$id'";
$result = $conn->query($sql);
if($result === TRUE){
  echo '<script>
  confirm("Item Deleted Sucessfully");
  window.location = "scrap.php";</script>';
}else{
  echo '<script>
  alert("Something went Wrong! Please try Again.")</script>'; 
}
?>