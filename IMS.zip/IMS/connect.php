<?php

 $conn= new mysqli("localhost","root","","id15573716_labm");

	if($conn->connect_error)

	{

		die("connection failed: " . $conn->connect_error());

	}

?>