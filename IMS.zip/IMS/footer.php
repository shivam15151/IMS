<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="footer.css" rel="stylesheet">
</head>
<body>
<footer> 


<div class="footer">
        <div class="Logos">
            <a href="https://kjsit.somaiya.edu.in/en" target="_blank"><img src="somlogo.png" alt="Somaiya Logo"></a>
        </div>
        <div class="social-links">
            <a href="https://www.facebook.com/kjsieitofficial" target="_blank" class="facebook"><img src="facebook.logo.png" style="width: 30px; height: 30px;"  alt="Facbook"></a>
            <a href="https://www.instagram.com/kjsieit_22/"  target="_blank" class="instagram" ><img src="insta.logo.png" style="width: 30px; height: 30px;"  alt="insta"></a>
            <a href="https://twitter.com/kjsieit1" target="_blank" class="twitter"><img src="twitter.logo.png" style="width: 30px; height: 30px;"  alt="twitter"></a>        
            <a href="https://www.youtube.com/kjsieitofficial" target="_blank" class="google-plus"><img src="youtube.logo.png" style="width: 30px; height: 30px;"  alt="youtube"></a>
            <a href="https://www.linkedin.com/in/kjsieit/" target="_blank" class="linkedin"><img src="linkedin.logo.png" style="width: 30px; height: 30px;"  alt="linkedin"></a>

        </div>
<div class="prepare">

    <p >
        <b>Prepared By:<br> Department of Artificial Intelligence and Data Science<br>
        Guided By:<br>  Dr. Milind Nemade,<br> Prof. Vidya Sagvekar<br>
        Team Members: <a href="https://www.linkedin.com/in/jasveer-saini-505499248" target="_blank">Jasveer Saini</a>, <a href="https://www.linkedin.com/in/abhiram-acharya-7839aa245" target="_blank">Abhiram Acharya</a>, <a href="https://www.linkedin.com/in/shivam-gupta-02b240285" target="_blank">Shivam Gupta</a>, <a href="https://www.linkedin.com/in/aakash-pandey-78b588257"  >Aakash Pandey</a>, <a href="https://www.linkedin.com/in/harshada-sutar-159782248" target="_blank">Harshada Sutar</a>            </b>
    </p>
</div>
</div>
     




  </footer>
</body>
</html>

