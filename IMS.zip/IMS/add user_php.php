<?php
include('connect.php');
$username = $_POST["username"];
$passw = $_POST["pass"];
$lab_no = $_POST["lab_no"];
$sql = "INSERT INTO `users`(`username`,`password`,`lab_no`) VALUES ('$username','$passw','$lab_no')";
$result = $conn->query($sql);
if($result === TRUE){
  echo '<script>
  alert("User Added Sucessfully")
  window.location= "profile.php"</script>';
}else{
  echo '<script>
  alert("Something went Wrong! Please try Again.")</script>'; 
}
?>