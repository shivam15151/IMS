<?php

include('connect.php');

$lab_no = $_POST["lab_no"];

$description = $_POST["description"];

$quantity = $_POST["qty"];

$equ_sr_no = $_POST["eqp_no"];

$clg_code = $_POST["code"];

$maf = $_POST["maf"];

$invoice = $_POST["inv"];

$chal = $_POST["chal"];

$dop = $_POST["date"];

$gi_no = $_POST["gi_no"];

$rate = $_POST["rate"];

$dis = $_POST["dis"];

$dis_rate = $_POST["dis_rate"];

$vat = $_POST["vat"];

$rate_vat = $_POST["rate_vat"];

$octri = $_POST["octri"];

$oct_rate = $_POST["oct_rate"];

$Lab_in_Charge_Name = $_POST["Lab_in_Charge_Name"];

$Name_of_HOD = $_POST["Name_of_HOD"];

$total = $_POST["total"];

$defective = $_POST["defective"];

$img = rand(1000,100000)."-".$_FILES['img']['name'];

$img_loc = $_FILES['img']['tmp_name'];

$img_size = $_FILES['img']['size'];

$img_type = $_FILES['img']['type'];

$img_location="uploads/";

$new_img_size = $img_size/1024; 

$new_img_name = strtolower($img);

$final_img=str_replace(' ','-',$new_img_name);

if(move_uploaded_file($img_loc,$img_location.$final_img)){

$sql = "INSERT INTO `items`(`lab_no`, `description`, `quantity`, `equipment no`, `college code`, `manufacturer`, `invoice`,`challan_no`, `date`, `gi_no`, `rate`,`discount`, `discounted rate`, `vat`, `rate with vat`,` octri`, `rate_with_octri`, `Lab_in_Charge_Name`, `Name_of_HOD`, `total_cost`, `path`, `defective`) VALUES ('$lab_no', '$description', '$quantity', '$equ_sr_no', '$clg_code', '$maf', '$invoice' ,'$chal', '$dop', '$gi_no', '$rate','$dis', '$dis_rate','$vat', '$rate_vat','$octri','$oct_rate', '$Lab_in_Charge_Name' , '$Name_of_HOD' , '$total', 'uploads/$final_img', '$defective')";

$result = $conn->query($sql);

if($result === TRUE){

    echo '<script>

	alert("Item Added Sucessfully");

	window.location = "add item.php";</script>';

}else{

	echo '<script>

	alert("Something went Wrong! Please try Again.");

	window.location = "add item.php";</script>'; 

}

}else{

$sql = "INSERT INTO `items`(`lab_no`, `description`, `quantity`, `equipment no`, `college code`, `manufacturer`, `invoice`,`challan_no`, `date`, `gi_no`, `rate`,`discount`, `discounted rate`, `vat`, `rate with vat`,`octri`, `rate_with_octri`, `Lab_in_Charge_Name`, `Name_of_HOD`, `total_cost`, `path`, `defective`) VALUES ('$lab_no', '$description', '$quantity', '$equ_sr_no', '$clg_code', '$maf', '$invoice' ,'$chal', '$dop', '$gi_no', '$rate','$dis', '$dis_rate','$vat', '$rate_vat','$octri','$oct_rate', '$Lab_in_Charge_Name', '$Name_of_HOD' , '$total', '$defective')";

$result = $conn->query($sql);

if($result === TRUE){

    echo '<script>

	alert("Item Added Sucessfully");

	window.location = "add item.php";</script>';

}else{

	echo '<script>

	alert("Something went Wrong! Please try Again.");window.location = "add item.php";

	</script>'; 

}

}

?>