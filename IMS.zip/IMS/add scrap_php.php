<?php
include('connect.php');
$lab_no = $_POST["lab_no"];
$description = $_POST["description"];
$equ_sr_no = $_POST["eqp_no"];
$clg_code = $_POST["code"];
$maf = $_POST["maf"];
$dop = $_POST["date"];
$cost_vat = $_POST["cost_vat"];
$reason = $_POST["reason"];
$sql = "INSERT INTO `scrap`(`lab_no`, `description`, `equipment_sr_no`,`college_code`, `company`, `date_of_purchase`, `cost`, `reason`) VALUES ('$lab_no','$description','$equ_sr_no','$clg_code','$maf','$dop','$cost_vat','$reason')";
$result = $conn->query($sql);
if($result === TRUE){
  echo '<script>
  alert("Item Added Sucessfully");
  window.location = "scrap.php";</script>';
}else{
  echo '<script>
  alert("Something went Wrong! Please try Again.");
  window.location = "add scrap.php";</script>'; 
}
?>