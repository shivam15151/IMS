<?php
include('connect.php');
$lab = $_POST["lab"];
$rep_cal = $_POST["rep_cali"];
$com_nam = $_POST["com_name"];
$con_pe = $_POST["con_per"];
$mobi_no = $_POST["mob_no"];
$date = $_POST["dor"];
$cost = $_POST["cost"];
$remark = $_POST["rem"];
$img = rand(1000,100000)."-".$_FILES['img']['name'];
$img_loc = $_FILES['img']['tmp_name'];
$img_size = $_FILES['img']['size'];
$img_type = $_FILES['img']['type'];
$img_location="uploads/";
$new_img_size = $img_size/1024; 
$new_img_name = strtolower($img);
$final_img=str_replace(' ','-',$new_img_name);
if(move_uploaded_file($img_loc,$img_location.$final_img)){
$sql = "INSERT INTO `repair`(`lab_no`,`rep_calib`, `company_name`, `concerned_person`, `mobile_no`, `date`, `cost`, `remark`, `path`) VALUES ('$lab','$rep_cal','$com_nam','$con_pe','$mobi_no','$date','$cost','$remark','uploads/$final_img')";
$result = $conn->query($sql);
if($result === TRUE){
  echo '<script>
  alert("Item Added Sucessfully");
  window.location = "repair.php";</script>';
}else{
  echo '<script>
  alert("Something went Wrong! Please try Again.")</script>'; 
}
}else{$sql = "INSERT INTO `repair`(`lab_no`,`rep_calib`, `company_name`, `concerned_person`, `mobile_no`, `date`, `cost`, `remark`) VALUES ('$lab','$rep_cal','$com_nam','$con_pe','$mobi_no','$date','$cost','$remark')";
$result = $conn->query($sql);
if($result === TRUE){
  echo '<script>
  alert("Item Added Sucessfully");
  window.location = "repair.php";</script>';
}else{
  echo '<script>
  alert("Something went Wrong! Please try Again.")</script>'; 
}
}
?>