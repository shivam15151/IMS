<?php

include('connect.php');

session_start();

if (! (isset ( $_SESSION ['login'] ))) {

	header ( 'location:index.php' );

}

$sql = "SELECT * FROM `items` WHERE `lab_no` = 'Lab 603: RF Communication Lab'";

$result = $conn->query($sql);

$counter=0;

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <style type="text/css">.disclaimer { display: none; }</style><meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="">

    <meta name="author" content="">

    <title> IMS </title>

    <!-- Custom fonts for this template-->

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-xymdQtn1n3lH2wcu0qhcdaOpQwyoarkgLVxC/wZ5q7h9gHtxICrpcaSUfygqZGOe" crossorigin="anonymous"></script>


    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->

    <link href="css/sb-admin-2.min.css" rel="stylesheet">

          <link href="bg-color.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->

    <div id="wrapper">

        <!-- Sidebar -->

        <!-- Sidebar -->

        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->

            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">

                <div class="sidebar-brand-icon rotate-n-15">

                    <i class="#"></i>

                </div>

                <div class="sidebar-brand-text mx-3"><?php echo $_SESSION['login']; ?></div>

            </a>

            <!-- Divider -->

            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->

            <li class="nav-item active">

                <a class="nav-link" href="dashboard.php">

                    <i class="fas fa-fw fa-tachometer-alt"></i>

                    <span>Dashboard</span></a>

            </li>

            <!-- Divider -->

            <hr class="sidebar-divider">

            <!-- Nav Item - Utilities Collapse Menu -->

            <li class="nav-item">

                <a class="nav-link" href="profile.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Profile</span>

                </a>

            <li class="nav-item">

                <a class="nav-link" href="add item.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Add Items</span>

                </a>

            <li class="nav-item">

                <a class="nav-link" href="room.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Room</span>

                </a>

            <li class="nav-item">

                <a class="nav-link" href="hardware inv.php">

                    <i class="fas fa-fw fa-wrench"></i>

                    <span>Inventory</span>

                </a>

                <!-- Divider -->

                <hr class="sidebar-divider">

                <!-- Nav Item - Charts -->

            <li class="nav-item">

                <a class="nav-link" href="defective.php">

                    <i class="fas fa-fw fa-chart-area"></i>

                    <span>Defectives</span></a>

            </li>

            <li class="nav-item">

                <a class="nav-link" href="borrower.php">

                    <i class="fa fa-users"></i>

                    <span>Borrower</span></a>

            </li>

            <!-- Nav Item - Tables -->

            <li class="nav-item">

                <a class="nav-link" href="repair.php">

                    <i class="fas fa-fw fa-table"></i>

                    <span>Repair</span></a>

            </li>

            <!-- Nav Item - Charts -->

           

            </li>

            <!-- Nav Item - Charts -->

            <li class="nav-item">

                <a class="nav-link" href="scrap.php">

                    <i class="fas fa-fw fa-chart-area"></i>

                    <span>Scrap</span></a>

            </li>

            <!-- Divider -->

            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->

            <div class="text-center d-none d-md-inline">

                <button class="rounded-circle border-0" id="sidebarToggle"></button>

            </div>

        </ul>

        <!-- End of Sidebar -->

        <!-- Content Wrapper -->

        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->

            <div id="content">

                <!-- Topbar -->

                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->

                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">

                        <i class="fa fa-bars"></i>

                    </button>

                    <!-- Topbar Search -->

                    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">

                        <div class="input-group">

                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

                            <div class="input-group-append">

                                <button class="btn btn-primary" type="button">

                                    <i class="fas fa-search fa-sm"></i>

                                </button>

                            </div>

                        </div>

                    </form>

                    <!-- Topbar Navbar -->

                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->

                        <li class="nav-item dropdown no-arrow d-sm-none">

                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <i class="fas fa-search fa-fw"></i>

                            </a>

                            <!-- Dropdown - Messages -->

                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">

                                <form class="form-inline mr-auto w-100 navbar-search">

                                    <div class="input-group">

                                        <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

                                        <div class="input-group-append">

                                            <button class="btn btn-primary" type="button">

                                                <i class="fas fa-search fa-sm"></i>

                                            </button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </li>

                        <!-- Nav Item - Alerts -->

                        

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->

                         <li class="nav-item dropdown no-arrow">

                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['login']; ?></span>

                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">

                            </a>

                            <!-- Dropdown - User Information -->

                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">

                                <div class="dropdown-divider"></div>

                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">

                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>

                                    Logout

                                </a>

                            </div>

                        </li>

                    </ul>

                </nav>

                <!-- End of Topbar -->

                <!-- Begin Page Content -->

   <div class="dropdown"  style="margin:0 auto;text-align: center;">

  <button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

    Inventory

  </button>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

    <a class="dropdown-item" selected href="603_har_inv.php">Hardware Inventory</a>

    <a class="dropdown-item" href="603_sof_inv.php">Software Inventory</a>

    

  </div>

</div>
<div class="container-fluid">

                    <!-- Page Heading -->

                    <div class="d-sm-flex align-items-center justify-content-between mb-4">

                        <a href="Generate Report 603 har.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>

                    </div>

<br>
<?php
include 'navigation.php';
?>
<br>

                

                <div class="table-responsive" style="margin:0 auto; width:90%; overflow:auto; height:80%;">

                    <form>

                        <table class="table table-light table-bordered" id="table" style="background-color: white;box-shadow: 2px 2px 2px #999;">

                            <tr style="text-align: center;">

                               

                                <th>Sr. no.</th>

                                <th>Lab</th>

                                <th>Description</th>

                                <th>Quantity</th>

                                <th>Equipment Serial No.</th>

                                <th>College Code</th>

                                <th>Supplier / Manufacturer</th>

                               

                                <th>Invoice</th>

                                <th>Challan</th>

                                <th>Date of Purchase </th>

                                <th>Gl No.</th>

                                <th>Rate</th>

                                <th>Discount</th>

                                <th>Discounted Rate</th>

                                <th>VAT/MST/CGST/SGST</th>

                                <th>Rate with Vat</th>

                                <th>Octri</th>

                                <th>Rate with Octri</th>

                                <th>Lab_in_Charge_Name</th>

                                <th>Name_of_HOD</th>

                                <th>Total Cost</th>

                                <th>Image / PDF</th>

                                <th>Working Status</th>

                                <th>Action</th>

                            </tr>

                             <?php

                                    if ($result->num_rows > 0) {

                                        while ($row = $result->fetch_assoc()) {

                                    ?> 

                            <tr>

                                 <td style="text-align: center;"><?php echo ++$counter; ?></td>

                                 <td style="text-align: center;"><?php echo $row["lab_no"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["description"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["quantity"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["equipment no"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["college code"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["manufacturer"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["invoice"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["challan_no"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["date"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["gi_no"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["rate"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["discount"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["discounted rate"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["vat"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["rate with vat"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["octri"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["rate_with_octri"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["Lab_in_Charge_Name"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["Name_of_HOD"]; ?></td>

                                 <td style="text-align: center;"><?php echo $row["total_cost"]; ?></td>

                                 <td style="text-align: center;"><a href="<?php echo $row['path']; ?>">view</a></td>

                                 <td style="text-align: center;"><?php echo $row["defective"]; ?></td>

                                 <td style="text-align: center;">

                                    <a href="edit_item.php?id=<?php echo $row['id'] ?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                                    <a href="del hardware.php?id=<?php echo $row['id'] ?>"><i class="fa fa-trash"></i>

                                </td>

                                </td>

                            </tr>

                    <?php

                                        }

                                    }

                    ?>

                        </table>

                        <!--<div class="text-center">

            <a href="user_data_print.php" class="btn btn-primary"></a> 

        </div>-->

                    </form>

                </div>

                <br>

<!-- Scroll to Top Button-->

<a class="scroll-to-top rounded" href="#page-top">

    <i class="fas fa-angle-up"></i>

</a>
<?php include 'footer.php' ?>
<!-- Logout Modal-->

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

    <div class="modal-dialog" role="document">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>

                <button class="close" type="button" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">×</span>

                </button>

            </div>

            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>

            <div class="modal-footer">

                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>

                <a class="btn btn-primary" href="logout.php">Logout</a>

            </div>

        </div>

    </div>

</div>

<!-- Bootstrap core JavaScript-->

<script src="vendor/jquery/jquery.min.js"></script>

<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->

<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->

<script src="js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->

<script src="vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->

<script src="js/demo/chart-area-demo.js"></script>

<script src="js/demo/chart-pie-demo.js"></script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>

</body>

</html>