<?php
include('connect.php');
session_start();
if (! (isset ( $_SESSION ['login'] ))) {
	header ( 'location:index.php' );
}
$output=" ";
if(isset($_POST['inventory'])){
	$output="lab_no, description, qty, eqp_no, code, maf, inv, date, gi_no, rate, dis_rate, rate_vat, cost_vat, defective  
";
	$selectyr = "select * from items;";
	$selectyrquery = mysqli_query($conn, $selectyr);
	if(mysqli_num_rows($selectyrquery)>0){	
		while($rows = mysqli_fetch_array($selectyrquery)){
			$output .= $rows['lab_no'].", ".$rows['description'].",".$rows['quantity'].",".$rows['equipment no'].",".$rows['college code'].",".$rows['manufacturer'].",".$rows['invoice'].",".$rows['date'].",".$rows['gi_no'].",".$rows['rate'].",".$rows['discounted rate'].",".$rows['rate with vat'].",".$rows['cost with vat'].",".$rows['defective']."
";		
		}
	}
	else{
		$output.="No";
	}
	$date = date("d-m-Y")."_".date("h:i:sA");
	header("Content-Type: text/csv");
	header("Content-Disposition:attachment; filename=inventory_\"$date\".csv");
	echo $output;
}
?>