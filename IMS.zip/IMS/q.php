<?php

 /***** EDIT BELOW LINES *****/

  $DB_Server = "localhost"; // MySQL Server

  $DB_Username = "id15573716_admin"; // MySQL Username

  $DB_Password = "Zylox@135pass"; // MySQL Password

  $DB_DBName = "id15573716_labm"; // MySQL Database Name

  $DB_TBLName = "items"; // MySQL Table Name

  $xls_filename = 'export_'.date('Y-m-d').'.xls'; // Define Excel (.xls) file name

  /***** DO NOT EDIT BELOW LINES *****/

  // Create MySQL connection

  $sql = "Select * from $DB_TBLName";

  $Connect = new mysqli("localhost","id15573716_admin","Zylox@135pass","id15573716_labm","items");

	if($Connect->connect_error)

	{

		die("connection failed: " . $Connect->connect_error());

	}

  // Select database

//   $Db = mysqli_select_db($DB_DBName, $Connect) or die("Failed to select database:<br />" . mysqli_error(). "<br />" . mysqli_errno());

  // Execute query

  $result = mysqli_query($Connect, "SELECT * FROM items");

  // Header info settings

  header("Content-Type: application/xls");

  header("Content-Disposition: attachment; filename=$xls_filename");

  header("Pragma: no-cache");

  header("Expires: 0");

  /***** Start of Formatting for Excel *****/

  // Define separator (defines columns in excel &amp; tabs in word)

  $sep = "\t"; // tabbed character

  // Start of printing column names as names of MySQL fields

   foreach (mysqli_fetch_lengths($result) as $i => $val) {

    printf("Field %2d has length: %2d\n", $i+1, $val);

  }

//  for ($i = 0; $i<$result -> fetch_row(); $i++) {

//   printf $result -> fetch_row(). "\t";

//  }

 print("\n");

  // End of printing column names

  // Start while loop to get data

  while($row = $result -> fetch_row())

 {

  $schema_insert = "";

 for($j=0; $j<$result->fetch_row(); $j++)

 {

  if(!isset($row[$j])) {

  $schema_insert .= "NULL".$sep;

 }

  elseif ($row[$j] != "") {

  $schema_insert .= "$row[$j]".$sep;

 }

  else {

  $schema_insert .= "".$sep;

 }

 }

  $schema_insert = str_replace($sep."$", "", $schema_insert);

  $schema_insert = preg_replace("/\r\n|\n\r|\n|\r/", " ", $schema_insert);

  $schema_insert .= "\t";

 print(trim($schema_insert));

 print "\n";

 }

?>