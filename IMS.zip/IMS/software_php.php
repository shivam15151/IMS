<?php

include('connect.php');

$lab = $_POST["lab_no"];

$description = $_POST["description"];

$qty = $_POST["qty"];

$no_users = $_POST["no_of_users"];

$ser_based = $_POST["server_based"];

$swe_no = $_POST["sw_no"];

$exp_date = $_POST["exp_date"];

$i_code = $_POST["i_code"];

$supplier = $_POST["supplier"];

$invoice = $_POST["invoice"];

$date = $_POST["date"];

$gi_no = $_POST["gi_no"];

$rate_vat = $_POST["rate_vat"];

$Lab_in_Charge_Name = $_POST["Lab_in_Charge_Name"];

$Name_of_HOD = $_POST["Name_of_HOD"];

$total_cost = $_POST["total_cost"];

$working = $_POST["Working"];

$remark = $_POST["remark"];

$img = rand(1000,100000)."-".$_FILES['img']['name'];

$img_loc = $_FILES['img']['tmp_name'];

$img_size = $_FILES['img']['size'];

$img_type = $_FILES['img']['type'];

$img_location="uploads/";

$new_img_size = $img_size/1024; 

$new_img_name = strtolower($img);

$final_img=str_replace(' ','-',$new_img_name);

if(move_uploaded_file($img_loc,$img_location.$final_img)){

$sql = "INSERT INTO `software`(`lab_no`,`description`, `quantity`, `no_users`, `server_based`, `license_no`, `license_expiry`, `institute_code`, `supplier`, `invoice`, `date_purchase`, `gi_no`, `rate_vat`,`Lab_in_Charge_Name`,`Name_of_HOD`,`total_cost`, `path`, `status`, `remark`) VALUES( '$lab','$description', '$qty' ,'$no_users' , '$ser_based','$swe_no' ,'$exp_date'  , '$i_code', '$supplier', '$invoice', '$date', '$gi_no', '$rate_vat','$Lab_in_Charge_Name','$Name_of_HOD','$total_cost' , 'uploads/$final_img', '$working','$remark')";

$result = $conn->query($sql);

if($result === TRUE){

  echo '<script>

  alert("Item Added Sucessfully");

  window.location = "add item.php";</script>';

}else{

  echo '<script>

  alert("Something went Wrong! Please try Again.");

  window.location = "add item.php";</script>';

}

}

else{

    $sql ="INSERT INTO `software`(`lab_no`,`description`, `quantity`, `no_users`, `server_based`, `license_no`, `license_expiry`, `institute_code`, `supplier`, `invoice`, `date_purchase`, `gi_no`, `rate_vat`,`Lab_in_Charge_Name`,`Name_of_HOD`, `total_cost`,`path`, `status`, `remark`) VALUES( '$lab','$description', '$qty' ,'$no_users' , '$ser_based','$swe_no' ,'$exp_date'  , '$i_code', '$supplier', '$invoice', '$date', '$gi_no', '$rate_vat','$Lab_in_Charge_Name','$Name_of_HOD','$total_cost' ,'uploads/$final_img','$working','$remark')";

$result = $conn->query($sql);

if($result === TRUE){

  echo '<script>

  alert("Item Added Sucessfully");

  window.location = "add item.php";</script>';

}else{

  echo '<script>

  alert("Something went Wrong! Please try Again.");

  window.location = "add item.php";</script>';

}

}

?>

