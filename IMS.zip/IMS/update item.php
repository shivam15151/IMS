<?php

include('connect.php');

$id = $_GET['id'];

$lab_no = $_POST["lab_no"];

$description = $_POST["description"];

$quantity = $_POST["qty"];

$equ_sr_no = $_POST["eqp_no"];

$clg_code = $_POST["code"];

$maf = $_POST["maf"];

$invoice = $_POST["inv"];

$chal = $_POST["chal"];

$dop = $_POST["date"];

$gi_no = $_POST["gi_no"];

$rate = $_POST["rate"];

$dis = $_POST["dis"];

$dis_rate = $_POST["dis_rate"];

$vat = $_POST["vat"];

$rate_vat = $_POST["rate_vat"];

$octri = $_POST["octri"];

$oct_rate = $_POST["oct_rate"];

$Lab_in_Charge_Name = $_POST["Lab_in_Charge_Name"];

$Name_of_HOD = $_POST["Name_of_HOD"];

$total = $_POST["total"];

$defective = $_POST["defective"];

$remark = $_POST["remark"];

$img = rand(1000,100000)."-".$_FILES['img']['name'];

$img_loc = $_FILES['img']['tmp_name'];

$img_size = $_FILES['img']['size'];

$img_type = $_FILES['img']['type'];

$img_location="uploads/";

$new_img_size = $img_size/1024; 

$new_img_name = strtolower($img);

$final_img=str_replace(' ','-',$new_img_name);

if(move_uploaded_file($img_loc,$img_location.$final_img)){

$sql = "UPDATE `items` SET `lab_no`='$lab_no',`description`='$description',`quantity`='$quantity',`equipment no`='$equ_sr_no',`college code`='$clg_code',`manufacturer`='$maf',`invoice`='$invoice',`challan_no`='$chal',`date`='$dop',`gi_no`='$gi_no',`rate`='$rate',`discount`='$dis',`discounted rate`='$dis_rate',`vat`='$vat',`rate with vat`='$rate_vat',`octri`='$octri',`rate_with_octri`='$oct_rate',`Lab_in_Charge_Name`='$Lab_in_Charge_Name',`Name_of_HOD`='$Name_of_HOD',`total_cost`='$total',`path`='uploads/$final_img',`defective`='$defective',`remark`='remark' WHERE `id`='$id'";

$result = $conn->query($sql);

if($result === TRUE){

  echo '<script>

  alert("Item Updated Sucessfully");

  window.location = "hardware inv.php";</script>';

}else{

  echo '<script>

  alert("Something went Wrong! Please try Again.");

  window.location = "hardware inv.php";</script>'; 

}

}else{

    $sql = "UPDATE `items` SET `lab_no`='$lab_no',`description`='$description',`quantity`='$quantity',`equipment no`='$equ_sr_no',`college code`='$clg_code',`manufacturer`='$maf',`invoice`='$invoice',`challan_no`='$chal',`date`='$dop',`gi_no`='$gi_no',`rate`='$rate',`discount`='$dis',`discounted rate`='$dis_rate',`vat`='$vat',`rate with vat`='$rate_vat',`octri`='$octri',`rate_with_octri`='$oct_rate',`Lab_in_Charge_Name`='$Lab_in_Charge_Name',`Name_of_HOD`='$Name_of_HOD',`total_cost`='$total',`path`='uploads/$final_img',`defective`='$defective',`remark`='remark' WHERE `id`='$id'";

$result = $conn->query($sql);

if($result === TRUE){

  echo '<script>

  alert("Item Updated Sucessfully");

  window.location = "hardware inv.php";</script>';

}else{

  echo '<script>

  alert("Something went Wrong! Please try Again.");

  window.location = "hardware inv.php";</script>'; 

}

}

?>