<?php

include('connect.php');

if(isset($_POST['submit'])){

$username = $_POST["username"];

$password = $_POST["password"];

$sql = "SELECT * FROM `users` WHERE `username`= '$username' and `password`= '$password'";

$result = $conn->query($sql);

if($result->num_rows > 0)

{

	session_start();

	$_SESSION["login"] = $_POST['username'];

	

echo '<script>

	window.location = "dashboard.php";

	</script>';

}else{

	echo '<script>

	alert("Invalid Username or Password");

	window.location = "index.php";

	</script>';

}

}

?>
